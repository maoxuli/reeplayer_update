#!/bin/bash

PORT=5004

function print_help { 
  echo "Usage: $0 [-p ${PORT}] [-h]"
  echo "-p: streaming port"
  echo "-h: help"
} 

while getopts ":p:h" opt; do
  case $opt in
    p) PORT="$OPTARG";;
    \? | h | *) print_help; exit 0;;
  esac
done

echo "PORT: $PORT"

gst-launch-1.0 udpsrc port=$PORT ! application/x-rtp, encoding-name=H264, payload=96 ! queue ! rtph264depay ! h264parse ! queue ! avdec_h264 ! autovideosink sync=false async=false -e
