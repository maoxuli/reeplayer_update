import socket 
import select 

HOST = '0.0.0.0'
PORT = 6666 

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind((HOST, PORT))
print("Listen on ", PORT)
s.listen(5)
while True: 
    conn, addr = s.accept()
    if conn:
        print('Connected by {}'.format(addr))
        while True: 
            try: 
                data = conn.recv(1024).decode()
                if len(data) == 0: 
                    print("disconnect")
                    break
                print("Received: {}".format(data))
                conn.sendall(data.encode())
                print("Sent back")
            except socket.error, msg: 
                print("Socket exception: {}".format(msg))
                break
        conn.close()
s.close()
            