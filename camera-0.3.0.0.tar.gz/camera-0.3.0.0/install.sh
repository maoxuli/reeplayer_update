#!/bin/bash

## The script is used to install the camera system software on 
## current system. After the installation, the camera system software 
## will be launched with the system startup. 

echo "$(date +"%Y-%m-%d %T"): install camera system..."

## the script is in camera dir or camera version dir   
CAMERA_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "CAMERA_DIR: ${CAMERA_DIR}" 

## if install from version package, create symbal link       
VERSION="$( basename "${CAMERA_DIR}" )"
# echo "VERSION: ${VERSION}"
if [ "${VERSION}" != "camera" ] ; then 
  VERSION_DIR="${CAMERA_DIR}"
  CAMERA_DIR="$( readlink -m "${VERSION_DIR}/.." )/camera"
  echo "create symbal link: ${CAMERA_DIR} -> ${VERSION_DIR}"
  ln -snfr "${VERSION_DIR}" "${CAMERA_DIR}"
fi 

## install sytemd service 
# echo "install systemd service..."
sudo "${CAMERA_DIR}/scripts/camera_service.sh" install 

echo "$(date +"%Y-%m-%d %T"): install camera system done!"
