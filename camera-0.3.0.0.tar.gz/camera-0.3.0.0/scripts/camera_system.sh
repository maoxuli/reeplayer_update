#!/bin/bash

## The script is used to start and stop the camera system.
## when start the system, may start a background process to 
## check and download the latest version.  
## the start process may check downloaded versions and update 
## to the latest version. 

## Reeplayer/camera/scripts 
## INSTALL_DIR/CAMERA_DIR/SCRIPTS_DIR 
SCRIPTS_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "SCRIPTS_DIR: ${SCRIPTS_DIR}" 

INSTALL_DIR="$( readlink -m "${SCRIPTS_DIR}/../.." )"
echo "INSTALL_DIR: ${INSTALL_DIR}"

CAMERA_DIR="${INSTALL_DIR}/camera"
echo "CAMERA_DIR: ${CAMERA_DIR}"

start () {
  echo "$(date +"%Y-%m-%d %T"): start camera system..."
 
  ## load setup from current version 
  echo "Loading setup: ${SCRIPTS_DIR}/camera_setup.sh"
  . ${SCRIPTS_DIR}/camera_setup.sh 

  ## auto update to install the latest version
  echo "AUTO_UPDATE: ${AUTO_UPDATE}"
  if [ -z "${AUTO_UPDATE}" ] || [ "${AUTO_UPDATE}" -ge 2 ] ; then 
    echo ". ${SCRIPTS_DIR}/camera_update.sh install"
    . ${SCRIPTS_DIR}/camera_update.sh install
  fi

  ## re-load setup from current version 
  echo "Loading setup: ${SCRIPTS_DIR}/camera_setup.sh"
  . ${SCRIPTS_DIR}/camera_setup.sh 

  if [ -z "$CAMERA_LOG" ] ;  then
    echo "CAMERA_LOG is not set!"
    CAMERA_LOG="${INSTALL_DIR}/camera_log"
  fi
  echo "CAMERA_LOG: ${CAMERA_LOG}" 
  mkdir -p "${CAMERA_LOG}"

  if [ -z "$CAMERA_CONFIG" ] ;  then
    echo "CAMERA_CONFIG is not set!"
    CAMERA_CONFIG="${CAMERA_DIR}/config"
  fi
  echo "CAMERA_CONFIG: ${CAMERA_CONFIG}" 

  if [ -z "${CAMERA_BIN}" ] ; then 
    echo "CAMERA_BIN is not set!"
    CAMERA_BIN="${CAMERA_DIR}/bin"
  fi 
  echo "CAMERA_BIN: ${CAMERA_BIN}" 

  ## start camerad 
  CAMERAD="${CAMERA_BIN}/camerad"
  echo "CAMERAD: ${CAMERAD}" 
  if [ ! -f "${CAMERAD}" ] ; then 
    echo "${CAMERAD} not found!"
  else 
    CAMERAD_CONFIG=${CAMERA_CONFIG}/camerad.json
    echo "CAMERAD_CONFIG: ${CAMERAD_CONFIG}" 
    if [ ! -f "${CAMERAD_CONFIG}" ] ; then 
      echo "${CAMERAD_CONFIG} not found!"
    else 
      echo "${CAMERAD} -c ${CAMERAD_CONFIG} > /dev/null 2>&1 &"
      ${CAMERAD} -c ${CAMERAD_CONFIG} > /dev/null 2>&1 &
    fi 
  fi 

  ## start auto update to download the latest version
  echo "AUTO_UPDATE: ${AUTO_UPDATE}" 
  if [ -z "${AUTO_UPDATE}" ] || [ "${AUTO_UPDATE}" -ge 1 ] ; then 
    UPDATE_LOG="${CAMERA_LOG}/update.log"
    echo "UPDATE_LOG: ${UPDATE_LOG}" 
    echo ". ${SCRIPTS_DIR}/camera_update.sh download >> ${UPDATE_LOG} 2>&1 &"
    . ${SCRIPTS_DIR}/camera_update.sh download >> ${UPDATE_LOG} 2>&1 &
  fi 

  echo "$(date +"%Y-%m-%d %T"): start camera system done!"
}

stop () {
  echo "$(date +"%Y-%m-%d %T"): stop camera system..."

  ## load setup from current version 
  # echo "Loading setup: ${SCRIPTS_DIR}/camera_setup.sh"
  # . ${SCRIPTS_DIR}/camera_setup.sh 

  # if [ -z "${CAMERA_BIN}" ] ; then 
  #   echo "CAMERA_BIN is not set!"
  #   CAMERA_BIN="${CAMERA_DIR}/bin"
  # fi 
  # echo "CAMERA_BIN: ${CAMERA_BIN}" 

  ## stop camerad 
  # CAMERAD="${CAMERA_BIN}/camerad"
  # echo "CAMERAD: ${CAMERAD}" 
  # echo "Killing ${CAMERAD}"
  # killall ${CAMERAD}

  killall "camerad"

  echo "$(date +"%Y-%m-%d %T"): stop camera system done!"
}

case "$1" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  *)
    echo "Usage: $0 {start|stop}"
    ;;
esac 
