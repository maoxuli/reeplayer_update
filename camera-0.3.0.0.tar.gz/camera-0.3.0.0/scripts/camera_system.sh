#!/bin/bash

## The script is used to start and stop the camera system.
## when start the system, may start a background process to 
## check and download the latest version.  
## the start process may check downloaded versions and update 
## to the latest version. 

## load setup 
if [ -z "$CAMERA_SCRIPTS" ] ;  then
  CAMERA_SCRIPTS="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
fi
echo "CAMERA_SCRIPTS: ${CAMERA_SCRIPTS}" 
echo "Loading setup: ${CAMERA_SCRIPTS}/camera_setup.sh"
. ${CAMERA_SCRIPTS}/camera_setup.sh 

## bin path
if [ -z "$CAMERA_BIN" ] ;  then
  echo "CAMERA_BIN is not set!"
  CAMERA_BIN="${CAMERA_SCRIPTS}/../bin"
fi
echo "CAMERA_BIN: ${CAMERA_BIN}" 

## config path
if [ -z "$CAMERA_CONFIG" ] ;  then
  echo "CAMERA_CONFIG is not set!"
  CAMERA_CONFIG="${CAMERA_SCRIPTS}/../config"
fi
echo "CAMERA_CONFIG: ${CAMERA_CONFIG}" 

## log path
if [ -z "$CAMERA_LOG" ] ;  then
  echo "CAMERA_LOG is not set!"
  CAMERA_LOG="${CAMERA_SCRIPTS}/../log"
fi
echo "CAMERA_LOG: ${CAMERA_LOG}" 

start () {
  echo "$(date +"%Y-%m-%d %T"): start camera system..."
 
  ## start auto update to download the latest version
  echo "AUTO_UPDATE: ${AUTO_UPDATE}" 
  if [ -z "${AUTO_UPDATE}" ] || [ "${AUTO_UPDATE}" -ge 1 ] ; then 
    UPDATE_LOG="${CAMERA_LOG}/update.log"
    echo "UPDATE_LOG: ${UPDATE_LOG}" 
    echo ". ${CAMERA_SCRIPTS}/camera_update.sh download >> ${UPDATE_LOG} 2>&1 &"
    . ${CAMERA_SCRIPTS}/camera_update.sh download >> ${UPDATE_LOG} 2>&1 &
  fi 

  ## auto update to install the latest version
  if [ -z "${AUTO_UPDATE}" ] || [ "${AUTO_UPDATE}" -ge 2 ] ; then 
    echo ". ${CAMERA_SCRIPTS}/camera_update.sh install"
    . ${CAMERA_SCRIPTS}/camera_update.sh install
  fi

  ## start camerad 
  CAMERAD="${CAMERA_BIN}/camerad"
  echo "CAMERAD: ${CAMERAD}" 
  if [ ! -f "${CAMERAD}" ] ; then 
    echo "${CAMERAD} not found!"
  else 
    CAMERAD_CONFIG=${CAMERA_CONFIG}/camerad.json
    echo "CAMERAD_CONFIG: ${CAMERAD_CONFIG}" 
    if [ ! -f "${CAMERAD_CONFIG}" ] ; then 
      echo "${CAMERAD_CONFIG} not found!"
    else 
      echo "${CAMERAD} -c ${CAMERAD_CONFIG} > /dev/null 2>&1 &"
      ${CAMERAD} -c ${CAMERAD_CONFIG} > /dev/null 2>&1 &
    fi 
  fi 

  echo "$(date +"%Y-%m-%d %T"): start camera system done!"
}

stop () {
  echo "$(date +"%Y-%m-%d %T"): stop camera system..."

  ## stop camerad 
  CAMERAD="${CAMERA_BIN}/camerad"
  echo "CAMERAD: ${CAMERAD}" 
  echo "Killing ${CAMERAD}"
  killall ${CAMERAD}

  echo "$(date +"%Y-%m-%d %T"): stop camera system done!"
}

case "$1" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  *)
    echo "Usage: $0 {start|stop}"
    ;;
esac 
