#!/bin/bash

## Overwrite the default settings in this file. 
## If the settings are not set, default will be used.  

set -x

## HOME must be set 
## by login or by systemd unit 
if [ -z "${HOME}" ] ; then 
    echo "HOME is not set!"
    exit
fi 

## Dependencies 
export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:${HOME}/Reeplayer/camera/lib" 
export GST_PLUGIN_PATH="${GST_PLUGIN_PATH}:${HOME}/Reeplayer/camera/lib/gst-plugins"
export PATH="$PATH:${HOME}/Reeplayer/camera/bin"

## Path for log files
# export CAMERA_LOG="${HOME}/Reeplayer/camera_log"

## Path for config files
# export CAMERA_CONFIG="${HOME}/Reeplayer/camera/config"

## Path for camera system executable 
# export CAMERA_BIN="${HOME}/Reeplayer/camera/bin"

## Auto update level 
## 0: no auto update, 1: auto download new version 
## 2: auto download and install new version 
# export AUTO_UPDATE=2 

## URL for update 
# export UPDATE_URL=""
export UPDATE_URL="https://raw.githubusercontent.com/maoxuli/reeplayer_update/master"

set +x 
