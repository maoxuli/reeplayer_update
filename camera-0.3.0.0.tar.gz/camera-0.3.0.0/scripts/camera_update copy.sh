#!/bin/bash

## The script is used to update the camera system software,
## the updated package is downloaded and extracted to the 
## project directory, in the folder named with version number. 

echo "$(date +"%Y-%m-%d %T"): camera update..."

## scripts path
if [ -z "${CAMERA_SCRIPTS}" ] ;  then
  CAMERA_SCRIPTS="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
fi
echo "CAMERA_SCRIPTS: ${CAMERA_SCRIPTS}" 

## check the latest version in project directory
PROJECT_DIR="${CAMERA_SCRIPTS}/.."
echo "PROJECT_DIR: ${PROJECT_DIR}"
LOCAL_VERSION="0.0.0.0"

## "1.1.1.1" is expanded to decimal number string "01010101"
## so each version element support two decimal digits in [0, 99]  
ver() {
    printf "%02d%02d%02d%02d" ${1//./ }
}

shopt -s nullglob
for d in ${PROJECT_DIR}/camera-*/ ; do
  # echo $d
  # VERSION="$(basename $d)"
  VERSION="${d##*-}"
  VERSION="${VERSION%/}"
  # echo "VERSION: ${VERSION}"
  if [ "$(ver "${VERSION}")" -gt "$(ver "${LOCAL_VERSION}")" ] ; then 
    LOCAL_VERSION=${VERSION}
    # echo "LOCAL_VERSION: ${LOCAL_VERSION}"
  fi
done
shopt -u nullglob

echo "LOCAL_VERSION: ${LOCAL_VERSION}"

## load setup
echo "Loading setup: ${CAMERA_SCRIPTS}/camera_setup.sh"
. ${CAMERA_SCRIPTS}/camera_setup.sh 

## get the latest version from update URL 
if [ ! -z "${UPDATE_URL}" ] ; then 
  echo "UPDATE_URL: ${UPDATE_URL}" 

  ## download version package to project dir 
  ## if updated version is available 

fi 

## extract the downloaded version packages 
shopt -s nullglob
for f in ${PROJECT_DIR}/camera-*.tar.gz ; do
  VERSION_PACKAGE=$f
  VERSION_DIR="$(basename "${VERSION_PACKAGE}" .tar.gz)"
  # echo ${VERSION_DIR}
  if [ ! -d "${PROJECT_DIR}/${VERSION_DIR}" ] ; then 
    echo "extract ${VERSION_PACKAGE}"
    tar -xzf "${VERSION_PACKAGE}" -C "${PROJECT_DIR}"
  fi 
  echo "remove ${VERSION_PACKAGE}"
  rm ${VERSION_PACKAGE}
done
shopt -u nullglob

echo "$(date +"%Y-%m-%d %T"): camera update done!"
