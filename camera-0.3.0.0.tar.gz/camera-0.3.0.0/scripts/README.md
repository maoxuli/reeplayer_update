# Utility Scripts  

## Live preview for the cameras on Jetson system 

If the Jetson system has a local monitor, below scripts could be used for live preview.  

    ~/camera/scripts/jetson_preview.sh      [preview for single camera]
    ~/camera/scripts/pairwise_preview.sh    [preview for two cameras]

You may use below command to show the options for the shell script: 

    ~/camera/scripts/jetson_preview.sh -h 
    ~/camera/scripts/pairwise_preview.sh -h 

In summary, the options can be used to set the camera ID, the capture resolution, the size scale for display, and the rotation of the input images. 

1. Set camera ID with -i (only for single camera preview)

    ~/camera/scripts/jetson_preview.sh -i 0     (camera 0)
    ~/camera/scripts/jetson_preview.sh -i 1     (camera 1)

2. Set camera mode (resolution and framerate) with -m 

    ~/camera/scripts/jetson_preview.sh -m 1080p     (1920x1080@30)
    ~/camera/scripts/jetson_preview.sh -m 1440p     (2560x1440@30)
    ~/camera/scripts/jetson_preview.sh -m 1944p     (2592x1944@30)
    ~/camera/scripts/jetson_preview.sh -m 3040p     (4032x3040@30)

3. Set rotation for input image with -r 

    ~/camera/scripts/jetson_preview.sh -r 0     (no rotation)
    ~/camera/scripts/jetson_preview.sh -r 2     (rotate 180 degree)
    ~/camera/scripts/jetson_preview.sh -r 4     (horizontal flip)
    ~/camera/scripts/jetson_preview.sh -r 6     (vertical flip)

4. Set image size scale for display with -s 

    ~/camera/scripts/jetson_preview.sh -s 2     (display size is the image size divided by 2)
    ~/camera/scripts/jetson_preview.sh -s 3     (display size is the image size divided by 3)


## Test cameras on Jetson Nano by streaming video 

If the Jetson Nano is a headless system, the cameras could be tested by streaming the captured images to another system. 

On Jetson Nano: open a terminal (or SSH seesion) and execute below command: 

    ~/camera/scripts/jetson_streaming.sh

On another system: open a terminal and excute below command:

    scripts/streaming_client_udp.sh 

Please refer to the "live preview" for the options for camera ID, capture resolution and fraterate, and rotation of the input images. 

Other options are supported for streaming target IP and video stream quality. 

1. Set streaming target IP with -o 

    ~/camera/scripts/jetson_streaming.sh -o 192.168.1.169   (the IP address of target system)

2. Set video stream quality with -q 

    ~/camera/scripts/jetson_streaming.sh -q 1000000     (video stream quality in bps)


## Video recording for single camera on Jetson Nano, to a single video file 

On Jetson Nano, open a terminal (or SSH session) and execute below command: 

    ~/camera/scripts/jetson_recording.sh 

This shell script will record captured images to a single .mp4 file, until the script is terminated with ctrl-c. 

Please refer to the "live preview" for the options for camera ID, capture resolution and fraterate, and rotation of the input images. 

Other options are supported for video quality. 

1. Set video qualtity with -q 

    ~/camera/scripts/jetson_recording.sh -q 1000000     (video quality in bps)

## Video recording for single camera on Jetson Nano, to split video files 

On Jetson Nano, open a terminal (or SSH seesion) and execute below command: 

    ~/camera/scripts/jetson_recording_split.sh 

This shell script will record captured images to a series of video clips, until the script is terminated with ctrl-c. 

Please refer to the "live preview" for the options for camera ID, capture resolution and fraterate, and rotation of the input images. 

Same option -q is supported for video quality. 

## Video recording for single camera on Jetson Nano, to image files  

On Jetson Nano, open a terminal and execute below command: 

    ~/camera/scripts/jetson_recording_images.sh 

This shell script will record captured images to a series of image files, until the script is terminated with ctrl-c. 

Please refer to the "live preview" for the options for camera ID, capture resolution and fraterate, and rotation of the input images. 

Other options are supported for image file name and image quality. 

1. Set prefix for image file name with -o 

    ~/camera/scripts/jetson_recording_images.sh -o test     (prefix for image file name)

The script will record images to a series of files with the file name "[prefix]_[index].jpg, for example: 

    "test_000000.jpg"
    "test_000001.jpg"
    "test_000002.jpg"

If the prefix is not set, the script generate a prefix in the format of "[camera_id]_[camera_mode]_[date_time]", for example: 

    "camera_0_1080p_2020_09_10_23:11:18_000000.jpg"
    "camera_0_1080p_2020_09_10_23:11:18_000001.jpg"
    "camera_0_1080p_2020_09_10_23:11:18_000002.jpg" 

2. Set image qualtity with -q 

    ~/camera/scripts/jetson_recording.sh -q 100     (image compression quality)


## Pairwise video preview on Jetson system 


## Pairwise video streaming on Jetson system 


## Pairwise video recording on Jetson system 


## Preview video files on Jetson Nano by streaming the video 

1. On Jetson Nano: read video file -i and streaming to target host -o: 

    scripts/jetson_video_streaming.sh -i ~/example.mp4 -o 192.168.1.169 

    -i: video file name 
    -o: streaming target host IP (the host that plays the video stream)
    -r: rotation on camera image 
    -h: help  

    Please refer above section for the options of -r. 

    [NOTE: 'ctrl-c' MULTIPLE time to stop the running]

2. On a host system with monitor: receive and display video stream 

    scripts/streaming_client_udp.sh 


# System service 

1. Start and stop recording in background 

    scripts/stitching_system.sh start 
    scripts/stitching_system.sh stop 

    (the log is saved in "log" folder)

2. Install systemd service to launch recording on system startup

    sudo scripts/stitching_service.sh install 
    sudo scripts/stitching_service.sh uninstall 

    [The "stitching.service" should be modified according to system user]

Service management with systemd tool: 

    systemctl status stitching.service 
    sudo systemctl start stitching.service 
    sudo systemctl stop stitching.serivce 