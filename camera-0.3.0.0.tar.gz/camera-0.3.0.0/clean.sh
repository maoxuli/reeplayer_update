#!/bin/bash 
set -x 
sudo rm /usr/local/lib/libvideostitch* 
sudo rm /usr/local/bin/ds-videostitch* 
sudo rm /usr/local/bin/reeplayer* 
sudo rm /usr/local/bin/camerad* 
sudo rm /opt/nvidia/deepstream/deepstream-5.0/lib/gst-plugins/libnvdsgst_camerascalib.so
sudo rm /opt/nvidia/deepstream/deepstream-5.0/lib/gst-plugins/libnvdsgst_videostitcher.so
