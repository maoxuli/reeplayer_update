#!/bin/bash

echo "export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib:$LD_LIBRARY_PATH:${HOME}/Reeplayer/camera/lib" >> ~/.bashrc 
echo "export GST_PLUGIN_PATH=${GST_PLUGIN_PATH}:${HOME}/Reeplayer/camera/lib/gst-plugins" >> ~/.bashrc 
echo "export PATH=$PATH:${HOME}/Reeplayer/camera/bin" >> ~/.bashrc 
