# Extrinsic calibration of camera 

The code includess two-steps extrinsic calbiration of cammeras. 

1. Calcuate homography between two cameras using the features matching algorithms in OpenCV 

    python homography_estimation.py left_fixed --config config.json --reference_image 000015_0.png --target_image 000015_1.png 

The homography will display on screen, and the image for features/matching and the image for warping/blending are saved.  

2. Interactive adjustments ont the homography 

With --interactive argument, the script support to adjust the homography elements and display the results in real-time. By this way, the homography can be adjusted manually. 

With --parttern argument, a chessboard can be used to help the calibration. 

## Major issues 

1. With this method, the result depends on the features detected. If the features are distributed in the overlap region of the images, then the homography will be better. If the features only covered a small part of the overlap region, then the homography generates big errors for other regions. 

2. This script only calculate homography from one image to another, so the warping/blending is warping one image to another image. So in the result, the two images have different persepective angle. In the real application, we need to adjust the homography to divide it for two cameras. 

# Revision of extrinsic calibration 

The old method calibrate two camera by projecting one image plane to another. This is not a big issue if the cameras' FOV is relative narrow, and the image planes of the two cameras are in a relative small angle. The homography between two cameras is given as below: 

{
    "homographies": 
    [ 
        {
            "images": 
            {
                "target": 1, 
                "reference": 0
            }, 
            "matrix": 
            {
                "h00":-0.836900689562, "h01":0.0536098105518, "h02":1380.24220883, 
                "h10":-0.692579649292, "h11":0.733203495169, "h12":243.923146374, 
                "h20":-0.00092198128431, "h21":7.27380059492e-05, "h22":1.0
            }
        } 
    ]
}

For two cameras with a wider FOV and a relative bigger rotation, it is necessary to adjust the calibration to project the two images to a common plane. The homographies for two cameras are given as below: 

{
    "resolution": 
    {
        "width": 2016 
        "height": 1520 
    },
    "homographies": 
    [ 
        {
            "images": 
            {
                "target": 0, 
                "reference": 2
            }, 
            "matrix": 
            {
                "h00":-0.836900689562, "h01":0.0536098105518, "h02":1380.24220883, 
                "h10":-0.692579649292, "h11":0.733203495169, "h12":243.923146374, 
                "h20":-0.00092198128431, "h21":7.27380059492e-05, "h22":1.0
            }
        },
        {
            "images": 
            {
                "target": 1, 
                "reference": 2
            }, 
            "matrix": 
            {
                "h00":-0.836900689562, "h01":0.0536098105518, "h02":1380.24220883, 
                "h10":-0.692579649292, "h11":0.733203495169, "h12":243.923146374, 
                "h20":-0.00092198128431, "h21":7.27380059492e-05, "h22":1.0
            }
        } 
    ]
}
