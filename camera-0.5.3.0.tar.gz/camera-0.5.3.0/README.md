# Camera

The software system for camera device. 

## Build software system from source code 

By default, the source code on camera device should be saved in file system as below: 

    ~/Reeplayer 
    ~/Reeplayer/camera                      [camera repo]
    ~/Reeplayer/camera_ros/src/camera_ros   [camera_ros repo]
    ~/Reeplayer/camera-core                 [camera-core repo]

Before build the software, create an install folder in file system and set its ownership as below: 

    sudo mkdir -p /opt/reeplayer
    sudo chown $(id -u):$(id -g) /opt/reeplayer 

The software could be built in docker container, as below: 

    cd ~/Reeplayer/camera/docker 
    ./docker_start.sh 
    [In docker container]
    cd camera 
    ./build -ai  

The generated install package will be in ~/Reeplayer/camera. 

A copy of the binary version of the software system will be installed in ~/opt/reeplayer/camera.  

## Run software on development device 

On the camera device that used for development, the software system could be built as above and the software system will be installed in ~/opt/reeplayer/camera. To "install" the software to make it run with system startup, run script as below: 

    cd /opt/reeplayer/camera 
    ./install.sh

To stop the camera software launching with system startup, run below script: 

    cd /opt/reeplayer/camera
    ./uninstall.sh 

In addition, all the software modules could be start and stop seperately for debugging and testing. The software modules could also run in its source code location for debugging and testing. Please refer to relevant documents for more details.  

## Install and run software system on other camera device 

On a new camera device, follow below steps to install the software system: 

1. Download the camera software install package as below: 

    ~/Downloads/camera-0.5.3.0.tar.gz 

2. Extract the software to /opt/reeplayer/camera-0.5.3.0 as below: 
    sudo mkdir /opt/reeplayer
    sudo chown $(id -u):$(id -g) /opt/reeplayer
    tar -xzvf ~/Downloads/camera-0.5.3.0.tar.gz -C /opt/reeplayer 

3. Install the software to make it launch with system startup: 

    cd /opt/reeplayer/camera-0.5.3.0 
    ./install.sh 

After installation, /opt/reeplayer/camera will be a symbol link to /opt/reeplayer/camera-0.5.3.0. 

To uninstall the software, run below script: 

    cd /opt/reeplayer/camera 
    ./uninstall.sh 
