#!/bin/bash

## disable the auto start of the system 
## log necessary information  

echo "$(date +"%Y-%m-%d %T"): uninstall camera system..."

## the script is in camera dir or version package dir 
CAMERA_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "CAMERA_DIR: ${CAMERA_DIR}" 

## disable systemd service 
. ${CAMERA_DIR}/scripts/service.sh uninstall 

echo "$(date +"%Y-%m-%d %T"): uninstall camera system done!"
