#!/bin/bash

VERSION=0.5.3.0