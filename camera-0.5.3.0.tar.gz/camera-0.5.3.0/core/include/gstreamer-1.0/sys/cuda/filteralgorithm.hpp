/*
 * Copyright (C) 2017 RidgeRun, LLC (http://www.ridgerun.com)
 * All Rights Reserved.
 *
 * The contents of this software are proprietary and confidential to RidgeRun,
 * LLC.  No part of this program may be photocopied, reproduced or translated
 * into another programming language without prior written consent of
 * RidgeRun, LLC.  The user is free to modify the source code after obtaining
 * a software license from RidgeRun.  All source code changes must be provided
 * back to RidgeRun without any encumbrance.
 */

#ifndef __GST_CUDA_ALGORITHM_FILTER_HPP__
#define __GST_CUDA_ALGORITHM_FILTER_HPP__

#include <gmodule.h>
#include <sys/cuda/gstcuda.h>


namespace Gst
{
  namespace Cuda
  {
    namespace Algorithm
    {
      class Filter
      {
      public:

	/**
	 * open:
	 *
	 * Hook to allow the cuda algorithm initialization routine.
	 *
	 * Returns: true if initialization is successfull, false otherwise.
	 */
	virtual bool open () = 0;

	/**
	 * close:
	 *
	 * Hook to allow the cuda algorithm finalization routine.
	 *
	 * Returns: true if finalization is successfull, false otherwise.
	 */
	virtual bool close () = 0;

	/**
	 * process:
	 * @input_buffer: (in) (transfer none): The input buffer that contains
	 * the data to be processed on the GPU.
	 * @output_buffer: (out) (transfer none): The output buffer that contains
	 * the data processed by the GPU.
	 *
	 * Hook to allow the cuda algorithm process routine. This function
	 * is the responsible for the CUDA algorithm processing execution.
	 * This function will be called when in_place is not configured for
	 * processing the inconming buffers.
	 * In this function the input and output buffers are different,
	 * so the results of the CUDA algorithm processing only will be
	 * reflected on the output_buffer, that means that the
	 * input_buffer remains unmodified.
	 *
	 * Returns: true if process is successfull, false otherwise.
	 */
	virtual bool process (const GstCudaData &input_buffer, GstCudaData &output_buffer) = 0;

	/**
	 * process_ip:
	 *
	 * @io_buffer: (in) (transfer none): The input/output buffer that contains
	 * the data to be processed by the GPU.
	 *
	 * Hook to allow the cuda algorithm proccess_ip (proccess in place)
	 * routine. This function is the responsible for the CUDA algorithm
	 * processing execution.
	 * This function will be called when in_place is configured for
	 * processing the incoming buffers.
	 * In this function the input and output buffer is the same. That
	 * means that the results of the CUDA algorithm processing will directly
	 * modify the input buffer, so its original incoming data will be modified
	 * accordinlgy to the CUDA algorithm.
	 *
	 * Returns: true if process_ip is successfull, false otherwise.
	 */
	virtual bool process_ip (GstCudaData &io_buffer) = 0;

	virtual ~Filter() {};
      };
    };
  };
};

extern "C" {

     /**
      * factory_make:
      *
      * Return a newly allocated algorithm to be used by cudafilter
      *
      * Returns: A newly allocated algorithm to be used by cudafilter
      */
  G_MODULE_EXPORT Gst::Cuda::Algorithm::Filter * factory_make (void);
}

#endif //__GST_CUDA_ALGORITHM_FILTER_HPP_
