/*
 * Copyright (C) 2017 RidgeRun, LLC (http://www.ridgerun.com)
 * All Rights Reserved.
 *
 * The contents of this software are proprietary and confidential to RidgeRun,
 * LLC.  No part of this program may be photocopied, reproduced or translated
 * into another programming language without prior written consent of
 * RidgeRun, LLC.  The user is free to modify the source code after obtaining
 * a software license from RidgeRun.  All source code changes must be provided
 * back to RidgeRun without any encumbrance.
 */

#ifndef __GST_CUDA_BASE_FILTER_H__
#define __GST_CUDA_BASE_FILTER_H__

#include <gst/gst.h>
#include <gst/base/gstbasetransform.h>
#include "sys/cuda/gstcuda.h"

G_BEGIN_DECLS

#define GST_CUDA_BASE_TYPE_FILTER gst_cuda_base_filter_get_type ()

/**
 * GstCudaBaseFilter:
 *
 * The opaque #GstCudaBaseFilter data structure.
 */
G_DECLARE_DERIVABLE_TYPE(GstCudaBaseFilter, gst_cuda_base_filter, GST_CUDA_BASE, FILTER, GstBaseTransform)


/**
 * GstCudaBaseFilterClass:
 * @parent_class:   Element parent class
 * @start:          Optional.
 *                  Called when the element starts processing.
 *                  Allows opening external resources.
 * @stop:           Optional.
 *                  Called when the element stops processing.
 *                  Allows closing external resources.
 * @transform:      Required if the element does not operate in-place.
 *                  Transforms one incoming buffer to one outgoing buffer.
 *                  The method is allowed to change size/timestamp/duration
 *                  of the outgoing buffer.
 * @transform_ip:   Required if the element operates in-place.
 *                  Transform the incoming buffer in-place.
 *
 * Subclasses can override any of the available virtual methods or not, as
 * needed. At minimum either @transform or @transform_ip need to be overridden.
 * If the element can overwrite the input data with the results (data is of the
 * same type and quantity) it should provide @transform_ip.
 */
struct _GstCudaBaseFilterClass
{
  GstBaseTransformClass parent_class;

  /*< public >*/
  /* virtual methods for subclasses */
  gboolean      (*start)        (GstCudaBaseFilter *trans);

  gboolean      (*stop)         (GstCudaBaseFilter *trans);

  GstFlowReturn (*transform)    (GstCudaBaseFilter *trans, GstCudaData *in_data,
                                 GstCudaData *out_data);

  GstFlowReturn (*transform_ip) (GstCudaBaseFilter *trans, GstCudaData *data);
};


G_END_DECLS
#endif // __GST_CUDA_BASE_FILTER_H__
