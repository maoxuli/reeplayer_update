#ifndef __LIVE_CALIBRATOR_H__
#define __LIVE_CALIBRATOR_H__

#include <string>
#include <map>
#include <vector>
#include <deque>
#include <memory>
#include <atomic>
#include <thread>
#include <mutex>
#include <condition_variable>

#include <opencv2/core.hpp>
#include <opencv2/core/cuda.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/cudafeatures2d.hpp>
#include <opencv2/xfeatures2d.hpp>
#include <opencv2/xfeatures2d/cuda.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/stitching/detail/camera.hpp>

#include <videostitching/fast_matchers.h>
#include <videostitching/fast_estimators.h>
#include <videostitching/fast_warpers.h>

namespace videostitching {

class LiveCalibrator
{
public: 
    struct Settings 
    {
        std::string camera_params; // default camera params file 
        float detect_scale = -1; // down scale for input images (0,1) 
        int min_matches = 5; // min matches good for estimation 
        float hessian_threshold = 200; // for SURF
        float match_conf = 0.5f; // for SURF 
        float ransac_threshold = 3; // ransac reproj threshold [1,10]
        std::string ba_cost_func = "reproj";  // reproj | ray | no 
        float conf_thresh = 1.0f;
        std::string ba_refine_mask = "xxxxx";
        bool do_wave_correct = true;
        std::string warp_type = "spherical"; // shperical | cylindrical | plane

        Settings(const std::string& config = ""); 
        std::string to_string() const; 
    }; 

    LiveCalibrator(const Settings& settings = Settings());
    ~LiveCalibrator(); 

    bool detect(const std::vector<cv::Mat>& images, const std::string& id);
    bool visual_matches(const std::string& id, cv::Mat& output);

    void remove(const std::string& id); 
    cv::Mat visual_coverage(const std::string& id = "");

    bool estimate(cv::Mat& visual_matches);
    bool evaluate(const std::vector<cv::Mat>& images, cv::Mat& output); 
    bool camera_params(std::vector<cv::detail::CameraParams>& cameras, 
                       cv::Size& image_size);
    void reset(); 

    bool save(const std::string& camera_params = "");

private: 
    const int _num_cameras;
    Settings _settings; 
    
    cv::Size _input_size; 
    cv::Size _detect_size; // scaled down from input size 
    std::vector<cv::detail::CameraParams> _cameras;     
    std::vector<cv::Mat> _detect_masks; 
    std::vector<std::vector<cv::Mat> > _more_detect_masks; 

    void prepare(); 
    void initialize(const cv::Size& image_size); 
    void prepare_warping();

    // features finding and matching 
    cv::Ptr<cv::cuda::SURF_CUDA> _finder; 
    cv::Ptr<FastMatcher> _matcher; 

    // transform estimator 
    std::shared_ptr<Estimator> _estimator;
    std::shared_ptr<BundleAdjusterBase> _adjuster; 

    // blending for evaluation 
    std::vector<cv::Ptr<ProjectWarper> > _warpers;
    std::vector<cv::Rect> _warped_rects;
    std::vector<cv::Point> _warped_corners; 
    std::vector<cv::Size> _warped_sizes; 
    std::vector<cv::cuda::GpuMat> _warped_masks; 
    std::vector<cv::cuda::GpuMat> _warped_images;
    std::vector<cv::Rect> _crop_rects; 
    std::vector<cv::Rect> _output_rects;
    cv::cuda::GpuMat _output_image; 
    cv::Size _output_size;
    cv::Rect _output_roi; 

    bool features_detection(const std::vector<cv::Mat>& images, 
                            const std::vector<cv::Mat>& masks, 
                            std::vector<ImageFeatures>& features, 
                            MatchesInfo& matches_info); 

    void append_matches(std::vector<ImageFeatures>& all_features, 
                        MatchesInfo& all_matches_info, 
                        const std::vector<ImageFeatures>& features, 
                        const MatchesInfo& matches_info, 
                        std::set<std::pair<int,int> >& all_matches_set);

    bool prepare_matches(std::vector<ImageFeatures>& all_features, 
                         MatchesInfo& all_matches_info); 

    bool estimate_transform(std::vector<ImageFeatures>& features, 
                            MatchesInfo& matches_info, 
                            std::vector<cv::detail::CameraParams>& cameras); 

    struct Frame {
        std::vector<cv::Mat> images;
        std::vector<ImageFeatures> features; 
        MatchesInfo matches_info;
        cv::Mat visual_matches; 

        Frame() {}
        Frame(const std::vector<cv::Mat>& _images, 
              const std::vector<ImageFeatures>& _features, 
              const MatchesInfo& _matches_info, 
              const cv::Mat& _visual_matches) 
        : images(_images) 
        , features(_features)
        , matches_info(_matches_info)
        , visual_matches(_visual_matches)
        {
        } 
    }; 

    std::map<std::string, Frame> _frames; 
}; 

} // namespace videostitching 

#endif 
