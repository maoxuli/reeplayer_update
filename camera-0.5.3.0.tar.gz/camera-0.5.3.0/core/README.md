# Camera Core 

## Build camera-core library 

    ./build -ai  

The libraries and c/c++ header files are by default installed in /opt/reeplayer/camera/core. 

The installation package is camera-core-x.x.x.x.tar.gz. 

## Re-build videostitching library  

    cd videostitching 
    mkdir build 
    cd build 
    cmake .. 
    make 
    make  install 

## Re-build videostitcher library 

    cd videostitcher 
    mkdir build 
    cd build 
    cmake ..
    make 
    make install 
    