#ifndef __NVGST_SINK_BIN_H__
#define __NVGST_SINK_BIN_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <nvgstpipeline/nvgst_common.h>

typedef enum
{
  NVGST_SINK_FAKE,
  NVGST_SINK_RENDER_EGL,
  NVGST_SINK_RENDER_OVERLAY,
  NVGST_SINK_ENCODE_FILE,
  NVGST_SINK_ENCODE_UDP,
} NvGstSinkType;

typedef enum
{
  NVGST_CONTAINER_MP4 = 1,
  NVGST_CONTAINER_MKV
} NvGstContainerType;

typedef enum
{
  NVGST_ENCODER_H264 = 1,
  NVGST_ENCODER_H265,
  NVGST_ENCODER_VP8,
  NVGST_ENCODER_VP9, 
  NVGST_ENCODER_JPEG
} NvGstEncoderFormat;

typedef enum
{
  NVGST_ENCODER_TYPE_HW,
  NVGST_ENCODER_TYPE_SW
}NvGstEncoderType;

typedef struct
{
  NvGstSinkType type;
  gint width; 
  gint height; 
  gboolean sync;
  NvGstContainerType container;
  NvGstEncoderFormat codec;
  NvGstEncoderType enc_type;
  gint bitrate;
  guint profile;
  guint gpu_id;
  gchar *file_location;
  guint udp_port;
  guint rtsp_port;
  guint64 udp_buffer_size;
  guint iframeinterval;
  guint64 max_size_time;
  guint64 max_size_bytes;
  guint64 max_files;
} NvGstSinkEncoderConfig;

typedef struct
{
  NvGstSinkType type;
  gint width;
  gint height;
  gboolean sync;
  gboolean qos;
  gboolean qos_value_specified;
  guint gpu_id;
  guint nvbuf_memory_type;
  guint display_id;
  guint overlay_id;
  guint offset_x;
  guint offset_y;
} NvGstSinkRenderConfig;

typedef struct
{
  gboolean enable;
  NvGstSinkType type;
  NvGstSinkRenderConfig render_config;
  NvGstSinkEncoderConfig encoder_config;
} NvGstSinkConfig;

typedef struct
{
  GstElement *bin;
  GstElement *queue;
  GstElement *conv;
  GstElement *cap_filter;
  GstElement *enc_caps_filter;
  GstElement *encoder;
  GstElement *codecparse;
  GstElement *mux;
  GstElement *transform; 
  GstElement *sink;
  GstElement *rtppay;
  gulong sink_buffer_probe;
  // as sub bin of multi sink bin 
  GstElement *parent; 
  GstElement *tee; 
  GstPad *teepad;
} NvGstSinkBin;

typedef struct
{
  GstElement *bin;
  GstElement *queue;
  GstElement *conv;
  GstElement *conv_filter;
  GstElement *tee;
  NvGstSinkBin sub_bins[MAX_SINK_BINS];
  gint num_bins;
  GMutex lock;
} NvGstMultiSinkBin;

gboolean parse_sink_config (NvGstSinkConfig * config, 
  GKeyFile * key_file, gchar * group); 

gboolean create_multi_sink_bin (guint num_bins, 
  NvGstSinkConfig * config_array, NvGstMultiSinkBin * bin);
  
gboolean enable_sink (NvGstMultiSinkBin * bin, guint sink_idx);
gboolean disable_sink (NvGstMultiSinkBin * bin, guint sink_idx);
gboolean check_sink (NvGstMultiSinkBin * bin, guint sink_idx);

void destroy_multi_sink_bin (NvGstMultiSinkBin * bin);

#ifdef __cplusplus
}
#endif

#endif
