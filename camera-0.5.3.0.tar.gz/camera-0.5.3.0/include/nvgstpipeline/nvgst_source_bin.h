#ifndef __NVGST_SOURCE_BIN_H__
#define __NVGST_SOURCE_BIN_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <nvgstpipeline/nvgst_common.h>

typedef enum
{
  NVGST_SOURCE_CAMERA_CSI,
} NvGstSourceType;

typedef struct
{
  gboolean enable; 
  NvGstSourceType type;
  gint source_width;
  gint source_height;
  gint source_fps_n;
  gint source_fps_d;
  gint camera_csi_sensor_id;
  guint flip_method; 
  gdouble scale; 
  gchar *format; 
} NvGstSourceConfig;

typedef struct
{
  GstElement *bin;
  GstElement *src_elem;
  GstElement *src_filter;
  GstElement *conv;
  GstElement *conv_filter;
} NvGstSourceBin;

typedef struct 
{
  GstElement *bin;
  NvGstSourceBin sub_bins[MAX_SOURCE_BINS];
  guint num_bins; 
} NvGstMultiSourceBin;

gboolean parse_source_config (NvGstSourceConfig * config, 
  GKeyFile * key_file, gchar * group);

gboolean create_multi_source_bin (guint num_bins, 
  NvGstSourceConfig * config_array, NvGstMultiSourceBin * bin); 

#ifdef __cplusplus
}
#endif

#endif
