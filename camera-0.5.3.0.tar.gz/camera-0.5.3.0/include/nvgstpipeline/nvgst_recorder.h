#ifndef __NVGST_RECORDER_H__
#define __NVGST_RECORDER_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <nvgstpipeline/nvgst_common.h>
#include <nvgstpipeline/nvgst_source_bin.h>
#include <nvgstpipeline/nvgst_sink_bin.h>

typedef struct
{
  gboolean enable; 
  gchar *location;
  gchar *config; 
} NvGstStitcherConfig;

typedef struct
{
  gint render_sink; 
  gint streaming_sink; 
  gint recording_sink; 
  guint num_source_bins;
  guint num_sink_bins;
  NvGstSourceConfig multi_source_config[MAX_SOURCE_BINS];
  NvGstSinkConfig multi_sink_config[MAX_SINK_BINS];
  NvGstStitcherConfig stitcher_config;
} NvGstConfig;

typedef struct
{
  gboolean quit;
  gint return_value;

  GMutex app_lock;
  GCond app_cond;

  NvGstConfig config;

  guint bus_id;
  GstElement *pipeline;
  NvGstMultiSourceBin multi_source_bin; 
  NvGstMultiSinkBin multi_sink_bin; 
  GstElement *stitcher; 
} AppCtx;

gboolean parse_stitcher_config (NvGstStitcherConfig * config, GKeyFile * key_file, gchar * group);
gboolean parse_config_file (NvGstConfig * config, gchar * cfg_file);

gboolean create_pipeline (AppCtx * appCtx);
gboolean start_pipeline(AppCtx * appCtx); 
void stop_pipeline(AppCtx * appCtx); 
void destroy_pipeline (AppCtx * appCtx);

// sink commands and status 
gboolean set_recording_file(AppCtx * appCtx, gchar * filename); 
gboolean start_recording(AppCtx * appCtx); 
gboolean stop_recording(AppCtx * appCtx); 
gboolean check_recording(AppCtx * appCtx); 
gchar * get_recording_file(AppCtx * appCtx); 

gboolean start_streaming(AppCtx * appCtx); 
gboolean stop_streaming(AppCtx * appCtx); 
gboolean check_streaming(AppCtx * appCtx); 
gchar * get_streaming_url(AppCtx * appCtx); 

gboolean start_render(AppCtx * appCtx); 
gboolean stop_render(AppCtx * appCtx);
gboolean check_render(AppCtx * appCtx); 

// stitcher commands and status 
gchar * stitcher_command(AppCtx * appCtx, gchar * message);

#ifdef __cplusplus
}
#endif

#endif
