#!/usr/bin/env python

import socket 
import select 
import json 

# request = {"method": "shutdown_system"}
# request = {"method": "reboot_system"}
request = {"method": "config_power", "params": {"mode": 6}}
# request = {"method": "power_status"}
# request = {"method": "config_network", "params": {"wifi_ssid": "abcd", "wifi_password": "1234"}}
# request = {"method": "config_network", "params": {"ap_ip": "10.0.1.1/24"}}
# request = {"method": "network_status"}
# request = {"method": "config_software"}
# request = {"method": "download_software"}
# request = {"method": "install_software", "params": {"version": "1.1.1.1"}}
# request = {"method": "software_status"}
# request = {"method": "config_docker_image"}
# request = {"method": "pull_docker_image", "params": {}}
# request = {"method": "docker_image_status"}

RECV_BUFFER_SIZE = 1024
camerad_addr = ("127.0.0.1", 5050)
camerad_timeout = 10.0

json_request = json.dumps(request)
json_request += "\n"; # json string in line 

response = {}
conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try: 
    print("connect to {}".format(camerad_addr))
    conn.connect(camerad_addr)
    print("Send system request: {}".format(json_request))
    conn.sendall(json_request.encode())
    conn.setblocking(0)
    print("Waiting for response")
    rlist, _, _ = select.select([conn], [], [], camerad_timeout)
    if rlist: 
        assert rlist[0] == conn 
        json_response = conn.recv(RECV_BUFFER_SIZE).decode()
        print("Received response: {}".format(json_response))
        response = json.loads(json_response)
    else: 
        print("Response timeout!")
        response["error"] = {"code": -1, "message": "Response timeout"}   
except socket.error, msg:
    print("Socket exception: {}".format(msg))
    response["error"] = {"code": -1, "message": "Socket exception: {}".format(msg)}
except: 
    print("Exception")
    response["error"] = {"code": -1, "message": "Exception handle system request"}
conn.close() 
print("response: {}".format(response))