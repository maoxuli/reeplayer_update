#!/bin/bash

## install the camera system software 
## log necessary information 

echo "$(date +"%Y-%m-%d %T"): install camera system..."

## the script is in camera dir or version package dir   
CAMERA_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "CAMERA_DIR: ${CAMERA_DIR}" 

## if in version package dir, create symbal link     
VERSION="$( basename "${CAMERA_DIR}" )"
# echo "VERSION: ${VERSION}"
if [ "${VERSION}" != "camera" ] ; then 
  VERSION_DIR="${CAMERA_DIR}"
  CAMERA_DIR="$( readlink -m "${VERSION_DIR}/.." )/camera"
  echo "create symbal link: ${CAMERA_DIR} -> ${VERSION_DIR}"
  ln -snfr "${VERSION_DIR}" "${CAMERA_DIR}"
fi 

## install systemd service 
. ${CAMERA_DIR}/scripts/service.sh install 

echo "$(date +"%Y-%m-%d %T"): install camera system done!"
