// ROS bridge connection 
function CameraConnection(callback_error, callback_connected, callback_close) {
    this.ros = new ROSLIB.Ros();

    this.ros.on('error', function(error) {
        callback_error(error);
    });

    this.ros.on('connection', function() {
        callback_connected();
    });

    this.ros.on('close', function() {
        callback_close();
    });

    this.connect = function(hostname) {
        var service_url = 'ws://' + hostname + ":9090";
        this.ros.connect(service_url); 
    }

    this.connected = function() {
        return this.ros.isConnected(); 
    }
}

// ROS status topic  
function CameraStatus(connection) {
    var status_topic = new ROSLIB.Topic({
        ros : connection.ros,
        name : 'camera_status',
        messageType : 'std_msgs/String'
    });

    this.subscribe = function(callback_status) {
        status_topic.subscribe(function(message) {
            callback_status(JSON.parse(message.data));  
        });
    }
}

// Camera node RPC  
function Camera(connection) {
    var rpcService = new ROSLIB.Service({
        ros : connection.ros,
        name : 'camera/rpc_service',
        serviceType : 'camera/JsonService'
    });

    var rpcService2 = new ROSLIB.Service({
        ros : connection.ros,
        name : 'cam_status/rpc_service',
        serviceType : 'camera/JsonService'
    });

    var rpcRequest = new ROSLIB.ServiceRequest({
        data : "" 
    });

    var id = 1; 

    this.call_rpc_service = function(request, callback_success, callback_error) {
        request.jsonrpc = "2.0"
        request.id = id++; 
        rpcRequest.data = JSON.stringify(request); 
        rpcService.callService(rpcRequest, function(rpcResponse) {
            response = JSON.parse(rpcResponse.data);
            if (response.hasOwnProperty("result")) {
                var id = response.hasOwnProperty("id") ? response.id : null
                callback_success(id, response.result); 
            }
            else if (response.hasOwnProperty("error")) {
                if (callback_error != null)
                    callback_error(response.error.code, response.error.message);
            }
            else {
                if (callback_error != null)
                    callback_error(-32001, "Invalid RPC response: " + response);
            }
        });
        return id - 1; 
    }

    this.call_rpc_service2 = function(request, callback_success, callback_error) {
        request.jsonrpc = "2.0"
        request.id = id++; 
        rpcRequest.data = JSON.stringify(request); 
        rpcService2.callService(rpcRequest, function(rpcResponse) {
            response = JSON.parse(rpcResponse.data);
            if (response.hasOwnProperty("result")) {
                var id = response.hasOwnProperty("id") ? response.id : null
                callback_success(id, response.result); 
            }
            else if (response.hasOwnProperty("error")) {
                if (callback_error != null)
                    callback_error(response.error.code, response.error.message);
            }
            else {
                if (callback_error != null)
                    callback_error(-32001, "Invalid RPC response: " + response);
            }
        });
        return id - 1; 
    }
}

// power management 
Camera.prototype.shutdown_system = function(callback_success, callback_error) {
    var request = {"method": "shutdown_system"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.reboot_system = function(callback_success, callback_error) {
    var request = {"method": "reboot_system"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.config_power = function(params, callback_success, callback_error) {
    var request = {"method": "config_power", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.power_status = function(callback_success, callback_error) {
    var request = {"method": "power_status"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// network configuration 
Camera.prototype.config_network = function(params, callback_success, callback_error) {
    var request = {"method": "config_network", "params": params};
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.network_status = function(callback_success, callback_error) {
    var request = {"method": "network_status"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// software update 
Camera.prototype.config_update = function(params, callback_success, callback_error) {
    var request = {"method": "config_update", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.download_update = function(version, callback_success, callback_error) {
    var request = {"method": "download_update", "params": {"version": version}}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.install_update = function(version, callback_success, callback_error) {
    var request = {"method": "install_update", "params": {"version": version}}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.update_status = function(callback_success, callback_error) {
    var request = {"method": "update_status"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// docker image update 
Camera.prototype.config_docker = function(params, callback_success, callback_error) {
    var request = {"method": "config_docker", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.pull_docker = function(params, callback_success, callback_error) {
    var request = {"method": "pull_docker", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.docker_status = function(callback_success, callback_error) {
    var request = {"method": "docker_status"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// storage status 
Camera.prototype.storage_status = function(callback_success, callback_error) {
    var request = {"method": "storage_status"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// battery status 
Camera.prototype.battery_status = function(callback_success, callback_error) {
    var request = {"method": "battery_status"}; 
    return this.call_rpc_service2(request, callback_success, callback_error); 
};

// cpu status 
Camera.prototype.cpu_status = function(callback_success, callback_error) {
    var request = {"method": "cpu_status"}; 
    return this.call_rpc_service2(request, callback_success, callback_error); 
};

// video file list status 
Camera.prototype.list_status = function(callback_success, callback_error) {
    var request = {"method": "list_status"}; 
    return this.call_rpc_service2(request, callback_success, callback_error); 
};

// Recorder node RPC 
function Recorder(connection) {
    var rpcService = new ROSLIB.Service({
        ros : connection.ros,
        name : 'recorder/rpc_service',
        serviceType : 'camera/JsonService'
    });

    var rpcRequest = new ROSLIB.ServiceRequest({
        data : "" 
    });

    var id = 1; 

    this.call_rpc_service = function(request, callback_success, callback_error) {
        request.jsonrpc = "2.0"
        request.id = id++; 
        rpcRequest.data = JSON.stringify(request); 
        rpcService.callService(rpcRequest, function(rpcResponse) {
            response = JSON.parse(rpcResponse.data);
            if (response.hasOwnProperty("result")) {
                var id = response.hasOwnProperty("id") ? response.id : null
                callback_success(id, response.result); 
            }
            else if (response.hasOwnProperty("error")) {
                if (callback_error != null)
                    callback_error(response.error.code, response.error.message);
            }
            else {
                if (callback_error != null)
                    callback_error(-32001, "Invalid RPC response: " + response);
            }
        });
        return id - 1; 
    }
}

Recorder.prototype.enable_recording = function(callback_success, callback_error) {
    var request = {"method": "enable_recording"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.disable_recording = function(callback_success, callback_error) {
    var request = {"method": "disable_recording"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.config_recording = function(params, callback_success, callback_error) {
    var request = {"method": "config_recording", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.start_recording = function(callback_success, callback_error) {
    var request = {"method": "start_recording"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.stop_recording = function(callback_success, callback_error) {
    var request = {"method": "stop_recording"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.recording_status = function(callback_success, callback_error) {
    var request = {"method": "recording_status"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
}; 

Recorder.prototype.enable_streaming = function(callback_success, callback_error) {
    var request = {"method": "enable_streaming"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.disable_streaming = function(callback_success, callback_error) {
    var request = {"method": "disable_streaming"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.streaming_status = function(callback_success, callback_error) {
    var request = {"method": "streaming_status"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
}; 

Recorder.prototype.config_stitching = function(params, callback_success, callback_error) {
    var request = {"method": "config_stitching", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.stitching_status = function(callback_success, callback_error) {
    var request = {"method": "stitching_status"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
}; 

Recorder.prototype.config_capture = function(params, callback_success, callback_error) {
    var request = {"method": "config_capture", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.capture_status = function(callback_success, callback_error) {
    var request = {"method": "capture_status"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
}; 

// Calibrator node RPC 
function Calibrator(connection) {
    var rpcService = new ROSLIB.Service({
        ros : connection.ros,
        name : 'calibrator/rpc_service',
        serviceType : 'camera/JsonService'
    });

    var rpcRequest = new ROSLIB.ServiceRequest({
        data : "" 
    });

    var id = 1; 

    this.call_rpc_service = function(request, callback_success, callback_error) {
        request.jsonrpc = "2.0"
        request.id = id++; 
        rpcRequest.data = JSON.stringify(request); 
        rpcService.callService(rpcRequest, function(rpcResponse) {
            response = JSON.parse(rpcResponse.data);
            if (response.hasOwnProperty("result")) {
                var id = response.hasOwnProperty("id") ? response.id : null
                callback_success(id, response.result); 
            }
            else if (response.hasOwnProperty("error")) {
                if (callback_error != null)
                    callback_error(response.error.code, response.error.message);
            }
            else {
                if (callback_error != null)
                    callback_error(-32001, "Invalid RPC response: " + response);
            }
        });
        return id - 1; 
    }
}

Calibrator.prototype.enable_calibration = function(callback_success, callback_error) {
    var request = {"method": "enable_calibration"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.disable_calibration = function(callback_success, callback_error) {
    var request = {"method": "disable_calibration"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.config_calibration = function(params, callback_success, callback_error) {
    var request = {"method": "config_calibration", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.calib_next = function(callback_success, callback_error) {
    var request = {"method": "calib_next"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.calib_prev = function(callback_success, callback_error) {
    var request = {"method": "calib_prev"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.calib_frame = function(id, callback_success, callback_error) {
    var request = {"method": "calib_frame", "params": {"id": id}}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.calib_detect = function(callback_success, callback_error) {
    var request = {"method": "calib_detect"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.calib_remove = function(id, callback_success, callback_error) {
    var request = {"method": "calib_remove", "params": {"id": id}}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.estimate_calibration = function(callback_success, callback_error) {
    var request = {"method": "estimate_calibration"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.reset_calibration = function(callback_success, callback_error) {
    var request = {"method": "reset_calibration"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.save_calibration = function(callback_success, callback_error) {
    var request = {"method": "save_calibration"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.calibration_status = function(callback_success, callback_error) {
    var request = {"method": "calibration_status"};  
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// Uploader node RPC 
function Uploader(connection) {
    var rpcService = new ROSLIB.Service({
        ros : connection.ros,
        name : 'uploader/rpc_service',
        serviceType : 'camera/JsonService'
    });

    var rpcRequest = new ROSLIB.ServiceRequest({
        data : "" 
    });

    var id = 1; 

    this.call_rpc_service = function(request, callback_success, callback_error) {
        request.jsonrpc = "2.0"
        request.id = id++; 
        rpcRequest.data = JSON.stringify(request); 
        rpcService.callService(rpcRequest, function(rpcResponse) {
            response = JSON.parse(rpcResponse.data);
            if (response.hasOwnProperty("result")) {
                var id = response.hasOwnProperty("id") ? response.id : null
                callback_success(id, response.result); 
            }
            else if (response.hasOwnProperty("error")) {
                if (callback_error != null)
                    callback_error(response.error.code, response.error.message);
            }
            else {
                if (callback_error != null)
                    callback_error(-32001, "Invalid RPC response: " + response);
            }
        });
        return id - 1; 
    }
}

Uploader.prototype.enable_uploading = function(callback_success, callback_error) {
    var request = {"method": "enable_uploading"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Uploader.prototype.disable_uploading = function(callback_success, callback_error) {
    var request = {"method": "disable_uploading"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Uploader.prototype.config_uploading = function(params, callback_success, callback_error) {
    var request = {"method": "config_uploading", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Uploader.prototype.uploading_status = function(callback_success, callback_error) {
    var request = {"method": "uploading_status"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};
