#!/usr/bin/env bash

set -e 

## This script launch camera node with settings 
## run as the entry command of the docker container 

if [ "$USER" == "root" ]; then 
  echo "Supposed to run with non-root user!"
  exit 1
fi 

SCRIPTS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "SCRIPTS_DIR: ${SCRIPTS_DIR}" 

## load setup is exists 
SETUP_SCRIPT="${SCRIPTS_DIR}/setup.sh"
if [ -f "${SETUP_SCRIPT}" ]; then
  . "${SETUP_SCRIPT}" load
else 
  echo "Not found ${SETUP_SCRIPT}"
fi 

if [ -z "${CAMERA_LOG_DIR}" ]; then 
  echo "CAMERA_LOG_DIR is not set, using default!"
  CAMERA_LOG_DIR="camera_log"
fi 
CAMERA_LOG_DIR="$HOME/${CAMERA_LOG_DIR}"
echo "CAMERA_LOG_DIR: ${CAMERA_LOG_DIR}"
mkdir -p ${CAMERA_LOG_DIR}

CAMERA_LOG="${CAMERA_LOG_DIR}/camera.log"
echo "CAMERA_LOG: ${CAMERA_LOG}" 

if [ -z "${CAMERA_ROS}" ]; then 
  echo "CAMERA_ROS is not set, using default!"
  CAMERA_ROS="ros"
fi 
CAMERA_ROS="$(cd "${SCRIPTS_DIR}/.." && pwd)/${CAMERA_ROS}"
if [ ! -d "${CAMERA_ROS}" ]; then 
  CAMERA_ROS="$(cd "${SCRIPTS_DIR}/../.." && pwd)/camera_ros/devel"
fi 
echo "CAMERA_ROS: ${CAMERA_ROS}"
. ${CAMERA_ROS}/setup.sh 

CAMERA_ARGS="respawn:=true"
echo "CAMERA_ARGS: ${CAMERA_ARGS}"

## use exec to force roslaunch as the foreground process 
echo "exec roslaunch camera camera.launch ${CAMERA_ARGS} >> ${CAMERA_LOG} 2>&1"
exec roslaunch camera camera.launch ${CAMERA_ARGS} >> ${CAMERA_LOG} 2>&1
