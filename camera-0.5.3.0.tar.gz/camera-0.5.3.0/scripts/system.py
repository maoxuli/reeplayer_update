#!/usr/bin/env python

## This script is run by camerad.service to receive 
## message from camerad.socket, and handle the request.
## the request/response follows JSON-RPC 2.0 specification 

import sys
import time
import socket
import json 
import os
import subprocess

## JSON-RPC 2.0  
JSON_PARSE_ERROR = -32700
RPC_INVALID_REQUEST = -32600
RPC_METHOD_NOT_FOUND = -32601
RPC_INVALID_PARAMS = -32602
RPC_INTERNAL_ERROR = -32603
RPC_SERVER_ERROR = -32000

jsonrpc_error_messages = dict([
    (JSON_PARSE_ERROR, "Invalid JSON was received by the server"),
    (RPC_INVALID_REQUEST, "The JSON sent is not a valid Request object"),
    (RPC_METHOD_NOT_FOUND, "The method does not exist / is not available"),
    (RPC_INVALID_PARAMS, "Invalid method parameter(s)"),
    (RPC_INTERNAL_ERROR, "Internal JSON-RPC error"),
    (RPC_SERVER_ERROR, "General server error"),
])

def get_error_message(code): 
    if code not in jsonrpc_error_messages: 
        return ""
    return jsonrpc_error_messages[code]

def jsonrpc_wrap_error(request, code, message): 
    response = {"jsonrpc": 2.0, "error": {"code": code, "message": message}} 
    if request is not None and "id" in request: 
        response["id"] = request["id"]
    return response 

def jsonrpc_wrap_result(request, result): 
    response = {"jsonrpc": 2.0, "result": result} 
    if request is not None and "id" in request: 
        response["id"] = request["id"]
    return response 

## validate a single JSON-RPC 2.0 request object 
def validate_request_fields(request):
    ## be a dictionary 
    if not isinstance(request, dict): 
        print("request is not a dict object")
        return False 
    ## be jsonrpc 2.0 object 
    # if "jsonrpc" not in request or request["jsonrpc"] != "2.0": # be jsonrpc 2.0 object 
    #     return false
    ## method exists 
    if not ("method" in request and isinstance(request["method"], basestring)): 
        return False 
    ## id is integer, string, or None if it exists 
    if "id" in request and not (isinstance(request["id"], int) or isinstance(request["id"], basestring) or request["id"] is None): 
        print("Invalid id")
        return False
    ## params is dict, list, or None if it exists 
    if "params" in request and not (isinstance(request["params"], dict) or isinstance(request["params"], list) or request["params"] is None): 
        print("Invalid params")
        return False 
    return True  

SHELL = "bash"
SCRIPTS_DIR = os.path.dirname(os.path.realpath(__file__))

## run script with command and arguments 
def run_shell_script(script, command, args=[]): 
    arguments = [SHELL, "{}/{}".format(SCRIPTS_DIR, script), command]
    arguments += args 
    print("shell input: {}".format(arguments))
    try:
        message = subprocess.check_output(arguments, stderr=subprocess.STDOUT).decode('utf-8')
        print("shell output: " + message)
        return True, message
    except subprocess.CalledProcessError as e:
        return False, e.output.decode()
    except Exception as e:
        # check_call can raise other exceptions, such as FileNotFoundError
        return False, str(e)
    
## shutdown system 
def shutdown_system(request): 
    print("shutdown system")
    success, message = run_shell_script("power.sh", "shutdown")
    if not success: 
        return jsonrpc_wrap_error(request, RPC_SERVER_ERROR, message)
    return jsonrpc_wrap_result(request, True)    

## reboot system 
def reboot_system(request): 
    print("reboot system")
    success, message = run_shell_script("power.sh", "reboot")
    if not success: 
        return jsonrpc_wrap_error(request, RPC_SERVER_ERROR, message)
    return jsonrpc_wrap_result(request, True)         

## config power mode 
def config_power(request): 
    print("config power mode")
    params = request["params"]
    if "mode" in params: 
        args = [str(params["mode"])]
        success, message = run_shell_script("power.sh", "set_mode", args)
        if not success: 
            return jsonrpc_wrap_error(request, RPC_SERVER_ERROR, message)
    return jsonrpc_wrap_result(request, True) 

## get power status 
def power_status(request): 
    print("power status")
    result = {"mode": 0, "rebooting": False}
    return jsonrpc_wrap_result(request, result) 

## config network 
def config_network(request): 
    print("config network")
    params = request["params"]            
    if "wifi_ssid" in params and "wifi_password" in params: 
        args = [str(params["wifi_ssid"]), str(params["wifi_password"])]
        success, message = run_shell_script("network.sh", "set_wifi_id", args)
        if not success: 
            return jsonrpc_wrap_error(request, RPC_SERVER_ERROR, message)
    if "ap_ip" in params: 
        args = [str(params["ap_ip"])]
        success, message = run_shell_script("network.sh", "set_ap_ip", args)
        if not success: 
            return jsonrpc_wrap_error(request, RPC_SERVER_ERROR, message)
    return jsonrpc_wrap_result(request, True) 

## get network status 
def network_status(request): 
    print("network status")
    result = {"wifi_connected": True, "wifi_ssid": "abcd", "ap_id": "10.0.1.1", "eth_dhcp": True}
    return jsonrpc_wrap_result(request, result) 

## config for software update
def config_software(request): 
    print("config software")
    params = request["params"]
    return jsonrpc_wrap_result(request, True) 

## download updated software 
def download_software(request): 
    print("download software")
    args = []
    if "params" in request and "version" in request["params"]["version"]: 
        args = [str(request["params"]["version"])]
    success, message = run_shell_script("software.sh", "download", args)
    if not success: 
        return jsonrpc_wrap_error(request, RPC_SERVER_ERROR, message)
    return jsonrpc_wrap_result(request, True) 

## install updated software 
def install_software(request): 
    print("install software")
    args = []
    if "params" in request and "version" in request["params"]["version"]: 
        args = [str(request["params"]["version"])]
    success, message = run_shell_script("software.sh", "install", args)
    if not success: 
        return jsonrpc_wrap_error(request, RPC_SERVER_ERROR, message)
    return jsonrpc_wrap_result(request, True) 

## get software update status 
def software_status(request): 
    print("software status")
    result = {"current": "0.0.0.0", "downloaded": "0.1.0.0", "latest": "0.2.0.0"}
    return jsonrpc_wrap_result(request, result) 

## config for docker image update 
def config_docker_image(request): 
    print("config docker update")
    params = request["params"]
    return jsonrpc_wrap_result(request, True) 

## pull docker image  
def pull_docker_image(request): 
    print("pull docker image")
    return jsonrpc_wrap_result(request, True) 

## docker image updata status 
def docker_image_status(request): 
    print("docker image status")
    result = {}
    return jsonrpc_wrap_result(request, result) 

## service handlers 
## method: handler 
service_handlers = {
    "shutdown_system": shutdown_system,
    "reboot_system": reboot_system,
    "config_power": config_power, 
    "power_status": power_status, 
    "config_network": config_network, 
    "network_status": network_status,
    "config_software": config_software, 
    "download_software": download_software, 
    "install_software": install_software, 
    "software_status": software_status, 
    "config_docker_image": config_docker_image,
    "pull_docker_image": pull_docker_image, 
    "docker_image_status": docker_image_status
}

## process request 
def process_request(request): 
    print("process request: {}".format(request))
    method = request["method"]
    if method in service_handlers: 
        try: 
            return service_handlers[method](request)
        except KeyError: 
            return jsonrpc_wrap_error(request, RPC_INVALID_PARAMS, get_error_message(RPC_INVALID_PARAMS))
    else: 
        return jsonrpc_wrap_error(request, RPC_METHOD_NOT_FOUND, get_error_message(RPC_METHOD_NOT_FOUND))

## handle single request 
def handle_single_request(request): 
    print("handle single request: {}".format(request))
    if validate_request_fields(request): 
        return process_request(request)
    else: 
        return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, get_error_message(RPC_INVALID_REQUEST))

## handle batch request 
def handle_batch_request(request): 
    print("handle batch request: {}".format(request))
    if len(request) == 0: 
        return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, get_error_message(RPC_INVALID_REQUEST))
    else: 
        response = [] 
        for requ in request: 
            resp = handle_single_request(requ); 
            response.append(resp)
        return response

## handle JSON-RPC 2.0 request 
def handle_json_request(request): 
    print("handle json request: {}".format(request))
    if isinstance(request, list): 
        return handle_batch_request(request)
    elif isinstance(request, dict): 
        return handle_single_request(request)
    else: 
        return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, get_error_message(RPC_INVALID_REQUEST)); 

## JSON string, request and response message
def handle_request_message(request_message): 
    print("Handle request message: {}".format(request_message))
    json_response = {}
    try: 
        json_request = json.loads(request_message)
        # print("Request: {}".format(json_request))
        json_response = handle_json_request(json_request)
    except: 
        json_response = jsonrpc_wrap_error(None, JSON_PARSE_ERROR, get_error_message(JSON_PARSE_ERROR))
    return json.dumps(json_response)


RECV_BUFFER_SIZE = 1024 

## life cycle of a connection 
def connection_handler(conn):   
    if conn:
        while True: 
            try: 
                message = conn.recv(RECV_BUFFER_SIZE).decode()
                if message: 
                    print("Request message: {}".format(message))
                    request_message = message.splitlines()[0]
                    response_message = handle_request_message(request_message)
                    response_message += "\n" # json string in line 
                    print("Response message: {}".format(response_message))
                    conn.sendall(response_message.encode())
                else: 
                    print("Peer disconnected")
                    break
            except socket.error, msg: 
                print("Socket exception: {}".format(msg))
                break 
            except:
                print("Exception")
                break
        print("Close connection")
        conn.close()


## run a TCP server for testing 
def test(port): 
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(('0.0.0.0', port))
    print("Listen on ", port)
    s.listen(5)
    try: 
        while True: 
            conn, addr = s.accept()
            connection_handler(conn)
        s.close()
    except KeyboardInterrupt: 
        pass 


if __name__ == "__main__":
    if len(sys.argv) > 1: 
        test(int(sys.argv[1]))
    else: 
        conn = socket.fromfd(sys.stdin.fileno(), socket.AF_INET, socket.SOCK_STREAM)
        connection_handler(conn)
