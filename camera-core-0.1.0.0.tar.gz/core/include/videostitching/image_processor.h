#ifndef IMAGE_PROCESSOR_H 
#define IMAGE_PROCESSOR_H 

#include <opencv2/opencv.hpp> 

namespace videostitching {

class ImageProcessor 
{
public: 
    virtual ~ImageProcessor() {}

    virtual cv::Size output_size() const = 0; 

	virtual bool process(const std::vector<cv::cuda::GpuMat>& in_mats, cv::cuda::GpuMat& out_mat, 
                         cv::cuda::Stream& stream = cv::cuda::Stream::Null()) = 0; 
}; 

} // namespace videostitching 

#endif 
