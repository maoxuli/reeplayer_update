#ifndef __CAMERAS_CALIBRATION_H__
#define __CAMERAS_CALIBRATION_H__

#include <string>
#include <vector>
#include <memory>

#include <opencv2/core.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/stitching/detail/camera.hpp>

namespace videostitching {

// we define a unifrom interface for all calibrations on multi-cameras, 
// includes the geometric (intrinsic and extrinsic) calibration, the color 
// calibration, the vegnetting calibration, and so on. 
// the idea is passing in the images from all cameras at once, and output 
// a single image for display. Some state information will be overlayed on 
// the output image so user can take action according to the state. 
// all actions are passed in by a command string, so adapt to different 
// implemenations. 

class CamerasCalibrator 
{
public: 
    virtual ~CamerasCalibrator() {}

    // output size may be fixed size, which means the output images are in 
    // the exact size, or may be a max size, which mean the output images 
    // are in a variable size but always less than the given size.  
    // (0,0) means the output is in arbitrary size.  
    virtual cv::Size output_size() = 0; 

    // output size may be changed in run-time 
    typedef std::function<void (const cv::Size&)> OutputSizeCallback;
    virtual void set_output_size_callback(const OutputSizeCallback& cb) = 0; 

    // update the calib process by a new input, the output image is for display. 
    // return value may be varid for functions, but 0 means normal state. 
    // negative values for errors, and positive value for other special state. 
    // virtual int update(cv::InputArray in_images, cv::OutputArray out_image) = 0;
    virtual int update(const std::vector<cv::cuda::GpuMat>& in_images, cv::cuda::GpuMat& out_image) = 0; 

    // the control of the calib process is done by commands
    // the format of commands is specific to functions and implementations.  
    virtual bool calib_command(const std::string& command) = 0; 
}; 

bool save_camera_info(const std::string& filepath,
                      const cv::Mat& K, const cv::Mat& D, const cv::Size& image_size, 
                      float avg_error = 0, int flags = 0, float aspect_ratio = 1.0);

bool load_camera_info(const std::string& filepath, 
                      cv::Mat& K, cv::Mat& D, cv::Size& image_size, 
                      float& avg_error, int& flags, float& aspect_ratio);

bool load_camera_info(const std::string& filepath, 
                      cv::Mat& K, cv::Mat& D, cv::Size& image_size);

bool save_camera_params(const std::string& filepath, 
                        const cv::detail::CameraParams& camera_params,
                        const cv::Size& image_size);

bool load_camera_params(const std::string& filepath, 
                        cv::detail::CameraParams& camera_params, 
                        cv::Size& image_size);

} // namespace videostitching 

#endif 
