#ifndef __LIVE_ESTIMATOR_H__
#define __LIVE_ESTIMATOR_H__

#include <string>
#include <vector>
#include <memory>
#include <atomic>
#include <thread>
#include <mutex>
#include <condition_variable>

#include <opencv2/core.hpp>
#include <opencv2/core/cuda.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/cudafeatures2d.hpp>
#include <opencv2/xfeatures2d.hpp>
#include <opencv2/xfeatures2d/cuda.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/stitching/detail/camera.hpp>

#include "fast_matchers.h"
#include "fast_estimators.h"
#include "fast_warpers.h"

namespace videostitching {

class LiveEstimator
{
public: 
    struct Settings 
    {
        int num_cameras = 2; 
        cv::Size image_size; 
        std::vector<std::string> cameras_info; 
        std::string cameras_calib; 
        std::string warp_type = "spherical"; // shperical | cylindrical 
        bool visual_matches = true; 
        bool visual_detection = true; 
        int mode = 0; // 0=auto 1=trigger
        float detect_scale = -1; // down scale for input images  
        int detect_pattern = 0; // 0=SURF 1=chessboard 
        int min_matches = 10; // min matches good for estimation 
        float hessian_threshold = 200; // for SURF
        float match_conf = 0.2f; // for SURF 
        cv::Size board_size = cv::Size(8,5); // for chessboard 
        std::string ba_cost_func = "ray";  // reproj | ray | no 
        float conf_thresh = 1.f;
        std::string ba_refine_mask = "xxxxx";
        bool do_wave_correct = true;

        Settings() {}
    };

    LiveEstimator(const Settings& = Settings());
    ~LiveEstimator(); 

    void reset(); 
    bool trigger(int next_mode = 1); 
    bool save(const std::string& cameras_calib = ""); 

    void update(const std::vector<cv::cuda::GpuMat>& in_images, cv::cuda::GpuMat& out_image); 

private: 
    Settings _settings; 
    int _num_cameras;

    // correction warping 
    void prepare_correction(); 
    std::vector<cv::Ptr<RectifyWarper> > _correct_warpers; 
    std::vector<cv::cuda::GpuMat> _corrected_images; 
    std::vector<cv::Rect> _corrected_rects; 
    std::vector<cv::Size> _corrected_sizes; 

    // projection warping 
    void prepare_projection();
    std::vector<cv::detail::CameraParams> _init_cameras; 

    void update_projection(const std::vector<cv::detail::CameraParams>& cameras);  
    std::vector<cv::Ptr<ProjectWarper> > _project_warpers;
    std::vector<cv::cuda::GpuMat> _warped_masks; 
    std::vector<cv::Rect> _warped_rects;
    std::vector<cv::Point> _warped_corners; 
    std::vector<cv::Size> _warped_sizes; 
    std::vector<cv::cuda::GpuMat> _warped_images;
    cv::Size _out_size; 

    // blending 
    void update_blending(); 
    std::vector<cv::Rect> _blend_rects; 
    std::vector<cv::Point> _blend_corners;
    std::vector<cv::Size> _blend_sizes; 
    std::vector<cv::cuda::GpuMat> _blend_masks;
    std::vector<cv::cuda::GpuMat> _blend_alphas;  
    std::vector<cv::cuda::GpuMat> _blend_images; 
    cv::cuda::GpuMat _blended_image; 
    cv::Rect _blended_rect; 
    bool _blending; 

    // features detection 
    void prepare_detection(); 
    cv::Ptr<cv::cuda::SURF_CUDA> _finder; 
    std::shared_ptr<FastMatcher> _matcher; 
    std::vector<cv::Size> _detect_sizes; 
    std::vector<cv::cuda::GpuMat> _detect_masks; 

    bool detect_features(); 
    std::vector<cv::cuda::GpuMat> _gray_images; 
    std::vector<cv::cuda::GpuMat> _scaled_images; 
    std::vector<cv::Mat> _cpu_images; 

    void surf_detection(const std::vector<cv::cuda::GpuMat>& cuda_images, 
        std::vector<ImageFeatures>& features, MatchesInfo& matches_info); 

    void chessboard_detection(const std::vector<cv::cuda::GpuMat>& cuda_images, 
        std::vector<ImageFeatures>& features, MatchesInfo& matches_info);

    std::vector<ImageFeatures> _features; 
    MatchesInfo _matches_info; 
    std::set<std::pair<int,int> > _matches_set;  
    std::vector<cv::Mat> _overlay_images; 

    // transform estimation  
    void prepare_estimation(); 
    std::shared_ptr<Estimator> _estimator;
    std::shared_ptr<BundleAdjusterBase> _adjuster; 

    void estimate_transform(); 
    std::vector<cv::detail::CameraParams> _cameras; 

    // calib thread 
    void calib_thread(); 
    std::thread _calib_thread; 
    std::atomic<bool> _calibrating; 
    std::vector<cv::cuda::GpuMat> _calib_queue; 
    bool _queue_empty; 
    std::mutex _calib_mutex; 
    std::condition_variable _calib_condition; 
    std::mutex _update_mutex; 
}; 

} // namespace videostitching 

#endif 
