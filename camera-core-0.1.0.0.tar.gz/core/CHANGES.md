## [0.1.0] - 2021-01-14
- GStreamer plugin for video stitching
- The library for video stitching algorithms   
