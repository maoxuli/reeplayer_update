# Camera

The software system for camera device. 

## Build and create installation package 

    build.sh -ai 

## Install the software system 

    install.sh 
    uninstall.sh 
    