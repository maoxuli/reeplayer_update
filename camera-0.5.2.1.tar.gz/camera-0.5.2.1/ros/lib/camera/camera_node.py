#! /usr/bin/env python

import os 
import time
import threading
import json
import socket 
import select 
import rospy
from camera.srv import JsonMessage, JsonMessageResponse
from std_msgs.msg import String as JsonString

## fake number 
free_space = 20

## Camera node object
class CameraNode(object): 
    RECV_BUFFER_SIZE = 1024 

    def __init__(self): 
        ## parameters 
        self.update_rate = rospy.get_param("~state_update_rate", 1.0)
        self.update_rate = self.update_rate if self.update_rate > 0 else 1.0
        rospy.loginfo("state update rate: {}".format(self.update_rate))

        camerad_port = rospy.get_param("~camerad_port", "6666")
        rospy.loginfo("camerad socket port: {}".format(camerad_port))
        self.camerad_addr = ('127.0.0.1', camerad_port)

        self.camerad_timeout = rospy.get_param("~camerad_timeout", "10.0")
        rospy.loginfo("camerad socket timeout: {}".format(self.camerad_timeout))

        ## control dispatch
        ## target : handler 
        self.control_dispatch = {
            'system': self.control_system,
        }

        ## control service 
        control_service = "control"
        rospy.loginfo("Starting service: {}".format(control_service))
        rospy.Service(control_service, JsonMessage, self.control_service_handler)

        ## state check dispatch 
        ## taget : handler 
        self.check_dispatch = {
            'system': self.check_system, 
            'storage': self.check_storage,
            # 'battery': self.check_battery,
            # 'temperature': self.check_temperature,
        }

        ## state check service 
        check_service = "check"
        rospy.loginfo("Starting service: {}".format(check_service))
        rospy.Service(check_service, JsonMessage, self.check_service_handler)

        ## state topic 
        state_topic = "state" 
        rospy.loginfo("Advertise topic: {}".format(state_topic))
        self.state_pub = rospy.Publisher(state_topic, JsonString, queue_size=2)

        ## check and publish state in a thead 
        state_thread = threading.Thread(target=self.state_update_thread)
        state_thread.start()


    def control_service_handler(self, request): 
        rospy.loginfo("control service request: {}".format(request.data))
        control_request = json.loads(request.data.decode())
        control_response = self.handle_control_request(control_request)
        return JsonMessageResponse(json.dumps(control_response).encode())


    def handle_control_request(self, request): 
        rospy.loginfo("control request: {}".format(request))
        success = False
        message = ""
        try: 
            ## request: {"target": "xxx", ...}
            target = request["target"]
            if target in self.control_dispatch: 
                success, message = self.control_dispatch[target](request)
            else: 
                message = "unknown control target: {}".format(target)
        except: 
            message = "exception"
        ## response 
        return {"success": success, "message": message}


    def check_service_handler(self, request): 
        rospy.loginfo("check service request: {}".format(request.data))
        check_request = json.loads(request.data.decode())
        check_response = self.handle_check_request(check_request)
        return JsonMessageResponse(json.dumps(check_response).encode())


    def handle_check_request(self, request): 
        rospy.loginfo("check request: {}".format(request))
        success = False 
        message = ""
        try: 
            ## reqeust: {"target": "xxx", ...}
            target = request["target"]
            if target in self.check_dispatch: 
                success, message = self.check_dispatch[target](request); 
            else: 
                message = "unknown state check target: {}".format(target)
        except: 
            message = "exception"
        ## response 
        return {"success": success, "message": message}


    ## control command target to "system"
    # {"target": "system", "command": "shtudown", ...}
    # {"command": [
    #     "shutdown",
    #     "reboot", 
    #     "reset", 
    #     "check_update", 
    #     "download_update", 
    #     "install_update", 
    #     "update_docker",
    #     "get_update_info", 
    #     "set_eth_dhcp", 
    #     "set_eth_ip",
    #     "get_eth_info", 
    #     "enable_wifi", 
    #     "set_wifi_ids", 
    #     "get_wifi_info", 
    #     "enable_ap", 
    #     "set_ap_id",
    #     "set_ap_ip", 
    #     "get_ap_info",
    # ]}
    def control_system(self, request): 
        rospy.loginfo("control system: {}".format(request))
        ## forward to system service 
        return self.system_service_request(request)


    ## check command target to "system"
    # {"target": "system", "command": "get_update_info", ...}
    # {"command": [
    #     "get_update_info",
    #     "get_eth_info",
    #     "get_wifi_info", 
    #     "get_ap_info",
    # ]}
    def check_system(self, request): 
        rospy.loginfo("check system: {}".format(request))
        ## forward to system service 
        return self.system_service_request(request)


    def check_storage(self, request): 
        # {"target": "storage"}
        rospy.loginfo("check storage...")
        global free_space
        free_space = free_space - 1 if free_space > 1 else 20 
        storage = {"total": 100, "free": free_space}
        state = {request["target"]: storage}
        ## success, message 
        return True, state


    ## Forward control or check request to system service 
    ## I/O with json string 
    def system_service_request(self, request):
        json_reqeust = json.dumps(request)
        json_reqeust += "\n"; # json string in line 
        rospy.loginfo("Send request: {}".format(json_reqeust))
        success = False 
        message = ""
        conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try: 
            conn.connect(self.camerad_addr)
            conn.sendall(json_reqeust.encode())
            conn.setblocking(0)
            rospy.loginfo("Waiting for response")
            rlist, _, _ = select.select([conn], [], [], self.camerad_timeout)
            if rlist: 
                assert rlist[0] == conn 
                json_response = conn.recv(self.RECV_BUFFER_SIZE).decode()
                rospy.loginfo("Received response: {}".format(json_response))
                response = json.loads(json_response)
                success = response["success"]
                message = response["message"]
            else: 
                rospy.loginfo("Response timeout!")
                messsage = "Response timeout!"   
        except socket.error, msg:
            rospy.loginfo("Socket exception: {}".format(msg))
            message = "Socket exception: {}".format(msg)
        except: 
            rospy.loginfo("Exception")
            message = "Exception"
        conn.close() 
        return success, message


    ## state update thread 
    def state_update_thread(self): 
        rospy.loginfo("state update thread in")
        ros_rate = rospy.Rate(self.update_rate)

        global free_space
        while not rospy.is_shutdown():
            state = {}
            for target, check_handler in self.check_dispatch.items():
                success, message = check_handler({"target": target})
                if success: 
                    state.update(message)
            state_msg = JsonString() 
            state_msg.data = json.dumps(state).encode()
            rospy.loginfo("publish state topic: {}".format(state_msg))
            self.state_pub.publish(state_msg)
            ros_rate.sleep() 

        rospy.loginfo("state update thread out")


def main():
    rospy.init_node("camera_node")
    CameraNode() 
    rospy.spin()


if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
