#!/usr/bin/env bash

## This script install/uninstall systemd service: 
##
## camerad.socket & camerad.service: 
##
## Listen on socket and run script system.py, which receives 
## message and run system level commands accordingly.  

## systemd units 
SYSTEMD="/etc/systemd/system"
CAMERAD_SOCKET="camerad.socket"
CAMERAD_SERVICE="camerad@.service"

install () {
  echo "Prepare to install systemd service..."

  SCRIPTS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  echo "SCRIPTS_DIR: ${SCRIPTS_DIR}"

  ## load setup is exists 
  SETUP_SCRIPT="${SCRIPTS_DIR}/setup.sh"
  if [ -f "${SETUP_SCRIPT}" ]; then
    . "${SETUP_SCRIPT}" load
  else 
    echo "Not found ${SETUP_SCRIPT}"
  fi 

  echo ""
  echo "Install ${CAMERAD_SOCKET}..."

  if [ -z "${CAMERAD_PORT}" ]; then 
    echo "CAMERAD_PORT is not set, using default!"
    CAMERAD_PORT=6666
  fi 
  echo "Socket port for ${CAMERAD_SOCKET}: ${CAMERAD_PORT}"

  ## compose systemd unit file
  echo "Compose ${CAMERAD_SOCKET} unit file: ${SCRIPTS_DIR}/${CAMERAD_SOCKET}"
  cat >${SCRIPTS_DIR}/${CAMERAD_SOCKET} <<EOF
[Unit]
Description=${CAMERAD_SOCKET} 
[Socket] 
ListenStream=${CAMERAD_PORT} 
Accept=yes
[Install] 
WantedBy=sockets.target
EOF

  echo ""
  cat ${SCRIPTS_DIR}/${CAMERAD_SOCKET}
  echo ""

  ## install systemd unit
  echo "Copy ${SCRIPTS_DIR}/${CAMERAD_SOCKET} to ${SYSTEMD}"
  sudo cp ${SCRIPTS_DIR}/${CAMERAD_SOCKET} ${SYSTEMD}
  echo "Enable ${CAMERAD_SOCKET}"
  sudo systemctl enable ${CAMERAD_SOCKET} 

  echo ""
  echo "Install ${CAMERAD_SERVICE}..."

  if [ -z "${CAMERA_USER}" ]; then 
    echo "CAMERA_USER is not set, using default!"
    CAMERA_USER="$USER"
  fi 
  echo "CAMERA_USER: ${CAMERA_USER}"

  if [ -z "${SYSTEM_LOG_DIR}" ]; then 
    echo "SYSTEM_LOG_DIR is not set, using default!"
    SYSTEM_LOG_DIR="system_log"
  fi 
  SYSTEM_LOG_DIR="/home/${CAMERA_USER}/${SYSTEM_LOG_DIR}"
  echo "Prepare directory for system log: ${SYSTEM_LOG_DIR}"
  mkdir -p "${SYSTEM_LOG_DIR}"

  CAMERAD_SERVICE_LOG="${SYSTEM_LOG_DIR}/camerad_service.log"
  CAMERAD_SERVICE_LOG_OLD="${SYSTEM_LOG_DIR}/camerad_service_old.log"
  echo "Log file for ${CAMERAD_SERVICE}: ${CAMERAD_SERVICE_LOG}"

  CAMERAD_SCRIPT="${SCRIPTS_DIR}/system.py"
  echo "Script file for ${CAMERAD_SERVICE}: ${CAMERAD_SCRIPT}"

  ## compose systemd unit file
  echo "Compose ${CAMERAD_SERVICE} unit file: ${SCRIPTS_DIR}/${CAMERAD_SERVICE}"
  cat >${SCRIPTS_DIR}/${CAMERAD_SERVICE} <<EOF
[Unit]
Description=${CAMERAD_SERVICE}
[Service] 
Type=simple
ExecStart=${CAMERAD_SCRIPT}
StandardInput=socket 
StandardOutput=journal
StandardError=journal
[Install]
WantedBy=multi-user.target
EOF

  echo ""
  cat ${SCRIPTS_DIR}/${CAMERAD_SERVICE}
  echo ""

  ## install systemd unit 
  echo "Copy ${SCRIPTS_DIR}/${CAMERAD_SERVICE} to ${SYSTEMD}"
  sudo cp ${SCRIPTS_DIR}/${CAMERAD_SERVICE} ${SYSTEMD}
  echo "Enable ${CAMERAD_SERVICE}"
  sudo systemctl enable ${CAMERAD_SERVICE} 
}

uninstall () {
  echo "Uninstall ${CAMERAD_SOCKET}..."
  if [ -f "${SYSTEMD}/${CAMERAD_SOCKET}" ]; then
    echo "Stop ${CAMERAD_SOCKET}"
    sudo systemctl stop ${CAMERAD_SOCKET}
    echo "Disable ${CAMERAD_SOCKET}"
    sudo systemctl disable ${CAMERAD_SOCKET}
    echo "Remove ${SYSTEMD}/${CAMERAD_SOCKET}"
    sudo rm -f ${SYSTEMD}/${CAMERAD_SOCKET}
  fi 

  echo "Uninstall ${CAMERAD_SERVICE}..."
  if [ -f "${SYSTEMD}/${CAMERAD_SERVICE}" ]; then
    echo "Stop ${CAMERAD_SERVICE}"
    sudo systemctl stop ${CAMERAD_SERVICE}
    echo "Disable ${CAMERAD_SERVICE}"
    sudo systemctl disable ${CAMERAD_SERVICE}
    echo "Remove ${SYSTEMD}/${CAMERAD_SERVICE}"
    sudo rm -f ${SYSTEMD}/${CAMERAD_SERVICE}
  fi 
}

case "$1" in
  "") echo "Usage: $0 {install|uninstall}"; exit 1;;
  install) "$@";;
  uninstall) "$@";;
  *) echo "Unknown function: $1()"; exit 2;;
esac 
