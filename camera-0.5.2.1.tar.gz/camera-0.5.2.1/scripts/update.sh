#!/usr/bin/env bash

## The script is used to update the system software
## Support check, download, and install commands

SCRIPTS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "SCRIPTS_DIR: ${SCRIPTS_DIR}" 

## install_dir/camera_dir/scripts
INSTALL_DIR="$(readlink -m "${SCRIPTS_DIR}/../..")"
echo "INSTALL_DIR: ${INSTALL_DIR}"

## only work on installation 
## with camera directory as a symbal line to camera-x.x.x.x directory 
CAMERA_DIR="${INSTALL_DIR}/camera"
echo "CAMERA_DIR: ${CAMERA_DIR}"
CURRENT_VERSION_DIR="$(readlink -f "${CAMERA_DIR}")"
echo "CURRENT_VERSION_DIR: ${CURRENT_VERSION_DIR}"
VERSION_DIR="$(basename "${CURRENT_VERSION_DIR}")"
CURRENT_VERSION="${CURRENT_VERSION_DIR##*-}"
echo "CURRENT_VERSION: ${CURRENT_VERSION}"
if [ -z "${CURRENT_VERSION}" ] ; then 
  echo "Invalid installation"
  exit 1
fi 

## "1.1.1.1" is expanded to decimal number string "01010101"
## so each version element support two decimal digits in [0, 99]  
ver() {
    printf "%02d%02d%02d%02d" ${1//./ }
}

## search the downloaded packages for for updated version 
LATEST_PACKAGE=""
LATEST_VERSION="${CURRENT_VERSION}"
shopt -s nullglob
for f in ${INSTALL_DIR}/camera-*.tar.gz ; do
  PACKAGE="$f"
  VERSION_DIR="$(basename "${PACKAGE}" .tar.gz)"
  VERSION="${VERSION_DIR##*-}"
  # echo "VERSION: ${VERSION}"
  if [ "$(ver "${VERSION}")" -gt "$(ver "${LATEST_VERSION}")" ] ; then 
    LATEST_VERSION=${VERSION}
    # echo "LATEST_VERSION: ${LATEST_VERSION}"
    LATEST_PACKAGE="${PACKAGE}"
  fi
done
shopt -u nullglob
echo "LATEST_VERSION: ${LATEST_VERSION}" 
echo "LATEST_PACKAGE: ${LATEST_PACKAGE}" 

## load setup is exists 
SETUP_SCRIPT="${SCRIPTS_DIR}/setup.sh"
if [ -f "${SETUP_SCRIPT}" ]; then
  . "${SETUP_SCRIPT}" load
else 
  echo "Not found ${SETUP_SCRIPT}"
fi 

check () {
  echo "$(date +"%Y-%m-%d %T"): update check..."

  ## update URL 
  if [ -z "${UPDATE_URL}" ] ; then 
    echo "UPDATE_URL is not set!"
    return 1 
  fi 
  echo "UPDATE_URL: ${UPDATE_URL}" 

  ## check and download update version info 
  echo "Download version file"
  RESPONSE=$(curl --write-out '%{http_code}' --silent --output /dev/null "${UPDATE_URL}/version.sh")
  if [ ${STATUSCODE} -ne 200; then
    echo "Download response: ${STATUSCODE}"
    return 1
  fi
  echo "curl --output ${INSTALL_DIR}/version.sh ${UPDATE_URL}/version.sh"
  curl --output "${INSTALL_DIR}/version.sh" "${UPDATE_URL}/version.sh"

  ## load update version info 
  if [ -f "${INSTALL_DIR}/version.sh" ] ; then 
    echo "Load version info"
    . "${INSTALL_DIR}/version.sh" 
    echo "VERSION: ${VERSION}" 
  fi 

  echo ""
  echo "$(date +"%Y-%m-%d %T"): update check done!"
} 

download () {
  echo "$(date +"%Y-%m-%d %T"): update download..."

  ## check version info 
  ## which will set the version variable on success
  check 

  if [ -z "${VERSION}" ]; then 
    echo "Failed download version info"
    return 1
  fi 

  if [ ! "$(ver "${VERSION}")" -gt "$(ver "${LATEST_VERSION}")" ]; then 
    echo "No updated version available"
    return 0
  fi 

  ## update URL 
  if [ -z "${UPDATE_URL}" ] ; then 
    echo "UPDATE_URL is not set!"
    return 1 
  fi 
  echo "UPDATE_URL: ${UPDATE_URL}" 

  ## download updated version 
  echo "Download updated version package"
  VERSION_PACKAGE="camera-${VERSION}.tar.gz" 
  echo "VERSION_PACKAGE: ${VERSION_PACKAGE}" 
  RESPONSE=$(curl --write-out '%{http_code}' --silent --output /dev/null "${UPDATE_URL}/${VERSION_PACKAGE}")
  if [ ${STATUSCODE} -ne 200; then
    echo "Download response: ${STATUSCODE}"
    exit 1
  fi
  echo "curl --output ${INSTALL_DIR}/${VERSION_PACKAGE} ${UPDATE_URL}/${VERSION_PACKAGE}"
  curl --output "${INSTALL_DIR}/${VERSION_PACKAGE}" "${UPDATE_URL}/${VERSION_PACKAGE}"

  echo ""
  echo "$(date +"%Y-%m-%d %T"): update download done!"
}

install () {
  echo "$(date +"%Y-%m-%d %T"): update install..."

  ## install the latest package version 
  if [ "$(ver "${LATEST_VERSION}")" -gt "$(ver "${CURRENT_VERSION}")" ] ; then 
    LATEST_VERSION_DIR="${INSTALL_DIR}/camera-${LATEST_VERSION}"
    echo "LATEST_VERSION_DIR: ${LATEST_VERSION_DIR}"
    if [ -d "${LATEST_VERSION_DIR}" ] ; then 
      echo "${LATEST_VERSION_DIR} already exists"
      rm -rf "${LATEST_VERSION_DIR}"
    fi 
    echo "tar -xzf "${LATEST_PACKAGE}" -C "${INSTALL_DIR}""
    tar -xzf "${LATEST_PACKAGE}" -C "${INSTALL_DIR}"
    rm -rf "${LATEST_PACKAGE}"
    ## re-link the camera dir to latest version folder  
    ln -snfr "${LATEST_VERSION_DIR}" "${CAMERA_DIR}"
    ## delete current version folder 
    rm -rf "${CURRENT_VERSION_DIR}"
  else 
    echo "No updated version to install"
  fi

  echo ""
  echo "$(date +"%Y-%m-%d %T"): update install done!"
}

case "$1" in
  "") echo "Usage: $0 {check|download|install}"; exit 1;;
  check) "$@";;
  download) "$@";;
  install) "$@";;
  *) echo "Unknown function: $1()"; exit 2;;
esac 
        