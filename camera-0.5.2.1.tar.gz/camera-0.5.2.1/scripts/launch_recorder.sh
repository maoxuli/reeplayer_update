#!/usr/bin/env bash

## This script launch video_recorder node with settings 
## run as the entry command of the docker container  

if [ "$USER" == "root" ]; then 
  echo "Supposed to run with non-root user!"
  exit 1
fi 

SCRIPTS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "SCRIPTS_DIR: ${SCRIPTS_DIR}" 

## load setup is exists 
SETUP_SCRIPT="${SCRIPTS_DIR}/setup.sh"
if [ -f "${SETUP_SCRIPT}" ]; then
  . "${SETUP_SCRIPT}" load
else 
  echo "Not found ${SETUP_SCRIPT}"
fi 

if [ -z "${CAMERA_LOG_DIR}" ]; then 
  echo "CAMERA_LOG_DIR is not set, using default!"
  CAMERA_LOG_DIR="camera_log"
fi 
CAMERA_LOG_DIR="$HOME/${CAMERA_LOG_DIR}"
echo "CAMERA_LOG_DIR: ${CAMERA_LOG_DIR}"
mkdir -p ${CAMERA_LOG_DIR}

RECORDER_LOG="${CAMERA_LOG_DIR}/recorder.log"
echo "RECORDER_LOG: ${RECORDER_LOG}" 

if [ -z "${CAMERA_DATA_DIR}" ]; then 
  echo "CAMERA_DATA_DIR is not set, using default!"
  CAMERA_DATA_DIR="camera_data"
fi 
CAMERA_DATA_DIR="$HOME/${CAMERA_DATA_DIR}"
echo "CAMERA_DATA_DIR: ${CAMERA_DATA_DIR}"
mkdir -p ${CAMERA_DATA_DIR}

RECORDER_ARGS="respawn:=true recording_path:=${CAMERA_DATA_DIR}"
echo "RECORDER_ARGS: ${RECORDER_ARGS}"

if [ -z "${CAMERA_ROS}" ]; then 
  echo "CAMERA_ROS is not set, using default!"
  CAMERA_ROS="ros"
fi 
CAMERA_ROS="$(cd "${SCRIPTS_DIR}/.." && pwd)/${CAMERA_ROS}"
if [ ! -d "${CAMERA_ROS}" ]; then 
  CAMERA_ROS="$(cd "${SCRIPTS_DIR}/../.." && pwd)/camera_ros/devel"
fi 
echo "CAMERA_ROS: ${CAMERA_ROS}"
. ${CAMERA_ROS}/setup.sh 

if [ -z "${CAMERA_LIB}" ]; then 
  echo "CAMERA_LIB is not set, using default!"
  CAMERA_LIB="lib"
fi 
CAMERA_LIB="$(cd "${SCRIPTS_DIR}/.." && pwd)/${CAMERA_LIB}"
echo "CAMERA_LIB: ${CAMERA_LIB}"

export LD_LIBRARY_PATH=/usr/local/lib:${CAMERA_LIB}:$LD_LIBRARY_PATH
export GST_PLUGIN_PATH=${CAMERA_LIB}/gst-plugins:$GST_PLUGIN_PATH

echo ""
echo "!!! IMPORTANT: this ROS launch needs an exernal roscore running!"
echo ""

## use exec to force roslaunch as the foreground process 
echo "exec roslaunch --wait video_recorder video_recorder.launch ${RECORDER_ARGS} >> ${RECORDER_LOG} 2>&1"
exec roslaunch --wait video_recorder video_recorder.launch ${RECORDER_ARGS} >> ${RECORDER_LOG} 2>&1
