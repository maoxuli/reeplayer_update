#!/usr/bin/env bash

## The script is used to launch the camera software 
## run the software in foreground or start/stop in background

SCRIPTS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "SCRIPTS_DIR: ${SCRIPTS_DIR}" 

## load setup is exists 
SETUP_SCRIPT="${SCRIPTS_DIR}/setup.sh"
if [ -f "${SETUP_SCRIPT}" ]; then
  . "${SETUP_SCRIPT}" load
else 
  echo "Not found ${SETUP_SCRIPT}"
fi 

launch () {
  if [ "$USER" == "root" ]; then 
    echo "Supposed to run with non-root user!"
    return 1
  fi 

  if [ -z "${CAMERA_LOG_DIR}" ]; then 
    echo "CAMERA_LOG_DIR is not set, using default!"
    CAMERA_LOG_DIR="camera_log"
  fi 
  CAMERA_LOG_DIR="/home/$USER/${CAMERA_LOG_DIR}"
  echo "CAMERA_LOG_DIR: ${CAMERA_LOG_DIR}"
  mkdir -p ${CAMERA_LOG_DIR}

  DOCKER_COMPOSE_LOG="${CAMERA_LOG_DIR}/docker_compose.log"
  echo "DOCKER_COMPOSE_LOG: ${DOCKER_COMPOSE_LOG}"

  if [ -z "${CAMERA_CONFIG}" ]; then 
    echo "CAMERA_CONFIG is not set, using default!"
    CAMERA_CONFIG="config"
  fi 
  CAMERA_CONFIG="$(cd "${SCRIPTS_DIR}/.." && pwd)/${CAMERA_CONFIG}"
  echo "CAMERA_CONFIG: ${CAMERA_CONFIG}"

  DOCKER_COMPOSE_ARGS="-f ${CAMERA_CONFIG}/docker-compose.yml"
  echo "RTSP_STREAMING: ${RTSP_STREAMING}"
  if [ "${RTSP_STREAMING}" = true ]; then 
    DOCKER_COMPOSE_ARGS= "${DOCKER_COMPOSE_ARGS} -f ${CAMERA_CONFIG}/docker-compose-rtsp.yml"
  fi 
  echo "DOCKER_COMPOSE_ARGS: ${DOCKER_COMPOSE_ARGS}"

  echo "Stopping docker containers"
  echo "docker-compose ${DOCKER_COMPOSE_ARGS} down"
  docker-compose ${DOCKER_COMPOSE_ARGS} down  

  ## arg 1 is for detached mode
  echo "Starting docker containers"
  DETACHED="$1"
  echo "DETACHED: ${DETACHED}"
  if [ "${DETACHED}" = true ]; then 
    echo "docker-compose ${DOCKER_COMPOSE_ARGS} up -d"
    docker-compose ${DOCKER_COMPOSE_ARGS} up -d
  else 
    echo "docker-compose ${DOCKER_COMPOSE_ARGS} up"
    docker-compose ${DOCKER_COMPOSE_ARGS} up
  fi 
}

run () {
  echo "$(date +"%Y-%m-%d %T"): run camera..."
  launch  
  echo ""
  echo "$(date +"%Y-%m-%d %T"): exit camera!"
}

start () {
  echo "$(date +"%Y-%m-%d %T"): start camera..."
  launch true 
  echo ""
  echo "$(date +"%Y-%m-%d %T"): start camera done!"
}

stop () {
  echo "$(date +"%Y-%m-%d %T"): stop camera..."

  if [ -z "${CAMERA_CONFIG}" ]; then 
    echo "CAMERA_CONFIG is not set, using default!"
    CAMERA_CONFIG="config"
  fi 
  CAMERA_CONFIG="$(cd "${SCRIPTS_DIR}/.." && pwd)/${CAMERA_CONFIG}"
  echo "CAMERA_CONFIG: ${CAMERA_CONFIG}"

  DOCKER_COMPOSE_ARGS="-f ${CAMERA_CONFIG}/docker-compose.yml"
  echo "RTSP_STREAMING: ${RTSP_STREAMING}"
  if [ "${RTSP_STREAMING}" = true]; then 
    DOCKER_COMPOSE_ARGS= "${DOCKER_COMPOSE_ARGS} -f ${CAMERA_CONFIG}/docker-compose-rtsp.yml"
  fi 
  echo "DOCKER_COMPOSE_ARGS: ${DOCKER_COMPOSE_ARGS}"

  ## stop docker containers
  echo "Stopping docker containers"
  echo "docker-compose ${DOCKER_COMPOSE_ARGS} down"
  docker-compose ${DOCKER_COMPOSE_ARGS} down

  echo ""
  echo "$(date +"%Y-%m-%d %T"): stop camera done!"
}

case "$1" in
  "") echo "Usage: $0 {run|start|stop}"; exit 1;;
  run) "$@";;
  start) "$@";;
  stop) "$@";;
  *) echo "Unknown function: $1()"; exit 2;;
esac 
