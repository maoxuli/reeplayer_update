#!/usr/bin/env python

## This script is run by camerad.service to receive 
## message from camerad.socket, and handle system requirements. 

import sys
import time
import socket
import json 
import os

SCRIPTS_DIR = os.path.dirname(os.path.realpath(__file__))
RECV_BUFFER_SIZE = 1024 

def run_shell_command(command): 
    print("system command: {}".format(command))
    try: 
        os.system(command)
        return True, ""
    except: 
        print("system command error")
        return False, "system command error"

def stop_camera(): 
    print("stop camera")
    return run_shell_command("systemctl stop camera")

def start_camera(): 
    print("start camera")
    return run_shell_command("systemctl start camera")

def shutdown_system(request): 
    success, message = stop_camera()
    if success: 
        print("shutdown")
        success, message = run_shell_command("poweroff -p")
    return success, message

def reboot_system(request): 
    success, message = stop_camera()
    if success: 
        print("reboot")
        success, message = run_shell_command("poweroff --reboot")
    return success, message

def reset_camera(request): 
    success, message = stop_camera()
    if success: 
        success, message = start_camera()
    return success, message

## auto update: install the updated version
#   echo "AUTO_UPDATE: ${AUTO_UPDATE}"
#   if [ -z "${AUTO_UPDATE}" ] || [ "${AUTO_UPDATE}" -ge 2 ] ; then 
#     echo "Installing update"
#     echo ". ${SCRIPTS_DIR}/update.sh install >> ${UPDATE_LOG} 2>&1"
#     . ${SCRIPTS_DIR}/update.sh install >> ${UPDATE_LOG} 2>&1
#   fi

#   ## auto update: check/download the latest version
#   echo "AUTO_UPDATE: ${AUTO_UPDATE}"
#   if [ -z "${AUTO_UPDATE}" ] || [ "${AUTO_UPDATE}" -ge 2 ] ; then 
#     echo "Downloading update"
#     echo ". ${SCRIPTS_DIR}/update.sh download >> ${UPDATE_LOG} 2>&1 &"
#     . ${SCRIPTS_DIR}/update.sh download >> ${UPDATE_LOG} 2>&1 &
#   elif [ "${AUTO_UPDATE}" -ge 1 ] ; then 
#     echo "Checking update"
#     echo ". ${SCRIPTS_DIR}/update.sh check >> ${UPDATE_LOG} 2>&1 &"
#     . ${SCRIPTS_DIR}/update.sh check >> ${UPDATE_LOG} 2>&1 &
#   fi 

def check_update(request): 
    pass 

def download_update(request): 
    pass 

def install_update(request): 
    pass 

def update_docker(request): 
    pass 

def get_update_info(request): 
    pass 

def set_eth_dhcp(request): 
    pass 

def set_eth_ip(request): 
    pass 

def get_eth_info(request): 
    pass 

def set_wifi_id(request): 
    print("set_wifi_id")
    ssid = request["ssid"]
    password = request["password"]
    return run_shell_command("{}/network.sh set_wifi_id {} {}".format(SCRIPTS_DIR, ssid, password))

def set_wifi_dhcp(request): 
    pass 

def set_wifi_ip(request): 
    pass 

def get_wifi_info(request): 
    pass 

def set_ap_id(request): 
    pass 

def set_ap_ip(request): 
    pass 

def get_ap_info(request): 
    pass 

## command handlers 
command_handlers = {
    "shutdown": shutdown_system,
    "reboot": reboot_system, 
    "reset": reset_camera, 
    "check_update": check_update, 
    "download_update": download_update, 
    "install_update": install_update, 
    "update_docker": update_docker, 
    "get_update_info": get_update_info,
    "set_eth_dhcp": set_eth_dhcp, 
    "set_eth_ip": set_eth_ip, 
    "get_eth_info": get_eth_info, 
    "set_wifi_id": set_wifi_id, 
    "set_wifi_dhcp": set_wifi_dhcp, 
    "set_wifi_ip": set_wifi_ip, 
    "get_wifi_info": get_wifi_info, 
    "set_ap_id": set_ap_id,  
    "set_ap_ip": set_ap_ip, 
    "get_ap_info": get_ap_info, 
}

## handle request in json string 
## return response in json string 
# {"target": "system", "command": "shtudown", ...}
def handle_request(json_request): 
    print("Handle request: {}".format(json_request))
    success = False 
    message = "" 
    try: 
        request = json.loads(json_request)
        print("Request: {}".format(request))
        success, message = command_handlers[request["command"]](request) 
    except KeyError: 
        print("Json key error")
        message = "Json key error"
    except ValueError: 
        print("Json value error")
        message = "Json value error"
    except: 
        print("Handle request error")
        message = "Handle request error"

    response = {"success": success, "message": message}
    return json.dumps(response)

## life cycle of a connection 
def handle_connection(conn):   
    if conn:
        while True: 
            try: 
                message = conn.recv(RECV_BUFFER_SIZE).decode()
                if message: 
                    print("Received message: {}".format(message))
                    request = message.splitlines()[0]
                    response = handle_request(request)
                    response += "\n" # json string in line 
                    print("Send response: {}".format(response))
                    conn.sendall(response.encode())
                else: 
                    print("Peer disconnected")
                    break
            except socket.error, msg: 
                print("Socket exception: {}".format(msg))
                break 
            except:
                print("Exception")
                break
        print("Close connection")
        conn.close()

## run a TCP server for testing 
def test(port): 
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(('0.0.0.0', port))
    print("Listen on ", port)
    s.listen(5)
    while True: 
        conn, addr = s.accept()
        handle_connection(conn)
    s.close()


if __name__ == "__main__":
    if len(sys.argv) > 1: 
        test(int(sys.argv[1]))
    else: 
        conn = socket.fromfd(sys.stdin.fileno(), socket.AF_INET, socket.SOCK_STREAM)
        handle_connection(conn)
