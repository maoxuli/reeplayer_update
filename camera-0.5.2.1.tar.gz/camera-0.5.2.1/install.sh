#!/bin/bash

## install the camera software system

echo "$(date +"%Y-%m-%d %T"): install camera system..."

## run in camera or camera-x.x.x.x folder
CAMERA_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "CAMERA_DIR: ${CAMERA_DIR}" 

## if in camera-x.x.x.x, create camera as symbal link     
VERSION="$(basename "${CAMERA_DIR}")"
if [ "${VERSION}" != "camera" ] ; then 
  VERSION_DIR="${CAMERA_DIR}"
  CAMERA_DIR="$(readlink -m "${VERSION_DIR}/..")/camera"
  echo "Create symbal link ${CAMERA_DIR} for ${VERSION_DIR}"
  ln -snfr "${VERSION_DIR}" "${CAMERA_DIR}"
fi 

## install systemd service 
. ${CAMERA_DIR}/scripts/setup.sh reset
. ${CAMERA_DIR}/scripts/system_service.sh install
. ${CAMERA_DIR}/scripts/camera_service.sh install 
sudo ${CAMERA_DIR}/scripts/network.sh install

echo "$(date +"%Y-%m-%d %T"): install camera system done!"
