#!/usr/bin/env bash 
set -e 

sudo apt-get update

## install docker compose with pip3 
echo "Install docker-compose"
sudo apt-get install -y python3-pip 
sudo pip3 install --upgrade pip 
sudo pip3 install setuptools docker-compose

## install tools 
echo "Install extra tools"
sudo apt-get install -y curl hostapd

set +e 
