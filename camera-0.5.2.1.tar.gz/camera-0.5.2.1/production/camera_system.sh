#!/usr/bin/env bash 

## prepare directories for camera software 
sudo mkdir /opt/reeplayer
sudo chown -R $(id -u):$(id -g) /opt/reeplayer 

## download camera software package and 
download () {
  echo "download..."    
}

install () {
  echo "install..."  
  ## check if current user in docker group 


}

init () {
  echo "init..."   
  echo "Add current user to group docker"
sudo usermod -aG docker ${USER}

## enable docker service 
echo "Enable docker service"
sudo systemctl enable docker  
}

case "$1" in
  "") echo "Usage: $0 {download|install|init}"; exit 1;;
  download) "$@"; exit;;
  install) "$@"; exit;;
  init) "$@"; exit;;
  *) echo "Unknown function: $1()"; exit 2;;
esac 
