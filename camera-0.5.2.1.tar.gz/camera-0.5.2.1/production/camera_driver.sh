#!/usr/bin/env bash 

install () {
  echo "install..."
}

uninstall () {
  echo "uninstall..."
}

case "$1" in
  "") echo "Usage: $0 {install|uninstall}"; exit 1;;
  install) "$@"; exit;;
  uninstall) "$@"; exit;;
  *) echo "Unknown function: $1()"; exit 2;;
esac 
