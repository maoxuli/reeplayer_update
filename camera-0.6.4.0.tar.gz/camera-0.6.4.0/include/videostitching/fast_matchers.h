#ifndef __FAST_MATCHERS_H
#define __FAST_MATCHERS_H

#include <opencv2/core.hpp>
#include <opencv2/core/cuda.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/cudafeatures2d.hpp>
#include <opencv2/xfeatures2d.hpp>
#include <opencv2/xfeatures2d/cuda.hpp>
#include <opencv2/calib3d.hpp>

#include <string>
#include <vector>
#include <set>

namespace videostitching {

struct ImageFeatures
{
    int img_idx;
    cv::Size img_size;
    std::vector<cv::KeyPoint> keypoints;
    cv::cuda::GpuMat descriptors;
    std::vector<cv::KeyPoint> getKeypoints() { return keypoints; };
};

struct MatchesInfo
{
    MatchesInfo();
    MatchesInfo(const MatchesInfo &other);
    MatchesInfo& operator =(const MatchesInfo &other);

    int src_img_idx;
    int dst_img_idx; 
    std::vector<cv::DMatch> matches;
    std::vector<char> inliers_mask;   
    int num_inliers; 
    cv::Mat H; 
    double confidence; 
    std::vector<cv::DMatch> getMatches() { return matches; };
    std::vector<char> getInliers() { return inliers_mask; };
};

class FastMatcher
{
public:
    FastMatcher(float match_conf = 0.65f, float ransac_threshold = 3, int min_matches = 4, int min_inliers = 4);

    void set_conf(float match_conf) { match_conf_ = match_conf; }; 
    void match(const std::vector<ImageFeatures> &features, MatchesInfo &matches_info);
    void refine(const std::vector<ImageFeatures> &features, MatchesInfo &matches_info);

protected:
    float match_conf_; 
    float ransac_threshold_; 
    int min_matches_;
    int min_inliers_;

    cv::Ptr<cv::cuda::DescriptorMatcher> matcher_;
};

} // namespace videostitching 

#endif // __FAST_MATCHERS_H
