#!/bin/bash

VERSION=0.5.0.0