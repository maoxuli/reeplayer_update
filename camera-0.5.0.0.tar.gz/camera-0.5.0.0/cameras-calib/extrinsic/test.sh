#!/usr/bin/env bash 

#RC_HOMOGRAPHY="{\"homographies\": [ {\"images\": {\"target\": 1, \"reference\": 0}, \"matrix\": {\"h00\":-0.836900689562, \"h01\":0.0536098105518, \"h02\":1380.24220883, \"h10\":-0.692579649292, \"h11\":0.733203495169, \"h12\":243.923146374, \"h20\":-0.00092198128431, \"h21\":7.27380059492e-05, \"h22\":1.0}} ]}"
RC_HOMOGRAPHY="{\"resolution\": {\"width\": 2016, \"height\": 1520}, \"homographies\": [ {\"images\": {\"target\": 1, \"reference\": 0}, \"matrix\": {\"h00\":1, \"h01\":0, \"h02\":2016, \"h10\":0, \"h11\":1, \"h12\":0, \"h20\":0, \"h21\":0, \"h22\":1}} ]}"

BORDER_WIDTH=0

gst-launch-1.0 -e cudastitcher name=stitcher \
homography-list="$RC_HOMOGRAPHY" \
border-width=$BORDER_WIDTH \
nvarguscamerasrc sensor-id=1 ! "video/x-raw(memory:NVMM),format=(string)NV12,width=(int)4032,height=(int)3040,framerate=(fraction)30/1" ! \
nvvidconv flip-method=2 ! "video/x-raw(memory:NVMM),format=(string)RGBA,width=(int)2048,height=(int)1520" ! stitcher.sink_0 \
nvarguscamerasrc sensor-id=0 ! "video/x-raw(memory:NVMM),format=(string)NV12,width=(int)4032,height=(int)3040,framerate=(fraction)30/1" ! \
nvvidconv flip-method=2 ! "video/x-raw(memory:NVMM),format=(string)RGBA,width=(int)2048,height=(int)1520" ! stitcher.sink_1 \
stitcher. ! queue ! nvvidconv ! nv3dsink 
#stitcher. ! tee name=t ! queue ! nvvidconv ! nvv4l2h264enc bitrate=8000000 ! h264parse ! qtmux ! filesink location=test.mp4 

