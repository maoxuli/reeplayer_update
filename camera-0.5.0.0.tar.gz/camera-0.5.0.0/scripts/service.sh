#!/bin/bash

## this script will install the systemd unit in the same folder
## and set the systemd unit run with local user
## other settings are set by the setup.sh in the same folder 

## systemd unit 
CAMERA_SERVICE="camera.service"
SIGNAL_SERVICE="signal.service"
SYSTEMD="/etc/systemd/system"

install () {
  echo "Install systemd service..."

  ## scripts path
  SCRIPTS_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
  echo "SCRIPTS_DIR: ${SCRIPTS_DIR}"

  ## load setup 
  echo "Loading setup from ${SCRIPTS_DIR}/setup.sh"
  . ${SCRIPTS_DIR}/setup.sh 
  echo ""

  if [ -z "${CAMERA_LOG}" ]; then 
    echo "CAMERA_LOG is not set!"
    CAMERA_LOG="${HOME}/camera_log"
  fi 
  echo "CAMERA_LOG: ${CAMERA_LOG}"
  mkdir -p ${CAMERA_LOG}

  SYSTEM_LOG="${CAMERA_LOG}/system.log"
  echo "SYSTEM_LOG: ${SYSTEM_LOG}"

  SYSTEM_SCRIPT="${SCRIPTS_DIR}/system.sh"
  echo "SYSTEM_SCRIPT: ${SYSTEM_SCRIPT}"

  ## create system (camera) service file
  echo "Create camera service: ${SCRIPTS_DIR}/${CAMERA_SERVICE}"
  cat >${SCRIPTS_DIR}/${CAMERA_SERVICE} <<EOF
[Unit]
Description=${CAMERA_SERVICE}
Requires=docker.service
After=docker.service
[Service]
Type=simple
RemainAfterExit=true
Restart=on-failure
User=${USER}
ExecStart=$(which bash) -c "mkdir -p ${CAMERA_LOG} && ${SYSTEM_SCRIPT} start >> ${SYSTEM_LOG}" 
ExecStop=$(which bash)  -c "mkdir -p ${CAMERA_LOG} && ${SYSTEM_SCRIPT} stop >> ${SYSTEM_LOG}" 
[Install]
WantedBy=multi-user.target
EOF

  echo ""
  cat ${SCRIPTS_DIR}/${CAMERA_SERVICE}
  echo ""

  ## install systemd unit
  echo "Copy ${SCRIPTS_DIR}/${CAMERA_SERVICE} to ${SYSTEMD}"
  sudo cp ${SCRIPTS_DIR}/${CAMERA_SERVICE} ${SYSTEMD}
  echo "Enable ${CAMERA_SERVICE}"
  sudo systemctl enable ${CAMERA_SERVICE} 

  SIGNAL_LOG="${CAMERA_LOG}/signal.log"
  echo "SIGNAL_LOG: ${SIGNAL_LOG}"

  SIGNAL_SCRIPT="${SCRIPTS_DIR}/signal.sh"
  echo "SIGNAL_SCRIPT: ${SIGNAL_SCRIPT}"

  ## create signal service file
  echo "Create signal service: ${SCRIPTS_DIR}/${SIGNAL_SERVICE}"
  cat >${SCRIPTS_DIR}/${SIGNAL_SERVICE} <<EOF
[Unit]
Description=${SIGNAL_SERVICE}
Requires=docker.service
After=docker.service
[Service]
Type=simple
RemainAfterExit=true
Restart=on-failure
ExecStart=$(which bash) -c "mkdir -p ${CAMERA_LOG} && ${SIGNAL_SCRIPT} >> ${SIGNAL_LOG}" 
[Install]
WantedBy=multi-user.target
EOF

  echo ""
  cat ${SCRIPTS_DIR}/${SIGNAL_SERVICE}
  echo ""

  ## install systemd unit
  echo "Copy ${SCRIPTS_DIR}/${SIGNAL_SERVICE} to ${SYSTEMD}"
  sudo cp ${SCRIPTS_DIR}/${SIGNAL_SERVICE} ${SYSTEMD}
  echo "Enable ${SIGNAL_SERVICE}"
  sudo systemctl enable ${SIGNAL_SERVICE} 
}

uninstall () {
  echo "Uninstall systemd service..."
  if [ -f "${SYSTEMD}/${CAMERA_SERVICE}" ]; then
    echo "Stop ${CAMERA_SERVICE}"
    sudo systemctl stop ${CAMERA_SERVICE}
    echo "Disable ${CAMERA_SERVICE}"
    sudo systemctl disable ${CAMERA_SERVICE}
    echo "Delete ${SYSTEMD}/${CAMERA_SERVICE}"
    sudo rm -f ${SYSTEMD}/${CAMERA_SERVICE}

    echo "Stop ${SIGNAL_SERVICE}"
    sudo systemctl stop ${SIGNAL_SERVICE}
    echo "Disable ${SIGNAL_SERVICE}"
    sudo systemctl disable ${SIGNAL_SERVICE}
    echo "Delete ${SYSTEMD}/${SIGNAL_SERVICE}"
    sudo rm -f ${SYSTEMD}/${SIGNAL_SERVICE}
  fi 
}

case "$1" in
  install)
    install
    ;;
  uninstall)
    uninstall
    ;;
  *)
    echo "Usage: $0 {install|uninstall}"
    ;;
esac 
