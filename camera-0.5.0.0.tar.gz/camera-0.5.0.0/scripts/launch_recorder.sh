#!/bin/bash

## scripts dir 
SCRIPTS_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "SCRIPTS_DIR: ${SCRIPTS_DIR}" 

## loading setup
echo "" 
echo "Loading setup from ${SCRIPTS_DIR}/setup.sh"
. ${SCRIPTS_DIR}/setup.sh 
echo ""

set -x 
export LD_LIBRARY_PATH=/usr/local/lib:${CAMERA_LIB}:$LD_LIBRARY_PATH
export GST_PLUGIN_PATH=${CAMERA_LIB}/gst-plugins:$GST_PLUGIN_PATH
export PATH=${CAMERA_BIN}:$PATH
set +x 

echo "CAMERA_ROS: ${CAMERA_ROS}"
. ${CAMERA_ROS}/setup.sh 

echo "CAMERA_LOG: ${CAMERA_LOG}"
mkdir -p ${CAMERA_LOG}

## propgate kill signals
kill_camera() {
  kill -INT $(jobs -p)
  wait $! 
}

echo "trap kill signals"
trap 'kill_camera' TERM INT

## start live recorder 
RECORDER_LOG="${CAMERA_LOG}/recorder.log"
echo "RECORDER_LOG: ${RECORDER_LOG}" 

RECORDER_ARGS="respawn:=true"
echo "RECORDER_ARGS: ${RECORDER_ARGS}"

echo "roslaunch --wait video_recorder video_recorder.launch ${RECORDER_ARGS} >> ${RECORDER_LOG} 2>&1 &"
roslaunch --wait video_recorder video_recorder.launch ${RECORDER_ARGS} >> ${RECORDER_LOG} 2>&1 &

## wait for all background processes exit 
for job in $(jobs -p)
do
  wait $job
done
