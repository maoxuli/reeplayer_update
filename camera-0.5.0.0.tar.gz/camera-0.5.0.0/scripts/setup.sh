#!/bin/bash

## The sofware system use default settings that mostly 
## deduced from the scripts directory.  
## This file override the default settings. 

## HOME should be set by login 
## or by systemd unit (which is set by installer)
if [ -z "${HOME}" ] ; then 
    echo "HOME is not set!"
    if [ $(id -u) -gt 0 ] 
    then
        exit 1
    else
        export HOME="/root"
    fi 
fi 
echo "HOME: ${HOME}"

## currect (scripts) path
export CAMERA_SCRIPTS="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "CAMERA_SCRIPTS: ${CAMERA_SCRIPTS}"

## install dir
export CAMERA_DIR="$( cd ${CAMERA_SCRIPTS}/.. && pwd )" 
echo "CAMERA_DIR: ${CAMERA_DIR}"

## Path for camera config
export CAMERA_CONFIG="${CAMERA_DIR}/config"
echo "CAMERA_CONFIG: ${CAMERA_CONFIG}"

## Path for camera lib
export CAMERA_LIB="${CAMERA_DIR}/lib"
echo "CAMERA_LIB: ${CAMERA_LIB}"

if [ ! -d "${CAMERA_LIB}" ]; then
    echo "${CAMERA_LIB} is not found!"
    export CAMERA_LIB="/opt/reeplayer/camera/lib" 
fi
echo "CAMERA_LIB: ${CAMERA_LIB}"

## Path for camera bin 
export CAMERA_BIN="${CAMERA_DIR}/bin"
echo "CAMERA_BIN: ${CAMERA_BIN}"

if [ ! -d "${CAMERA_BIN}" ]; then
    echo "${CAMERA_BIN} is not found!"
    export CAMERA_BIN="/opt/reeplayer/camera/bin" 
fi
echo "CAMERA_BIN: ${CAMERA_BIN}"

## Path for camera ROS packages 
export CAMERA_ROS="${CAMERA_DIR}/ros"
echo "CAMERA_ROS: ${CAMERA_ROS}"

if [ ! -d "${CAMERA_ROS}" ]; then
    echo "${CAMERA_ROS} is not found!"
    export CAMERA_ROS="$( cd ${CAMERA_DIR}/../camera_ros/devel && pwd )" 
fi
echo "CAMERA_ROS: ${CAMERA_ROS}"

## Path for log files
export CAMERA_LOG="${HOME}/camera_log"
echo "CAMERA_LOG: ${CAMERA_LOG}"
mkdir -p ${CAMERA_LOG}

## Path for data files
export CAMERA_DATA="${HOME}/camera_data"
echo "CAMERA_DATA: ${CAMERA_DATA}"
mkdir -p ${CAMERA_DATA}

## Auto update level 
## 0: no auto update, 1: auto check new version but not auto download (and install) 
## 2: auto download and auto install new version 
export AUTO_UPDATE=2 
echo "AUTO_UPDATE: ${AUTO_UPDATE}"

## URL for update 
# export UPDATE_URL=""
export UPDATE_URL="https://raw.githubusercontent.com/maoxuli/reeplayer_update/master"
echo "UPDATE_URL: ${UPDATE_URL}"
