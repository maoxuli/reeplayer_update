#!/bin/bash

## scripts dir 
SCRIPTS_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "SCRIPTS_DIR: ${SCRIPTS_DIR}" 

## loading setup
echo "" 
echo "Loading setup from ${SCRIPTS_DIR}/setup.sh"
. ${SCRIPTS_DIR}/setup.sh 
echo ""

set -x 
export LD_LIBRARY_PATH=/usr/local/lib:${CAMERA_LIB}:$LD_LIBRARY_PATH
export GST_PLUGIN_PATH=${CAMERA_LIB}/gst-plugins:$GST_PLUGIN_PATH
export PATH=${CAMERA_BIN}:$PATH
set +x 

## ROS setup 
if [ -z "${CAMERA_ROS}" ]; then 
  echo "CAMERA_ROS is not set!"
fi 
echo "CAMERA_ROS: ${CAMERA_ROS}"
. ${CAMERA_ROS}/setup.sh 

echo "CAMERA_CONFIG: ${CAMERA_CONFIG}" 
echo "CAMERA_LOG: ${CAMERA_LOG}"
mkdir -p ${CAMERA_LOG}

## propgate kill signals
kill_camera() {
  kill -INT $(jobs -p)
  wait $! 
}

echo "trap kill signals"
trap 'kill_camera' TERM INT

## Janus log
echo ""
JANUS_LOG="${CAMERA_LOG}/janus.log"
echo "JANUS_LOG: ${JANUS_LOG}"

## Janus config 
JANUS_CONFIG_PATH="${CAMERA_CONFIG}/janus"
JANUS_CONFIG="${JANUS_CONFIG_PATH}/janus.jcfg"
echo "JANUS_CONFIG: ${JANUS_CONFIG}"  
  
## start Janus 
echo "janus -b --config=${JANUS_CONFIG} --configs-folder=${JANUS_CONFIG_PATH} --log-file=${JANUS_LOG}"
janus -b --config=${JANUS_CONFIG} --configs-folder=${JANUS_CONFIG_PATH} --log-file=${JANUS_LOG} 

## RTSP server log
echo "" 
RTSP_LOG="${CAMERA_LOG}/rtspserver.log"
echo "RTSP_LOG: ${RTSP_LOG}"

## RTSP server config 
RTSP_CONFIG="${CAMERA_CONFIG}/rtspserver.json"
echo "RTSP_CONFIG: ${RTSP_CONFIG}"

## start RTSP server 
echo "rtspserver -c ${RTSP_CONFIG}  >> ${RTSP_LOG} 2>&1 &"
rtspserver -c ${RTSP_CONFIG}  >> ${RTSP_LOG} 2>&1 &

## camera launch log 
echo ""
CAMERA_LOG="${CAMERA_LOG}/camera.log"
echo "CAMERA_LOG: ${CAMERA_LOG}" 

## camera launch args 
## enable respawn for background running 
CAMERA_ARGS="respawn:=true"
echo "CAMERA_ARGS: ${CAMERA_ARGS}"

## start camera launch 
echo "roslaunch camera camera.launch ${CAMERA_ARGS} >> ${CAMERA_LOG} 2>&1 &"
roslaunch camera camera.launch ${CAMERA_ARGS} >> ${CAMERA_LOG} 2>&1 &

## wait for all background processes exit 
for job in $(jobs -p)
do
  wait $job
done
