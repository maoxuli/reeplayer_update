#!/bin/bash

CAMERA_ID=0
CAMERA_MODE=1080p
FLIP_METHOD=0
SCALE=1

function print_help { 
  echo "Usage: $0 [-i ${CAMERA_ID}] [-m ${CAMERA_MODE}] [-r ${FLIP_METHOD}] [-s ${SCALE}] [-h]"
  echo "-i: camera sensor ID, 0 or 1"
  echo "-m: camera sesnor mode:"
  echo -e "\t 1080p: 1920x1080@30 (default)" 
  echo -e "\t 1440p: 2560x1440@30"
  echo -e "\t 1944p: 2592x1944@30"
  echo -e "\t 3040p: 4032x3040@30"
  echo -e "\t 1848p: 3264x1848@28"
  echo -e "\t 2464p: 3264x2464@21"
  echo "-r: roation of input image:" 
  echo -e "\t 0: no rotation (default)" 
  echo -e "\t 1: counterclockwise - 90 degrees"
  echo -e "\t 2: rotate - 180 degrees"
  echo -e "\t 3: clockwise - 90 degrees"
  echo -e "\t 4: horizontal flip"
  echo -e "\t 5: upper right diagonal flip"
  echo -e "\t 6: vertical flip"
  echo -e "\t 7: upper-left diagonal"
  echo "-c: scale of input image"
  echo "-h: help"
} 

while getopts ":i:m:r:s:h" opt; do
  case $opt in
    i) CAMERA_ID="$OPTARG";;
    m) CAMERA_MODE="$OPTARG";;
    r) FLIP_METHOD="$OPTARG";;
    s) SCALE="$OPTARG";;
    \? | h | *) print_help; exit 0;;
  esac
done

# input 
WIDTH=1920
HEIGHT=1080
FPS=30

case $CAMERA_MODE in
  "1080p") WIDTH=1920; HEIGHT=1080; FPS=30;;
  "1440p") WIDTH=2560; HEIGHT=1440; FPS=30;;
  "1944p") WIDTH=2592; HEIGHT=1944; FPS=30;;
  "3040p") WIDTH=4032; HEIGHT=3040; FPS=30;;
  "1848p") WIDTH=3264; HEIGHT=1848; FPS=28;;
  "2464p") WIDTH=3264; HEIGHT=2464; FPS=21;;
  *) echo "Unknown camera mode: ${CAMERA_MODE}";;
esac

# output
# downsize by scale 
OUT_WIDTH=$((WIDTH / SCALE))
OUT_HEIGHT=$((HEIGHT / SCALE))

echo "CAMERA_ID: ${CAMERA_ID}"
echo "INPUT: ${WIDTH}x${HEIGHT}@${FPS}"
echo "FLIP_METHOD: ${FLIP_METHOD}" 
echo "SCALE: ${SCALE}"
echo "OUTPUT: ${OUT_WIDTH}x${OUT_HEIGHT}@${FPS}"

set -x

gst-launch-1.0 nvarguscamerasrc sensor-id=${CAMERA_ID} ! "video/x-raw(memory:NVMM),format=(string)NV12,framerate=(fraction)21/1" ! nvvidconv flip-method=${FLIP_METHOD} ! "video/x-raw(memory:NVMM),format=(string)NV12,width=(int)${OUT_WIDTH},height=(int)${OUT_HEIGHT},pixel-aspect-ratio=1/1" ! nv3dsink -e

set +x
