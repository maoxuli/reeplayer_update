
"use strict";

let JsonMessage = require('./JsonMessage.js')

module.exports = {
  JsonMessage: JsonMessage,
};
