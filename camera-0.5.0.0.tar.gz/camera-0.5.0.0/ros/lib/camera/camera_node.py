#! /usr/bin/env python

import os 
import time
import threading
import json
import rospy
from camera.srv import JsonMessage, JsonMessageResponse
from std_msgs.msg import String as JsonString

## fake number 
free_space = 20

## Camera node object
class CameraNode(object): 
    def __init__(self): 
        ## parameters 
        self.update_rate = rospy.get_param("~state_update_rate", 1.0)
        self.update_rate = self.update_rate if self.update_rate > 0 else 1.0
        rospy.loginfo("state update rate: {}".format(self.update_rate))

        self.system_signal_file = rospy.get_param("~system_signal_file", "/var/run/system_signal")
        rospy.loginfo("system signal file: {}".format(self.system_signal_file))

        ## control dispatch 
        self.control_dispatch = {
            'shutdown': self.shutdown,
            'reboot': self.reboot,
        }

        ## control service 
        control_service = "control"
        rospy.loginfo("Starting service: {}".format(control_service))
        rospy.Service(control_service, JsonMessage, self.control_service_handler)

        ## state check dispatch
        self.check_dispatch = {
            'storage': self.check_storage,
            # 'battery': self.check_battery,
            # 'temperature': self.check_temperature,
        }

        ## state check service 
        check_service = "check"
        rospy.loginfo("Starting service: {}".format(check_service))
        rospy.Service(check_service, JsonMessage, self.check_service_handler)

        ## state topic 
        state_topic = "state" 
        rospy.loginfo("Advertise topic: {}".format(state_topic))
        self.state_pub = rospy.Publisher(state_topic, JsonString, queue_size=2)

        ## check and publish state in a thead 
        state_thread = threading.Thread(target=self.state_update_thread)
        state_thread.start()


    def control_service_handler(self, request): 
        rospy.loginfo("control service request: {}".format(request.data))
        control_request = json.loads(request.data.decode())
        control_response = self.handle_control_request(control_request)
        return JsonMessageResponse(json.dumps(control_response).encode())


    def handle_control_request(self, request): 
        rospy.loginfo("control request: {}".format(request))
        try: 
            if request["command"] in self.control_dispatch: 
                return self.control_dispatch[request["command"]](request)
            else: 
                return {"success": False, "message": "unknown command"}
        except: 
            return {"success": False, "message": "exception"}


    def check_service_handler(self, request): 
            rospy.loginfo("check service request: {}".format(request.data))
            check_request = json.loads(request.data.decode())
            check_response = self.handle_check_request(check_request)
            return JsonMessageResponse(json.dumps(check_response).encode())


    def handle_check_request(self, request): 
        rospy.loginfo("check request: {}".format(request))
        try: 
            if request["command"] in self.check_dispatch: 
                return self.check_dispatch[request["command"]](request)
            else: 
                return {"success": False, "message": "unknown command"}
        except: 
            return {"success": False, "message": "exception"}


    def shutdown(self, request): 
        # {"command": "reboot", "password": ""}
        rospy.loginfo("write 'shutdown' to {}".format(self.system_signal_file))
        with open(self.system_signal_file, "w") as f: 
            f.write("shutdown") 
        return {"success": True, "message":""}


    def reboot(self, request): 
        # {"command": "reboot", "password": ""}
        rospy.loginfo("write 'reboot' to {}".format(self.system_signal_file))
        with open(self.system_signal_file, "w") as f: 
            f.write("reboot") 
        return {"success": True, "message":""}


    def check_storage(self, reqeust): 
        # {"command": "storage"}
        rospy.loginfo("check storage...")
        return {"success": True, "message": {"total": 100, "free": free_space}}


    ## state update thread 
    def state_update_thread(self): 
        rospy.loginfo("state update thread in")
        ros_rate = rospy.Rate(self.update_rate)

        global free_space
        while not rospy.is_shutdown():
            state = {} 
            free_space = free_space - 1 if free_space > 1 else 20 
            state["storage"] = {"total": 100, "free": free_space}
            state_msg = JsonString() 
            state_msg.data = json.dumps(state).encode()
            # rospy.loginfo("publish state topic: {}".format(state_msg))
            self.state_pub.publish(state_msg)
            ros_rate.sleep() 

        rospy.loginfo("state update thread out")

def main():
    rospy.init_node("camera_node")
    CameraNode() 
    rospy.spin()


if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
