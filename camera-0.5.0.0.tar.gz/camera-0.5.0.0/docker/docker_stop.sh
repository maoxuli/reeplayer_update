#!/usr/bin/env bash

# docker container 
DOCKER="camera"

# Display help 
function usage()
{
cat <<EOF
Usage: $(basename $0) [options] ...
OPTIONS:
    -h, --help             Display this help and exit.
    -n, --name <name>      Specify the name of the docker container.
EOF
exit 0
}

while [ $# -gt 0 ]
do
    case "$1" in
    -h | --help )       usage
                        exit
                        ;;
    -n | --name )       shift
                        DOCKER=$1
                        ;;
    *)                  usage
                        exit 1
    esac
    shift
done

echo "Docker name: $DOCKER"

docker ps -a --format "{{.Names}}" | grep $DOCKER 1>/dev/null
if [ $? == 0 ] ; then
    echo "Stopping running docker: $DOCKER"
    docker stop $DOCKER 1>/dev/null
fi
