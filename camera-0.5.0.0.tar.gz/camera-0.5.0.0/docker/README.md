# docker 

1. Build docker images

Docker images are layered as below. See scripts in sub folders. 

    ubunut
    l4t-base
    opencv
    ros 
    camera 

2. Run docker container 

    docker_start.sh 
    docker_into.sh 
    docker_stop.sh 
