#!/usr/bin/env bash

IMAGE="reeplayer/camera:ros-opencv-4.4.0-l4t-base-r32.4.4-ridgerun"

DOCKER="camera"
OPTIONS="-itd"

# shared dev folder 
DEV_FOLDER="Reeplayer"

# Display help 
function usage()
{
cat <<EOF
Usage: $(basename $0) [options] ...
OPTIONS:
    -h, --help             Display this help and exit.
    -i, --image <image>    Specify the docker image.
    -n, --name <name>      Specify the name of the docker container.
    -f, --foreground       Run the conatiner in foreground mode.
EOF
exit 0
}

while [ $# -gt 0 ]
do
    case "$1" in
    -h | --help )       usage
                        exit
                        ;;
    -i | --image )      shift
                        IMAGE=$1
                        ;;
    -n | --name )       shift
                        DOCKER=$1
                        ;;
    -f | --foreground ) OPTIONS="-it"
                        ;;
    *)                  usage
                        exit 1
    esac
    shift
done

echo "Docker image: $IMAGE"
echo "Docker name: $DOCKER"

if [[ "$(docker images -q $IMAGE 2> /dev/null)" == "" ]] ; then
    echo "Pulling docker image $IMAGE"
    docker pull $IMAGE 
    if [ $? -ne 0 ] ; then 
        error "Failed to pull docker image."
        exit 1
    fi
    echo "Pulled docker image." 
fi

# kill running container 
docker ps -a --format "{{.Names}}" | grep $DOCKER 1>/dev/null
if [ $? == 0 ] ; then
    echo "Stopping running docker"
    docker stop $DOCKER 1>/dev/null
    docker rm -f $DOCKER 1>/dev/null
fi

# prepare shared dev folder
echo "Prepare dev folder: $HOME/${DEV_FOLDER}"
if [ ! -d "$HOME/${DEV_FOLDER}" ];then
    mkdir "$HOME/${DEV_FOLDER}"
fi

# docker run 
echo "Starting docker container $DOCKER"
docker run ${OPTIONS} \
    --rm \
    --privileged \
    --net=host \
    -e CAMERA_UID=$(id -u) \
    -e CAMERA_GID=$(id -g) \
    -e NVIDIA_VISIBLE_DEVICES=all \
    -e NVIDIA_DRIVER_CAPABILITIES=compute,utility,video \
    -e DISPLAY=$DISPLAY \
    -v $HOME/.Xauthority:/root/.Xauthority:rw \
    -v /tmp/.X11-unix/:/tmp/.X11-unix \
    -v /tmp/argus_socket:/tmp/argus_socket \
    -v /usr/src:/usr/src \
    -v /usr/lib/pkgconfig:/usr/lib/pkgconfig \
    -v /var/run/system_signal:/var/run/system_signal \
    -v /opt/reeplayer:/opt/reeplayer \
    -v /home/reeplayer/.ros:/home/camera/.ros \
    -v /home/reeplayer/camera_log:/home/camera/camera_log \
    -v /home/reeplayer/camera_data:/home/camera/camera_data \
    -v $HOME/${DEV_FOLDER}:/home/camera/${DEV_FOLDER} \
    -w /home/camera/${DEV_FOLDER} \
    --name $DOCKER \
    $IMAGE

if [ $? -ne 0 ] ; then 
    echo "Failed to start docker container $DOCKER based on image: $IMAGE"
    exit 1
fi

echo "Docker container is started. Enter with: docker_into.sh"
echo "Enjoy!"
