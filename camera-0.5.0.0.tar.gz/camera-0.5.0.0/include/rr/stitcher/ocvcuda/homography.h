/*
 * Copyright (C) 2020-2021 RidgeRun, LLC (http://www.ridgerun.com)
 * All Rights Reserved.
 *
 * The contents of this software are proprietary and confidential to RidgeRun,
 * LLC.  No part of this program may be photocopied, reproduced or translated
 * into another programming language without prior written consent of
 * RidgeRun, LLC.  The user is free to modify the source code after obtaining
 * a software license from RidgeRun.  All source code changes must be provided
 * back to RidgeRun without any encumbrance.
 */

#ifndef __RR_STITCHER_OCVCUDA_HOMOGRAPHY_H__
#define __RR_STITCHER_OCVCUDA_HOMOGRAPHY_H__

#include <rr/stitcher/ihomography.h>

#include "rr/stitcher/image_geometry_utils.h"

namespace rr {
namespace stitcher {
namespace ocvcuda {

class Homography : public IHomography<uint8_t>,
  public IHomography<RGBA<uint8_t>> {

 public:
  RuntimeError refineHomographies(const std::vector<Matrix<uint8_t>> &images,
                                  std::vector<TransformationNode> &transformations,
                                  const float matchRatio,
                                  const uint minMatches,
                                  const int kernelSize[],
                                  const double kernelSigmas[]) override;

  RuntimeError refineHomographies(const std::vector<Matrix<RGBA<uint8_t>>>
                                  &images,
                                  std::vector<TransformationNode> &transformations,
                                  const float matchRatio,
                                  const uint minMatches,
                                  const int kernelSize[],
                                  const double kernelSigmas[]) override;

  RuntimeError refineHomography(const Matrix<uint8_t> &targetImage,
                                const Matrix<uint8_t> &referenceImage,
                                Matrix<float> &H,
                                const float matchRatio,
                                const uint minMatches,
                                const int kernelSize[],
                                const double kernelSigmas[]) override;

  RuntimeError refineHomography(const Matrix<RGBA<uint8_t>> &targetImage,
                                const Matrix<RGBA<uint8_t>> &referenceImage,
                                Matrix<float> &H,
                                const float matchRatio,
                                const uint minMatches,
                                const int kernelSize[],
                                const double kernelSigmas[]) override;

  RuntimeError transform(const Matrix<uint8_t> &srcImage, const Matrix<float> &H,
                         Matrix<uint8_t> &dstImage) override;

  RuntimeError transform(const Matrix<RGBA<uint8_t>> &srcImage,
                         const Matrix<float> &H, Matrix<RGBA<uint8_t>> &dstImage) override;
};

} // namespace ocvcuda
} // namespace stitcher
} // namespace rr

#endif //__RR_STITCHER_OCVCUDA_HOMOGRAPHY_H__
