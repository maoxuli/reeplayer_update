/*
 * Copyright (C) 2020 RidgeRun, LLC (http://www.ridgerun.com)
 * All Rights Reserved.
 *
 * The contents of this software are proprietary and confidential to RidgeRun,
 * LLC.  No part of this program may be photocopied, reproduced or translated
 * into another programming language without prior written consent of
 * RidgeRun, LLC.  The user is free to modify the source code after obtaining
 * a software license from RidgeRun.  All source code changes must be provided
 * back to RidgeRun without any encumbrance.
*/

#ifndef __RR_STITCHER_OPENCV_BLENDER_H__
#define __RR_STITCHER_OPENCV_BLENDER_H__

#include <rr/stitcher/iblender.h>

#include <cuda_runtime.h>

namespace rr {
namespace stitcher {
namespace ocvcuda {

class Blender : public IBlender<uint8_t, float>,
  public IBlender<RGBA<uint8_t>, RGBA<float>> {
 public:
  Blender ();

  RuntimeError applyMasks(const Matrix<uint8_t> &leftImage,
                          const Matrix<uint8_t> &rightImage,
                          Matrix<uint8_t> &outputImage,
                          Matrix<float> &leftMask,
                          Matrix<float> &rightMask,
                          const Matrix<float> &leftTransformation,
                          const Matrix<float> &rightTransformation);

  RuntimeError applyMasks(const Matrix<RGBA<uint8_t>> &leftImage,
                          const Matrix<RGBA<uint8_t>> &rightImage,
                          Matrix<RGBA<uint8_t>> &outputImage,
                          Matrix<RGBA<float>> &leftMask,
                          Matrix<RGBA<float>> &rightMask,
                          const Matrix<float> &leftTransformation,
                          const Matrix<float> &rightTransformation);

 private:
  RuntimeError getOverlapInterval(const Matrix<float> &leftTransformation,
                                  const Matrix<float> &rightTransformation,
                                  unsigned int imgsWidth,
                                  unsigned int imgsHeight,
                                  unsigned int &start,
                                  unsigned int &borderWidth);
};

} // namespace ocvcuda
} // namespace stitcher
} // namespace rr

cudaError_t
apply_blending_map_grey (
  const rr::stitcher::Matrix<uint8_t> &left_image,
  const rr::stitcher::Matrix<uint8_t> &right_image,
  rr::stitcher::Matrix<uint8_t> &output_image,
  const rr::stitcher::Matrix<float> &left_mask,
  const rr::stitcher::Matrix<float> &right_mask,
  unsigned int start,
  unsigned int border_width,
  const rr::stitcher::Matrix<float> left_inv_transf,
  const rr::stitcher::Matrix<float> right_inv_transf);

cudaError_t
apply_blending_map_rgba (
  const rr::stitcher::Matrix<rr::stitcher::RGBA<uint8_t>> &left_image,
  const rr::stitcher::Matrix<rr::stitcher::RGBA<uint8_t>> &right_image,
  rr::stitcher::Matrix<rr::stitcher::RGBA<uint8_t>> &output_image,
  const rr::stitcher::Matrix<rr::stitcher::RGBA<float>> &left_mask,
  const rr::stitcher::Matrix<rr::stitcher::RGBA<float>> &right_mask,
  unsigned int start,
  unsigned int border_width,
  const rr::stitcher::Matrix<float> left_inv_transf,
  const rr::stitcher::Matrix<float> right_inv_transf);

#endif //__RR_STITCHER_OPENCV_BLENDER_H__
