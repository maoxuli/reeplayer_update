#! /usr/bin/env python

import os 
import time
import threading
import json
import socket 
import select 
import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse


## JSON-RPC 2.0  
JSON_PARSE_ERROR = -32700
RPC_INVALID_REQUEST = -32600
RPC_METHOD_NOT_FOUND = -32601
RPC_INVALID_PARAMS = -32602
RPC_INTERNAL_ERROR = -32603
RPC_SERVER_ERROR = -32000

jsonrpc_error_messages = dict([
    (JSON_PARSE_ERROR, "Invalid JSON was received by the server"),
    (RPC_INVALID_REQUEST, "The JSON sent is not a valid Request object"),
    (RPC_METHOD_NOT_FOUND, "The method does not exist / is not available"),
    (RPC_INVALID_PARAMS, "Invalid method parameter(s)"),
    (RPC_INTERNAL_ERROR, "Internal JSON-RPC error"),
    (RPC_SERVER_ERROR, "General server error"),
])

def get_error_message(code): 
    if code not in jsonrpc_error_messages: 
        return ""
    return jsonrpc_error_messages[code]

def jsonrpc_wrap_error(request, code, message): 
    response = {"jsonrpc": 2.0, "error": {"code": code, "message": message}} 
    if request is not None and "id" in request: 
        response["id"] = request["id"]
    return response 

def jsonrpc_wrap_result(request, result): 
    response = {"jsonrpc": 2.0, "result": result} 
    if request is not None and "id" in request: 
        response["id"] = request["id"]
    return response 

## validate a single JSON-RPC 2.0 request object 
def validate_request_fields(request):
    ## be a dictionary 
    if not isinstance(request, dict): 
        print("request is not a dict object")
        return False 
    ## be jsonrpc 2.0 object 
    # if "jsonrpc" not in request or request["jsonrpc"] != "2.0": # be jsonrpc 2.0 object 
    #     return false
    ## method exists 
    if not ("method" in request and isinstance(request["method"], basestring)): 
        return False 
    ## id is integer, string, or None if it exists 
    if "id" in request and not (isinstance(request["id"], int) or isinstance(request["id"], basestring) or request["id"] is None): 
        print("Invalid id")
        return False
    ## params is dict, list, or None if it exists 
    if "params" in request and not (isinstance(request["params"], dict) or isinstance(request["params"], list) or request["params"] is None): 
        print("Invalid params")
        return False 
    return True  


## Camera node object
class CameraNode(object): 
    RECV_BUFFER_SIZE = 1024 

    def __init__(self): 
        ## communication with camerad service 
        camerad_port = rospy.get_param("~camerad_port", "6666")
        rospy.loginfo("camerad service socket port: {}".format(camerad_port))
        self.camerad_addr = ('127.0.0.1', camerad_port)

        self.camerad_timeout = rospy.get_param("~camerad_timeout", "10.0")
        rospy.loginfo("camerad service timeout: {}".format(self.camerad_timeout))

        ## dispatch service requests to handlers
        ## this is a list of methods that can be procesed in this object  
        ## all methods not in this list will be forwarded to the systemd service  
        self.service_handlers = { 
            'check_config' : self.check_config, 
            'update_config' : self.update_config, 
            'reset_config' : self.reset_config, 
            'save_config' : self.save_config, 
            # 'shutdown_system': self.shutdown_system, 
            # 'restart_system': self.restart_system,
            # 'connect_wifi': self.connect_wifi,
            # 'disconnect_wifi': self.disconnect_wifi, 
            # 'network_status': self.network_status,
            # 'check_software': self.check_software, 
            # 'download_software': self.download_software, 
            # 'install_software': self.install_software, 
            # 'software_status': self.software_status, 
            # 'check_docker': self.check_docker, 
            # 'pull_docker': self.pull_docker, 
            # 'docker_status': self.software_status, 
            'battery_status': self.battery_status, 
            'cpu_status': self.cpu_status,
            'gpu_status': self.gpu_status,
            'memory_status': self.memory_status,
            'storage_status': self.storage_status,
            'delete_files': self.delete_files,
            'files_status': self.files_status,
            'prepare_footage': self.prepare_footage,
            'update_footage': self.update_footage,
            'delete_footage': self.delete_footage,
            'footage_status': self.footage_status
        }
        rospy.loginfo("Service handlers:\n{}".format(self.service_handlers))

        ## A list of status checking methods 
        ## add or remove by status subscribe method 
        self.subscriptions = [
            'network_status',
            'battery_status', 
            'processor_status',
            'memory_status', 
            'storage_status' 
        ]
        rospy.loginfo("Status subscriptions:\n{}".format(self.subscriptions))

        ## camera service 
        camera_service = "camera_service"
        rospy.loginfo("Starting service: {}".format(camera_service))
        rospy.Service(camera_service, JsonService, self.camera_service_handler)

        ## status topic 
        status_topic = "camera_status" 
        rospy.loginfo("Advertise topic: {}".format(status_topic))
        self.status_pub = rospy.Publisher(status_topic, JsonString, queue_size=2)

        ## locking for concurrency 
        self.lock = threading.Lock() 

        ## check and publish state in a thead 
        status_thread = threading.Thread(target=self.status_update_thread)
        status_thread.start()


    ## JSON string request and response 
    def camera_service_handler(self, request): 
        rospy.loginfo("camera servcie request: {}".format(request.data))
        json_response = {}
        try: 
            json_request = json.loads(request.data.decode())
            json_response = self.handle_json_request(json_request)
        except: 
            json_reponse = jsonrpc_wrap_error(None, JSON_PARSE_ERROR, get_error_message(JSON_PARSE_ERROR))
        response = json.dumps(json_response)
        rospy.loginfo("service response: {}".format(response))
        return JsonServiceResponse(response.encode())


    ## handle JSON-RPC 2.0 request 
    def handle_json_request(self, request): 
        rospy.loginfo("handle json request: {}".format(request))
        if isinstance(request, list): 
            return self.handle_batch_request(request)
        elif isinstance(request, dict): 
            return self.handle_single_request(request)
        else: 
            return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, get_error_message(RPC_INVALID_REQUEST)); 


    ## handle batch request 
    def handle_batch_request(self, request): 
        rospy.loginfo("handle batch request: {}".format(request))
        if len(request) == 0: 
            return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, get_error_message(RPC_INVALID_REQUEST))
        else: 
            response = [] 
            for requ in request: 
                resp = self.handle_single_request(requ); 
                response.append(resp)
            return response


    ## handle single request 
    def handle_single_request(self, request): 
        rospy.loginfo("handle single request: {}".format(request))
        if validate_request_fields(request): 
            return self.process_request(request)
        else: 
            return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, get_error_message(RPC_INVALID_REQUEST))


    ## process request 
    def process_request(self, request): 
        rospy.loginfo("process request: {}".format(request))
        method = request["method"]
        if method in self.service_handlers: 
            rospy.loginfo("local handle request: {}".format(request))
            try: 
                return self.service_handlers[method](request)
            except KeyError: 
                return jsonrpc_wrap_error(request, RPC_INVALID_PARAMS, get_error_message(RPC_INVALID_PARAMS))
        else: 
            rospy.loginfo("system handle request: {}".format(request))
            return self.handle_system_request(request)

    ## check config 
    def check_config(self, request): 
        rospy.loginfo("check config...")
        return jsonrpc_wrap_error(request, RPC_INTERNAL_ERROR, "Not implemented")

    ## check config 
    def update_config(self, request): 
        rospy.loginfo("update config...")
        return jsonrpc_wrap_error(request, RPC_INTERNAL_ERROR, "Not implemented")

    ## reset config 
    def reset_config(self, request): 
        rospy.loginfo("reset config...")
        return jsonrpc_wrap_error(request, RPC_INTERNAL_ERROR, "Not implemented")

    ## save config 
    def save_config(self, request): 
        rospy.loginfo("save config...")
        return jsonrpc_wrap_error(request, RPC_INTERNAL_ERROR, "Not implemented")

    # ## shutdown system 
    # def shutdown_system(self, request): 
    #     rospy.loginfo("shutdown system...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)


    # ## restart system 
    # def restart_system(self, request): 
    #     rospy.loginfo("reboot system...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    # ## connect wifi 
    # def connect_wifi(self, request): 
    #     rospy.loginfo("connect wifi...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    # ## diconnect wifi
    # def disconnect_wifi(self, request): 
    #     rospy.loginfo("disconnect wifi...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)
    
    # ## check network status 
    # def network_status(self, request): 
    #     rospy.loginfo("network status...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    # ## check software update 
    # def check_software(self, request): 
    #     rospy.loginfo("check software update...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    # ## download software update 
    # def download_software(self, request): 
    #     rospy.loginfo("download software update...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    # ## install update 
    # def install_software(self, request): 
    #     rospy.loginfo("install software update...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    # ## software update status
    # def software_status(self, request): 
    #     rospy.loginfo("software update status...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    # ## check docker image update 
    # def check_docker(self, request): 
    #     rospy.loginfo("check docker image...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    # ## pull docker image 
    # def pull_docker(self, request): 
    #     rospy.loginfo("pull docker image...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    # ## docker image status
    # def docker_status(self, request): 
    #     rospy.loginfo("docker update status...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    ## battery status 
    def battery_status(self, request): 
        rospy.loginfo("battery status...")
        return jsonrpc_wrap_result(request, {"level": 50, "charging": False})

    ## cpu status 
    def cpu_status(self, request): 
        rospy.loginfo("cpu status...")
        return jsonrpc_wrap_result(request, {"usage": 70})

    ## gpu status 
    def gpu_status(self, request): 
        rospy.loginfo("gpu status...")
        return jsonrpc_wrap_result(request, {"usage": 60})

    ## memory status 
    def memory_status(self, request): 
        rospy.loginfo("memory status...")
        return jsonrpc_wrap_result(request, {"usage": 30})

    ## storage status 
    def storage_status(self, request): 
        rospy.loginfo("storage status...")
        fs = os.statvfs("/")
        total = fs.f_blocks * fs.f_frsize
        free = fs.f_bavail * fs.f_frsize / 1000000
        return jsonrpc_wrap_result(request, {"free": free})

    ## delete files 
    def delete_files(self, request): 
        rospy.loginfo("delete files...")
        return jsonrpc_wrap_error(request, RPC_INTERNAL_ERROR, "Not implemented")

    ## files status 
    def files_status(self, request): 
        rospy.loginfo("files status...")
        location = "/home/camera/camera_data"
        if "params" in request and "location" in request["params"]: 
            location = request["params"]["location"]
        files = [os.path.join(location, f) for f in os.listdir(location)]
        rospy.loginfo("files: {}".format(files))
        return jsonrpc_wrap_result(request, files)

    ## prepre footage  
    def prepare_footage(self, request): 
        rospy.loginfo("prepare footage...")
        return jsonrpc_wrap_error(request, RPC_INTERNAL_ERROR, "Not implemented")

    ## update footage data  
    def update_footage(self, request): 
        rospy.loginfo("update footage...")
        return jsonrpc_wrap_error(request, RPC_INTERNAL_ERROR, "Not implemented")

    ## delete footage 
    def delete_footage(self, request): 
        rospy.loginfo("delete footage...")
        return jsonrpc_wrap_error(request, RPC_INTERNAL_ERROR, "Not implemented")

    ## footage status 
    def footage_status(self, request): 
        rospy.loginfo("footage status...")
        location = "/home/camera/camera_data"
        if "params" in request and "location" in request["params"]: 
            location = request["params"]["location"]
        footages = []
        for f in os.listdir(location):
            if os.path.isdir(os.path.join(location, f)): 
                footages.append({"id": f, "location": os.path.join(location, f)}) 
        rospy.loginfo("footages: {}".format(footages))
        return jsonrpc_wrap_result(request, footages)

    ## handle request by forwarding to camerad service 
    def handle_system_request(self, request):
        rospy.loginfo("Handle system request: {}".format(request))
        json_request = json.dumps(request)
        json_request += "\n"; # json string in line 
        response = {} 
        try: 
            rospy.loginfo("Connting to service: {}".format(self.camerad_addr))
            conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            conn.connect(self.camerad_addr)
            rospy.loginfo("Sending request: {}".format(json_request))
            conn.sendall(json_request.encode())
            rospy.loginfo("Waiting for response")
            conn.setblocking(0)
            rlist, _, _ = select.select([conn], [], [], self.camerad_timeout)
            if rlist: 
                assert rlist[0] == conn 
                json_response = conn.recv(self.RECV_BUFFER_SIZE).decode()
                rospy.loginfo("Received response: {}".format(json_response))
                response = json.loads(json_response)
            else: 
                rospy.loginfo("Response timeout!")
                response = jsonrpc_wrap_error(request, RPC_SERVER_ERROR, "Response timeout from camerad service")
        except socket.error, msg:
            rospy.loginfo("Socket exception: {}".format(msg))
            response = jsonrpc_wrap_error(request, RPC_SERVER_ERROR, "Socket exception to camerad service")
        except: 
            rospy.loginfo("Exception")
            response = jsonrpc_wrap_error(request, RPC_SERVER_ERROR, "Handle system request exception")
        finally: 
            conn.close() 
        return response 


    ## status update thread 
    def status_update_thread(self): 
        rospy.loginfo("Status update thread in")
        update_rate = rospy.get_param("~status_update_rate", 1.0)
        update_rate = update_rate if update_rate > 0 else 1.0
        rospy.loginfo("status update rate: {}".format(update_rate))
        ros_rate = rospy.Rate(update_rate)
        while not rospy.is_shutdown():
            if self.status_pub.get_num_connections() > 0: 
                status = []
                for method in self.subscriptions:
                    request = {"method": method} 
                    try: 
                        response = self.handle_json_request(request)
                        if "result" in response: 
                            notification = {"method": method, "params": response["result"]}
                            status.append(notification)
                    except: 
                        rospy.loginfo("Exception in status update: " + method)
                if status: 
                    status_msg = JsonString() 
                    status_msg.data = json.dumps(status).encode()
                    rospy.loginfo("Publish status topic: {}".format(status_msg))
                    self.status_pub.publish(status_msg)
            ros_rate.sleep() 
        rospy.loginfo("Status update thread out")


def main():
    rospy.init_node("camera")
    CameraNode() 
    rospy.spin()


if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
