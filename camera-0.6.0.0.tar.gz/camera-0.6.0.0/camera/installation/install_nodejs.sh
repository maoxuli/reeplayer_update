#!/usr/bin/env bash 
set -e 

wget https://nodejs.org/dist/v10.24.1/node-v10.24.1-linux-arm64.tar.xz
sudo tar -C /usr/local --strip-components 1 -xJf node-v10.24.1-linux-arm64.tar.xz

sudo npm -g install -y http-server

set +e 
