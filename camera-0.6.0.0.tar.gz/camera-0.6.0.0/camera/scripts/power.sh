#!/usr/bin/env bash 

## This script is used to shutdown/reboot the sytem 
## or magage the power mode of the system 

stop_camera_service () {
  echo "$(date +"%Y-%m-%d %T"): stop camera service..."
  systemctl stop camera
}

power_shutdown () {
  stop_camera_service
  echo "$(date +"%Y-%m-%d %T"): power shutdown..."
  poweroff -p 
}

power_reboot () {
  stop_camera_service 
  echo "$(date +"%Y-%m-%d %T"): power reboot..."
  poweroff --reboot 
}

set_power_mode () {
  echo "$(date +"%Y-%m-%d %T"): set power mode..."
  MODE=$1 
  if [ ! -z "$MODE" ] ; then 
    echo "Set power mode to: ${MODE}"
    # nvpmodel -m ${MODE}
  fi 
}

get_power_status () {
  # nvpmodel -q 
  echo "0"
}

case "$1" in
  "") 
    echo "Usage: $(basename $0) {shutdown|reboot|set_mode|status}"
    exit 1
    ;;
  shutdown) 
    shift 
    power_shutdown "$@"
    ;;
  reboot)
    shift 
    power_reboot "$@"
    ;;
  set_mode)
    shift 
    set_power_mode "$@"
    ;;
  status)
    shift 
    get_power_status "$@"
    ;;
  *) 
    echo "Unknown command: $(basename $0) $1"
    exit 2
    ;;
esac 
