#!/usr/bin/env bash

## The script is used to update the camera software
## Support check, download, and install commands

## "1.1.1.1" is expanded to decimal number string "01010101"
## so each version element support two decimal digits in [0, 99]  
ver() {
    printf "%02d%02d%02d%02d" ${1//./ }
}

update_prepare () {
  SCRIPTS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  echo "SCRIPTS_DIR: ${SCRIPTS_DIR}" 

  ## install_dir/camera_dir/scripts
  INSTALL_DIR="$(readlink -m "${SCRIPTS_DIR}/../..")"
  echo "INSTALL_DIR: ${INSTALL_DIR}"

  ## only work on installation 
  ## with camera directory as a symbal line to camera-x.x.x.x directory 
  CAMERA_DIR="${INSTALL_DIR}/camera"
  echo "CAMERA_DIR: ${CAMERA_DIR}"
  CURRENT_VERSION_DIR="$(readlink -f "${CAMERA_DIR}")"
  echo "CURRENT_VERSION_DIR: ${CURRENT_VERSION_DIR}"
  VERSION_DIR="$(basename "${CURRENT_VERSION_DIR}")"
  echo "VERSION_DIR: ${VERSION_DIR}"
  CURRENT_VERSION="${VERSION_DIR#*-}"
  [[ "${CURRENT_VERSION}" = "camera" ]] && CURRENT_VERSION=""
  echo "CURRENT_VERSION: ${CURRENT_VERSION}"

  ## search the downloaded packages for for updated version 
  LATEST_PACKAGE=""
  LATEST_VERSION="${CURRENT_VERSION}"
  shopt -s nullglob
  for f in ${INSTALL_DIR}/camera-*.tar.gz ; do
    PACKAGE="$f"
    VERSION_DIR="$(basename "${PACKAGE}" .tar.gz)"
    VERSION="${VERSION_DIR##*-}"
    # echo "VERSION: ${VERSION}"
    if [ "$(ver "${VERSION}")" -gt "$(ver "${LATEST_VERSION}")" ] ; then 
      LATEST_VERSION=${VERSION}
      # echo "LATEST_VERSION: ${LATEST_VERSION}"
      LATEST_PACKAGE="${PACKAGE}"
    fi
  done
  shopt -u nullglob
  echo "LATEST_VERSION: ${LATEST_VERSION}" 
  echo "LATEST_PACKAGE: ${LATEST_PACKAGE}"

  ## load setup if exists 
  SETUP_SCRIPT="${SCRIPTS_DIR}/setup.sh"
  if [ -f "${SETUP_SCRIPT}" ]; then
    . "${SETUP_SCRIPT}" load
  else 
    echo "Not found ${SETUP_SCRIPT}"
  fi  
}

software_check () {
  echo "$(date +"%Y-%m-%d %T"): software check..."

  update_prepare 

  ## update URL 
  if [ -z "${UPDATE_URL}" ] ; then 
    echo "UPDATE_URL is not set!"
    return 1 
  fi 
  echo "UPDATE_URL: ${UPDATE_URL}" 

  ## check and download update version info 
  echo "Download version file"
  RESPONSE=$(curl --write-out '%{http_code}' --silent --output /dev/null "${UPDATE_URL}/version.sh")
  if [ ${STATUSCODE} -ne 200 ] ; then
    echo "Download response: ${STATUSCODE}"
    return 1
  fi
  echo "curl --output ${INSTALL_DIR}/version.sh ${UPDATE_URL}/version.sh"
  curl --output "${INSTALL_DIR}/version.sh" "${UPDATE_URL}/version.sh"

  ## load update version info 
  if [ -f "${INSTALL_DIR}/version.sh" ] ; then 
    echo "Load version info"
    . "${INSTALL_DIR}/version.sh" 
    echo "VERSION: ${VERSION}" 
  fi 

  echo ""
  echo "$(date +"%Y-%m-%d %T"): software check done!"
} 

software_download () {
  echo "$(date +"%Y-%m-%d %T"): software download..."

  ## check version info 
  ## which will set the version variable on success
  software_check 

  if [ -z "${VERSION}" ]; then 
    echo "Failed check version info"
    return 1
  fi 

  if [ ! "$(ver "${VERSION}")" -gt "$(ver "${LATEST_VERSION}")" ]; then 
    echo "No updated version available"
    return 0
  fi 

  ## update URL 
  if [ -z "${UPDATE_URL}" ] ; then 
    echo "UPDATE_URL is not set!"
    return 1 
  fi 
  echo "UPDATE_URL: ${UPDATE_URL}" 

  ## download updated version 
  echo "Download updated version package"
  VERSION_PACKAGE="camera-${VERSION}.tar.gz" 
  echo "VERSION_PACKAGE: ${VERSION_PACKAGE}" 
  RESPONSE=$(curl --write-out '%{http_code}' --silent --output /dev/null "${UPDATE_URL}/${VERSION_PACKAGE}")
  if [ ${STATUSCODE} -ne 200; then
    echo "Download response: ${STATUSCODE}"
    return 1
  fi
  echo "curl --output ${INSTALL_DIR}/${VERSION_PACKAGE} ${UPDATE_URL}/${VERSION_PACKAGE}"
  curl --output "${INSTALL_DIR}/${VERSION_PACKAGE}" "${UPDATE_URL}/${VERSION_PACKAGE}"

  echo ""
  echo "$(date +"%Y-%m-%d %T"): software download done!"
}

software_install () {
  echo "$(date +"%Y-%m-%d %T"): software install..."

  update_prepare 

  if [ -z ${CURRENT_VERSION} ]; then 
    echo "Not running in an installed version, skip update!"
    return 1 
  fi 

  ## install the latest package version 
  if [ "$(ver "${LATEST_VERSION}")" -gt "$(ver "${CURRENT_VERSION}")" ] ; then 
    LATEST_VERSION_DIR="${INSTALL_DIR}/camera-${LATEST_VERSION}"
    echo "LATEST_VERSION_DIR: ${LATEST_VERSION_DIR}"
    if [ -d "${LATEST_VERSION_DIR}" ] ; then 
      echo "${LATEST_VERSION_DIR} already exists"
      rm -rf "${LATEST_VERSION_DIR}"
    fi 
    echo "tar -xzf "${LATEST_PACKAGE}" -C "${INSTALL_DIR}""
    tar -xzf "${LATEST_PACKAGE}" -C "${INSTALL_DIR}"
    rm -rf "${LATEST_PACKAGE}"
    ## re-link the camera dir to latest version folder  
    ln -snfr "${LATEST_VERSION_DIR}" "${CAMERA_DIR}"
    ## delete current version folder 
    rm -rf "${CURRENT_VERSION_DIR}"
  else 
    echo "No updated version to install"
  fi

  echo ""
  echo "$(date +"%Y-%m-%d %T"): software install done!"
}

software_status () {
  echo ""
}

case "$1" in
  "") 
    echo "Usage: $(basename $0) {check|download|install|status}"
    exit 1
    ;;
  check) 
    shift 
    software_check "$@"
    ;;
  download) 
    shift 
    software_download "$@"
    ;;
  install) 
    shift 
    software_install "$@"
    ;;
  status) 
    shift 
    software_status "$@"
    ;;
  *) 
    echo "Unknown command: $(basename $0) $1"
    exit 2
    ;;
esac 
        