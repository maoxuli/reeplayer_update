#ifndef __FAST_BLENDERS_H
#define __FAST_BLENDERS_H

#include <opencv2/core.hpp>
#include <opencv2/core/cuda.hpp>
#include <opencv2/core/cuda_stream_accessor.hpp>

namespace videostitching {

class FastBlender 
{
public: 
    virtual ~FastBlender() {}; 

    virtual void prepare(const std::vector<cv::Point> &corners, const std::vector<cv::Size> &sizes, 
                 const std::vector<cv::cuda::GpuMat>& masks) = 0;

    virtual void update(const std::vector<cv::cuda::GpuMat>& masks) = 0; 

    virtual void feed(int index, const cv::cuda::GpuMat& src, cv::cuda::Stream& stream = cv::cuda::Stream::Null()) = 0;

    virtual void blend(cv::cuda::GpuMat& dst, cv::cuda::Stream& stream = cv::cuda::Stream::Null()) = 0;
}; 

class SimpleBlender : public FastBlender
{
public: 
    SimpleBlender(int num_images = 2); 

    void prepare(const std::vector<cv::Point> &corners, const std::vector<cv::Size> &sizes, 
                 const std::vector<cv::cuda::GpuMat>& mask); 

    void update(const std::vector<cv::cuda::GpuMat>& masks); 
    
    void feed(int index, const cv::cuda::GpuMat& src, cv::cuda::Stream& stream = cv::cuda::Stream::Null()); 

    void blend(cv::cuda::GpuMat& dst, cv::cuda::Stream& stream = cv::cuda::Stream::Null());

private: 
    int _num_images; 
    cv::Rect _roi; 
    std::vector<cv::Rect> _rects; 
    std::vector<cv::cuda::GpuMat> _masks; 
    std::vector<cv::cuda::GpuMat> _images; 
}; 

class FastMultiBandBlender : public FastBlender
{
public:
    FastMultiBandBlender(int num_bands = 5, int weight_type = CV_32F);

    void prepare(const std::vector<cv::Point> &corners, const std::vector<cv::Size> &sizes, 
                 const std::vector<cv::cuda::GpuMat>& masks);

    void update(const std::vector<cv::cuda::GpuMat>& masks); 

    void feed(int index, const cv::cuda::GpuMat& src, cv::cuda::Stream& stream = cv::cuda::Stream::Null());

    void blend(cv::cuda::GpuMat& dst, cv::cuda::Stream& stream = cv::cuda::Stream::Null());

private:
    int actual_num_bands_; 
    int weight_type_; //CV_32F or CV_16S

    int num_images_; 
    int num_bands_;
    cv::Rect dst_roi_final_; 
    cv::Rect dst_roi_;

    std::vector<cv::Point> tl_new_;
    std::vector<cv::Point> br_new_;
    std::vector<int> top_; 
    std::vector<int> bottom_; 
    std::vector<int> left_; 
    std::vector<int> right_; 

    // Laplacian pyramid of output image 
    std::vector<cv::cuda::GpuMat> gpu_dst_ups_; 
    std::vector<cv::cuda::GpuMat> gpu_dst_pyr_laplace_;
    std::vector<cv::cuda::GpuMat> gpu_dst_band_weights_;
    cv::cuda::GpuMat gpu_dst_mask_; 

    // Laplacian pyramid of input images 
    std::vector<cv::cuda::GpuMat> gpu_imgs_with_border_;
    std::vector<std::vector<cv::cuda::GpuMat> > gpu_src_pyr_laplace_vec_;
    std::vector<std::vector<cv::cuda::GpuMat> > gpu_src_ups_;

    // Gaussian pyromid of input masks  
    std::vector<cv::cuda::GpuMat> gpu_add_masks_;
    std::vector<cv::cuda::GpuMat> gpu_weight_maps_;   
    std::vector<std::vector<cv::cuda::GpuMat> > gpu_weight_pyr_gauss_vec_;
};

} // namespace videostitching 

#endif 
