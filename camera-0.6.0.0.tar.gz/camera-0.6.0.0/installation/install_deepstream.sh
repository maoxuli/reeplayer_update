#!/usr/bin/env bash 
set -e 

sudo apt-get update && sudo apt install -y \
    libssl1.0.0 \
    libgstreamer1.0-0 \
    gstreamer1.0-tools \
    gstreamer1.0-plugins-good \
    gstreamer1.0-plugins-bad \
    gstreamer1.0-plugins-ugly \
    gstreamer1.0-libav \
    libgstrtspserver-1.0-0 \
    libgstreamer-plugins-base1.0-dev \
    libjansson4=2.11-1

# sudo apt-get install ./deepstream-5.1_5.1.0-1_arm64.deb

set +e 
