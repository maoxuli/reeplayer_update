#ifndef __DETAILED_STITCHER_H
#define __DETAILED_STITCHER_H

#include <opencv2/opencv.hpp>
#include <opencv2/stitching.hpp>

#include <string>
#include <vector>

namespace videostitching {

class DetailedStitcher 
{
public: 
    struct Settings 
    {
        bool preview = false;
        bool try_cuda = false;
        double work_megapix = 0.6;
        double seam_megapix = 0.1;
        double compose_megapix = -1;
        float conf_thresh = 1.f;
    #ifdef HAVE_OPENCV_XFEATURES2D
        std::string features_type = "surf";
        float match_conf = 0.5f;
    #else
        std::string features_type = "orb";
        float match_conf = 0.3f;
    #endif
        int range_width = -1;
        std::string matcher_type = "homography";
        std::string estimator_type = "homography";
        std::string ba_cost_func = "ray";
        std::string ba_refine_mask = "xxxxx";
        bool do_wave_correct = true;
        cv::detail::WaveCorrectKind wave_correct = cv::detail::WAVE_CORRECT_HORIZ;
        std::string warp_type = "spherical";
        int expos_comp_type = cv::detail::ExposureCompensator::GAIN_BLOCKS;
        int expos_comp_nr_feeds = 1;
        int expos_comp_nr_filtering = 2;
        int expos_comp_block_size = 32;
        std::string seam_find_type = "gc_color"; 
        int blend_type = cv::detail::Blender::MULTI_BAND;
        float blend_strength = 5;

        Settings() {}
        Settings(int argc, char* argv[]);

        std::string description() const; 
    };

    DetailedStitcher(const Settings& settings = Settings()); 

    bool Stitch(const std::vector<cv::Mat>& in_images, cv::Mat& out_image, unsigned long stamp = 0); 

private: 
    Settings _settings;

    // cv::Ptr<cv::detail::CudaGraphCutSeamFinder> cuda_seam_finder; 
};

} // namespace videostitching 

#endif 
