#!/usr/bin/env python

import os 
import time
import threading
import json

import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse

from jsonrpc import * 
from footage_uploading.uploading_manager import UploadingManager 

import logging 

class FootageUploader(object): 
    def __init__(self): 
        ## initialize the uploading manager 
        config_file = rospy.get_param("~config_file", "footage_uploader.json")
        self.backup_config_file = rospy.get_param("~backup_config_file", "")
        rospy.loginfo("Loading config file: {}".format(config_file))
        try: 
            with open(config_file) as f: 
                self.settings = json.load(f)
            rospy.logdebug(self.settings)
        except Exception as e: 
            rospy.logerr("Failed loading config file {}: {}".format(config_file, str(e))) 
            raise e

        rospy.loginfo("Initialize uploading manager")
        self.manager = UploadingManager(self.settings)

        ## dispatch service requests to handlers
        ## this is a list of methods that can be procesed in this object  
        self.service_handlers = { 
            'check_config': self.check_config, 
            'update_config': self.update_config, 
            'reset_config': self.reset_config, 
            'save_config': self.save_config, 
            'start_uploading': self.start_uploading, 
            'stop_uploading': self.stop_uploading, 
            'pause_uploading': self.pause_uploading, 
            'resume_uploading': self.resume_uploading, 
            'uploading_status': self.uploading_status,
        }
        rospy.loginfo("Service handlers: {}".format(self.service_handlers.keys()))

        ## A list of status checking methods 
        ## add or remove by status subscribe method 
        self.notifications = [
            'uploading_status',
        ]
        rospy.loginfo("Status notifications: {}".format(self.notifications))

        ## rpc service 
        rpc_service = "rpc"
        rospy.loginfo("Starting service: {}".format(rpc_service))
        rospy.Service(rpc_service, JsonService, self.rpc_service_handler)

        ## status topic 
        status_topic = "status" 
        rospy.loginfo("Advertise topic: {}".format(status_topic))
        self.status_pub = rospy.Publisher(status_topic, JsonString, queue_size=2)

        ## status notification
        ## check and publish state in a thead periodically 
        status_thread = threading.Thread(target=self.status_update_thread)
        status_thread.start()


    ## shutdown the uploading manager 
    def shutdown(self):
        rospy.loginfo("Shutting down the footage uploader") 
        self.manager.shutdown() 


    ## RPC service handler 
    ## JSON string carried by ROS service request and response  
    def rpc_service_handler(self, request): 
        rospy.logdebug("RPC request: {}".format(request.data))
        try: 
            json_request = json.loads(request.data)
            json_response = self.handle_json_request(json_request)
        except Exception as e: 
            json_reponse = jsonrpc_wrap_error(None, JSON_PARSE_ERROR, str(e))
        rospy.logdebug("RPC response: {}".format(json_response))
        return JsonServiceResponse(json.dumps(json_response))


    ## handle JSON-RPC 2.0 request 
    def handle_json_request(self, request): 
        rospy.logdebug("JSON RPC request: {}".format(request))
        if isinstance(request, list): 
            return self.handle_batch_request(request)
        elif isinstance(request, dict): 
            return self.handle_single_request(request)
        else: 
            return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, "The request is neither a list nor an object."); 


    ## handle batch request 
    def handle_batch_request(self, request): 
        rospy.logdebug("Handle batch request: {}".format(request))
        if request: 
            response = [] 
            for req in request: 
                res = self.handle_single_request(req); 
                response.append(res)
            return response
        else: 
            return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, "Empty request list.")            


    ## handle single request 
    def handle_single_request(self, request): 
        rospy.logdebug("Handle single request: {}".format(request))
        if jsonrpc_validate_request(request): 
            return self.process_request(request)
        else: 
            return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, "Failed in validation.")


    ## process request 
    def process_request(self, request): 
        rospy.logdebug("process request: {}".format(request))
        try: 
            method = request["method"]
            if method in self.service_handlers: 
                rospy.logdebug("handle request: {}".format(method))
                params = request["params"] if "params" in request else None 
                result = self.service_handlers[method](params)
                rospy.logdebug("result: {}".format(result))
                return jsonrpc_wrap_result(request, result)
            else: 
                rospy.logerr("unsupported method: {}".format(method))
                return jsonrpc_wrap_error(None, RPC_METHOD_NOT_FOUND, str(method))
        except JsonRpcError as e:
            rospy.logerr("exception: {}".format(str(e)))
            return jsonrpc_wrap_exception(request, e)
        except Exception as e: 
            rospy.logerr("exception: {}".format(str(e)))
            return jsonrpc_wrap_error(None, RPC_INTERNAL_ERROR, str(e))            


    ## check config  
    def check_config(self, params): 
        rospy.logdebug("check config...")
        raise JsonRpcError(RPC_INTERNAL_ERROR, "Not implemented.")


    ## update config  
    def update_config(self, params): 
        rospy.logdebug("update config...")
        raise JsonRpcError(RPC_INTERNAL_ERROR, "Not implemented.")


    ## reset config  
    def reset_config(self, params): 
        rospy.logdebug("reset config...")
        raise JsonRpcError(RPC_INTERNAL_ERROR, "Not implemented.")


    ## save config  
    def save_config(self, params): 
        rospy.logdebug("save config...")
        raise JsonRpcError(RPC_INTERNAL_ERROR, "Not implemented.")


    ## return result/None, or raise JsonRpcError  
    def start_uploading(self, params): 
        rospy.loginfo("start uploading: {}".format(params))
        if not params or "footage_id" not in params: 
            raise JsonRpcError(RPC_INVALID_PARAMS, "Invalid footage_id in params")
        footage_id = params["footage_id"] 
        try: 
            self.manager.start_footage_uploading(footage_id)
        except Exception as e: 
            raise JsonRpcError(RPC_INTERNAL_ERROR, str(e))  


    ## return result/None, or raise JsonRpcError  
    def stop_uploading(self, params): 
        rospy.loginfo("stop uploading: {}".format(params))
        if not params or "footage_id" not in params: 
            raise JsonRpcError(RPC_INVALID_PARAMS, "Invalid footage_id in params")
        footage_id = params["footage_id"] 
        try: 
            self.manager.stop_footage_uploading(footage_id)
        except Exception as e: 
            raise JsonRpcError(RPC_INTERNAL_ERROR, str(e))   


    ## return result/None, or raise JsonRpcError  
    def pause_uploading(self, params): 
        rospy.loginfo("pause uploading: {}".format(params))
        if not params or "footage_id" not in params: 
            raise JsonRpcError(RPC_INVALID_PARAMS, "Invalid footage_id in params")
        footage_id = params["footage_id"] 
        try: 
            self.manager.pause_footage_uploading(footage_id)
        except Exception as e: 
            raise JsonRpcError(RPC_INTERNAL_ERROR, str(e))  


    ## return result/None, or raise JsonRpcError  
    def resume_uploading(self, params): 
        rospy.loginfo("resume uploading: {}".format(params))
        if not params or "footage_id" not in params: 
            raise JsonRpcError(RPC_INVALID_PARAMS, "Invalid footage_id in params")
        footage_id = params["footage_id"] 
        try: 
            self.manager.resume_footage_uploading(footage_id)
        except Exception as e: 
            raise JsonRpcError(RPC_INTERNAL_ERROR, str(e))   


    ## return uploading status for one or more (or all) footage, in one response 
    ## the params could represent one footage, or a list of footage 
    ## none or zero footage indicate for all footages managed by he uploader 
    def uploading_status(self, params): 
        rospy.logdebug("uploading status...")
        try: 
            if params is None or len(params) == 0: 
                footages = self.manager.all_footage()
            elif isinstance(params, list): 
                footages = params 
            else: 
                footages = [params] 
            rospy.logdebug("check uploading status for {}".format(footages))
            statuses = {}
            for footage_id in footages: 
                statuses[footage_id] = self.manager.footage_uploading_status(footage_id)
            return statuses 
        except Exception as e: 
            rospy.logerr("uploading status error: " + str(e))
            raise JsonRpcError(RPC_INTERNAL_ERROR, str(e))  


    ## status update thread 
    def status_update_thread(self): 
        rospy.loginfo("Status update thread in")
        update_rate = self.settings["status_update_rate"] if "status_update_rate" in self.settings else 1.0
        update_rate = update_rate if update_rate > 0 else 1.0
        rospy.loginfo("status update rate: {}".format(update_rate))
        ros_rate = rospy.Rate(update_rate)
        while not rospy.is_shutdown():
            if self.status_pub.get_num_connections() > 0: 
                status = []
                for method in self.notifications:
                    request = {"method": method} 
                    try: 
                        response = self.handle_json_request(request)
                        if "result" in response: 
                            notification = {"method": method, "params": response["result"]}
                            status.append(notification)
                    except Exception as e: 
                        rospy.logwarn("status update exception for {}: {}".format(method, str(e)))
                if status: 
                    try: 
                        status_msg = JsonString(json.dumps(status)) 
                        self.status_pub.publish(status_msg)
                        rospy.logdebug("Publish status message: {}".format(status_msg))
                    except Exception as e: 
                        rospy.logwarn("status publish exception for {}: {} ".format(method, str(e)))
            ros_rate.sleep() 
        rospy.loginfo("Status update thread out")


if __name__ == '__main__':
    try:
        rospy.init_node("footage_uploader", log_level=rospy.DEBUG)
        uploader = FootageUploader() 
        rospy.spin()
        uploader.shutdown() 
    except rospy.ROSInterruptException:
        print("ROS interrupted")
