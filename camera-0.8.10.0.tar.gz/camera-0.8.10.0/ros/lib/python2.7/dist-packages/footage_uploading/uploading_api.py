#!/usr/bin/env python

import requests

class UploadingAPI(object):
    def __init__(self, service_url, token, serial_no): 
        self.service_url = service_url  
        self.token = token 
        self.serial_no = serial_no 

    def post_request(self, endpoint, data):
        url = "{}/{}".format(self.service_url, endpoint) 
        print("URL: {}".format(url))
        headers = {
            "accept": "*/*", 
            "Content-Type": "application/json",
            "Authorization": "Bearer {}".format(self.token)
        }
        print("Headers: {}".format(headers))
        data["serial_no"] = str(self.serial_no)
        print("DATA: {}".format(data))
        print("requests.post(URL, json=DATA, headers=Headers)")
        resp = requests.post(url, json=data, headers=headers)
        print("Response: {}: {}".format(resp.status_code, resp.reason))
        return resp

    def footage_meta_upload(self, footage_id):
        print("footage meta upload")
        resp = self.post_request(
            "footages/footage-meta-upload", 
            {
                "footage_id": footage_id
            }
        )
        if resp.status_code < 400 and "corners_file_address" in resp.json(): 
            return resp.json()["corners_file_address"]
        else: 
            return None 

    def footage_upload(self, footage_id):
        resp = self.post_request(
            "footages/footage-upload", 
            {
                "footage_id": footage_id
            }
        )
        return resp.status_code < 400

    def footage_part_upload(self, footage_id, part_id):
        print("footage part upload")
        resp = self.post_request(
            "footages/footage-part-upload",
            {
                "footage_id": footage_id, 
                "part_id": part_id,
            }
        )
        if resp.status_code < 400 and "file_address" in resp.json(): 
            return resp.json()["file_address"]
        else: 
            return None 

    def footage_upload_progress(self, footage_id, finished, progress):
        print("footage upload progress")
        resp = self.post_request(
            "footages/footage-upload-progress",
            {
                "footage_id": footage_id, 
                "finished": finished, 
                "progress": progress, 
            }
        )
        return resp.status_code < 400

    def footage_part_upload_progress(self, footage_id, part_id, finished, progress):
        resp = self.post_request(
            "footages/footage-part-upload-progress",
            {
                "footage_id": footage_id,
                "part_id": part_id,
                "finished": finished,
                "progress": progress,
            }
        )
        return resp.status_code < 400
