#!/usr/bin/env python 

import json 
import threading
import queue  

import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse
from camera_ros import Uploader  

from concurrent import futures
import grpc

# Uploading service 
from camera_api import uploading_service_pb2, uploading_service_pb2_grpc


class UploadingServicer(uploading_service_pb2_grpc.UploadingServiceServicer):
    """Service to control and monitor footage uploading 
    """
    def __init__(self): 
        super(UploadingServicer, self).__init__()
        ## connect to ROS service of uploader node 
        self.uploader = Uploader() 


    def start(self, request, context):
        """Start uploading 
        """
        rospy.loginfo("Uploading start: {}".format(request.footage_id))
        try: 
            self.uploader.start_uploading(request.footage_id)
            return uploading_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def pause(self, request, context):
        """Pause uploading 
        """
        rospy.loginfo("Uploading pause: {}".format(request.footage_id))
        try: 
            self.uploader.pause_uploading(request.footage_id)
            return uploading_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def resume(self, request, context):
        """Resume the paused uploading 
        """
        rospy.loginfo("Uploading resume: {}".format(request.footage_id))
        try: 
            self.uploader.resume_uploading(request.footage_id)
            return uploading_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def stop(self, request, context):
        """Stop uploading 
        """
        rospy.loginfo("Uploading stop: {}".format(request.footage_id))
        try: 
            self.uploader.stop_uploading(request.footage_id)
            return uploading_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def check_status(self, request, context):
        """Check uploading status 
        """
        rospy.loginfo("Uploading check status for: {}".format(request.footages))
        try: 
            result = self.uploader.uploading_status(request.footages) 
            result = result if result is not None else {}
            statuses = {}
            for footage in result: 
                statuses[footage] = json.dumps(result[footage])
            rospy.loginfo("Uploading check status result: {}".format(statuses))
            return uploading_service_pb2.UploadingStatusResponse(statuses = statuses)
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def watch_status(self, request, context):
        """Watch uploading status, in stream 
        """
        rospy.loginfo("Uploader watch status")
        ## hook on the rpc exit 
        stop_event = threading.Event()
        def on_rpc_done():
            rospy.loginfo("Uploading watch status cancelling...")
            stop_event.set()   
        context.add_callback(on_rpc_done)

        ## queue for status from uploader 
        status_queue = queue.Queue() 
        def on_status(statuses): 
            try: 
                uploading_status = statuses["uploading_status"]
                status_queue.put(uploading_status)
                rospy.logdebug("queue: {}".format(uploading_status))
            except Exception as e: 
                rospy.logwarn("Uploading watch status error: " + str(e))

        rospy.loginfo("Subscribe status message") 
        self.uploader.subscribe_status(on_status) 

        ## waiting until client cancel or exception
        rospy.loginfo("Uploading watch status waiting on status")
        while not stop_event.is_set():
            try: 
                uploading_status = status_queue.get(timeout = 2)
                statuses = {}
                for footage_id in uploading_status: 
                    statuses[footage_id] = json.dumps(uploading_status[footage_id])
                yield uploading_service_pb2.UploadingStatusResponse(statuses = statuses) 
                rospy.logdebug("yield: {}".format(statuses))
            except queue.Empty:
                rospy.logwarn("Uploading watch status queue is empty, could be avoid by larger timeout.") 
                pass 
            except: 
                rospy.logwarn("What exception raised by yield when rpc is done?")
                pass 
        rospy.loginfo("Unsubscribe status message")
        self.uploader.unsubscribe_status() 
        rospy.loginfo("Recording watch status done")


class UploadingServer(object):
    def __init__(self): 
        ## gRPC server  
        num_threads = 4 
        ropy.loginfo("Service thread pool size: {}".format(num_threads))
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=num_threads))

        rospy.loginfo("Serve uploading service")
        uploading_service_pb2_grpc.add_UploadingServiceServicer_to_server(
            UploadingServiceServicer(),
            server
        )
        
        service_port = 50051
        rospy.loginfo("Listen on port: {}".format(service_port))
        self.server.add_insecure_port("[::]:{}".format(service_port))
        self.server.start()


    def wait_for_shutdown(self): 
        self.server.stop( )
        self.server.wait_for_termination()


if __name__ == "__main__":
    rospy.init_node("uploading_server", log_level=rospy.DEBUG)
    server = UploadingServer() 
    try:
        rospy.spin()
    except rospy.ROSInterruptException:
        print("ROS interrupted")
    server.wait_for_shutdown() 
    print("Service shutdown")
