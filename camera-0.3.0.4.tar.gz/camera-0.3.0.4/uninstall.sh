#!/bin/bash

## this script is used to uninstall the camera system software,  
## to stop it from launching with the system startup. 

echo "$(date +"%Y-%m-%d %T"): uninstall camera system..."

## the script is on the root of the install dir  
INSTALL_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "INSTALL_DIR: ${INSTALL_DIR}" 

## uninstall sytemd service 
# echo "uninstall systemd service..."
sudo "${INSTALL_DIR}/scripts/camera_service.sh" uninstall 

echo "$(date +"%Y-%m-%d %T"): install camera system done!"
