#!/usr/bin/env bash 

## This script is used to setup the network 
## Setup and enable/disable the ethernet, WiFi AP & client.

## Setup ethernet working with DHCP  
set_eth_dhcp () {
  echo "Setup ethernet with DHCP"
  cat > /etc/systemd/network/04-eth0.network <<EOF
[Match]
Name=eth0
[Network]
DHCP=yes
LinkLocalAddressing=no
EOF
  echo "Restart systemd.networkd"
  systemctl restart systemd-networkd 
} 

## Setup ethernet working with static IP and gateway 
## set_ethernet_ip --address 192.168.1.22/24 --gateway 192.168.1.1
set_eth_ip () {
  IP="$1"
  GATEWAY="$2"
  [[ -z "${IP}" ]] && IP="169.254.0.1/16"
  [[ -z "${GATEWAY}" ]] && GATEWAY="0.0.0.0"
  echo "Setup ethernet with static IP: ${IP} and Gateway: ${GATEWAY}"
  cat > /etc/systemd/network/04-eth0.network <<EOF
[Match]
Name=eth0
[Network]
Address=$IP
Gateway=$GATEWAY
EOF
  echo "Restart systemd.networkd"
  systemctl restart systemd-networkd 
} 

## Setup WiFi AP with static IP 
## setup_ap_ip --address 10.0.0.1/24 
set_ap_ip () {
  IP="$1"
  [[ -z "$IP" ]] && IP="10.0.0.1/24"
  echo "Setup AP with static IP: ${IP}"
  cat > /etc/systemd/network/12-ap.network <<EOF
[Match]
Name=ap@*
[Network]
LLMNR=no
MulticastDNS=yes
IPMasquerade=yes
Address=$IP
DHCPServer=yes
[DHCPServer]
DNS=1.1.1.1 8.8.8.8
EOF
  echo "Restart systemd.networkd"
  systemctl restart systemd-networkd 
}

## Setup WiFi AP with SSID and password 
## setup_ap_id --ssid Reeplayer --password 123456
set_ap_id () {
  SSID=$1
  PASSWORD=$2
  [[ -z "${SSID}" ]] && SSID="Reeplayer"
  [[ -z "${PASSWORD}" ]] && PASSWORD="Reeplayer"
  echo "Setup AP with SSID: ${SSID}"
  cat > /etc/hostapd/hostapd.conf <<EOF
driver=nl80211
ssid=$SSID
# ssid2="$SSID"
country_code=DE
hw_mode=g
channel=1
auth_algs=1
wpa=2
wpa_passphrase=$PASSWORD
wpa_key_mgmt=WPA-PSK
wpa_pairwise=TKIP
rsn_pairwise=CCMP
EOF
  chmod 600 /etc/hostapd/hostapd.conf
  echo "Restart accesspoint@wlan0.service"
  systemctl restart accesspoint@wlan0.service
}

## Setup wifi client with DHCP 
set_wifi_dhcp () {
  echo "Setup WiFi with DHCP"
  cat > /etc/systemd/network/08-wifi.network <<EOF
[Match]
Name=wl*
[Network]
LLMNR=no
MulticastDNS=yes
DHCP=yes
EOF
  echo "Restart systemd.networkd"
  systemctl restart systemd-networkd 
}

## Setup WiFi client with static IP and gateway 
## set_wifi_ip --address "192.168.1.212/24" --gateway "192.168.1.1"
set_wifi_ip () {
  IP=$1
  GATEWAY=$2 
  [[ -z "${IP}" ]] && IP="192.168.1.212/24"
  [[ -z "${GATEWAY}" ]] && GATEWAY="192.168.1.1"
  echo "Setup WiFi with IP: ${IP} and Gateway: ${GATEWAY}"
  cat > /etc/systemd/network/08-wifi.network <<EOF
[Match]
Name=wl*
[Network]
LLMNR=no
MulticastDNS=yes
Address=$IP
Gateway=$GATEWAY
DNS=$GATEWAY
EOF
  echo "Restart systemd.networkd"
  systemctl restart systemd-networkd 
}

## Setup wifi client with SSID and password
## setup_wifi --ssid "Guest" --password "12345678"
set_wifi_id () {
  SSID=$1 
  PASSWORD=$2 
  [[ -z "${SSID}" ]] && SSID="Guest"
  [[ -z "${PASSWORD}" ]] && PASSWORD=""
  echo "Setup wifi with SSID: ${SSID}"
  cat >/etc/wpa_supplicant/wpa_supplicant-wlan0.conf <<EOF
# The string of ssid and psk should be quoted  
network={
  ssid="$SSID"
  psk="$PASSWORD"
  key_mgmt=WPA-PSK
}
EOF
  chmod 600 /etc/wpa_supplicant/wpa_supplicant-wlan0.conf
  echo "Restart wpa_supplicant@wlan0.service"
  systemctl restart wpa_supplicant@wlan0.service 
}

## get network status  
get_network_status () {
  echo ""
}

## networkd installation and setup 
install_network () {
  SCRIPTS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  echo "SCRIPTS_DIR: ${SCRIPTS_DIR}"

  ## diable network manager 
  echo "Disable NetworkManger..."
  systemctl stop NetworkManager
  systemctl disable NetworkManager

  ## enable systemd.resolved
  echo "Enable systemd.resolved"
  systemctl enable systemd-resolved
  systemctl start systemd-resolved 
  rm /etc/resolv.conf
  ln -s /run/systemd/resolve/resolv.conf /etc/resolv.conf

  ## enable systemd.networkd 
  echo "Enable systemd.networkd"
  systemctl enable systemd-networkd
  mkdir -p /etc/systemd/network
  cp -r "${SCRIPTS_DIR}/systemd-networkd-wait-online.service.d" /etc/systemd/system 

  ## WiFi 
  cp "${SCRIPTS_DIR}/accesspoint@.service" /etc/systemd/system 
  systemctl enable accesspoint@wlan0.service 

  cp -r "${SCRIPTS_DIR}/wpa_supplicant@wlan0.service.d" /etc/systemd/system 
  systemctl unmask wpa_supplicant.service 
  systemctl enable wpa_supplicant@wlan0.service

  ## start 
  set_ap_ip 
  set_ap_id 
  set_wifi_dhcp
  set_wifi_id 
  set_eth_dhcp
}

# uninstall networkd and recover the network manager 
uninstall_network () {
  ## Disable systemd.networkd 
  echo "Disable systemd.networkd"
  systemctl stop systemd-networkd
  systemctl disable systemd-networkd
  rm -f /etc/systemd/network/*.network 

  ## Disable WiFi service 
  echo "Diable WiFi client service"
  systemctl stop wpa_supplicant@wlan0.service 
  systemctl disable wpa_supplicant@wlan0.service 
  systemctl mask wpa_supplicant.service 
  rm -rf /etc/systemd/system/wpa_supplicant@wlan0.service.d

  echo "Disable AP service" 
  systemctl stop accesspoint@wlan0.service 
  systemctl disable accesspoint@wlan0.service 
  rm -f /etc/systemd/system/accesspoint@.service

  ## Disable systemd.resolved
  echo "Disable systemd.resolved"
  systemctl stop systemd-resolved 
  systemctl disable systemd-resolved
  rm -rf /etc/systemd/system/systemd-networkd-wait-online.service.d

  ## Enable network manager 
  echo "Enable NetworkManger..."
  systemctl enable NetworkManager
  systemctl start NetworkManager
}

case "$1" in
  "") 
    echo "Usage: $(basename $0) {install|uninstall|status|"\
         "set_eth_dhcp|set_eth_ip|set_ap_ip|set_ap_id|"\
         "set_wifi_dhcp|set_wifi_ip|set_wifi_id}"
    exit 1
    ;;
  set_eth_dhcp) 
    shift 
    set_eth_dhcp "$@"
    ;;
  set_eth_ip) 
    shift 
    set_eth_ip "$@"
    ;;
  set_ap_ip) 
    shift 
    set_ap_ip "$@"
    ;;
  set_ap_id) 
    shift 
    set_ap_id "$@"
    ;;
  set_wifi_dhcp) 
    shift 
    set_wifi_dhcp "$@"
    ;;
  set_wifi_ip) 
    shift 
    set_wifi_ip "$@"
    ;;
  set_wifi_id) 
    shift 
    set_wifi_id "$@"
    ;;
  status) 
    shift 
    get_network_status "$@"
    ;;
  install) 
    shift 
    install_network "$@"
    ;;
  uninstall) 
    shift 
    uninstall_network "$@"
    ;;
  *) 
    echo "Unknown command: $(basename $0) $1"
    exit 2
    ;;
esac 
