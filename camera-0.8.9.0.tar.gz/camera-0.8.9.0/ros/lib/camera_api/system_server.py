#!/usr/bin/env python

import json 
import threading
import queue  

import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse
from camera_ros import Camera, Recorder 

from concurrent import futures
import grpc

## System service 
from camera_api import system_service_pb2, system_service_pb2_grpc


class SystemServicer(system_service_pb2_grpc.SystemServiceServicer): 
    """Service for system status and operations 
    """
    def __init__(self): 
        super(SystemServicer, self).__init__() 
        ## connect to ROS service of camera node 
        self.camera = Camera() 
        self.recorder = Recorder()


    def shutdown(self, request, context):
        """"Shutdown the camera system 
        """
        rospy.loginfo("System shutdown")
        try: 
            self.camera.shutdown_system() 
            return system_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def restart(self, request, context):
        """Restart the camera system 
        """
        rospy.loginfo("System restart")
        try: 
            self.camera.restart_system() 
            return system_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def enable_live(self, request, context):
        """Enable live pipeline
        """
        rospy.loginfo("Enable live: {}".format(request.message))
        try: 
            self.recorder.enable_live(json.loads(request.message)) 
            return system_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def disable_live(self, request, context):
        """Disable live pipeline
        """
        rospy.loginfo("Disable live")
        try: 
            self.recorder.disable_live() 
            return system_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def check_status(self, request, context):
        """Check the system status, synchronously 
        """
        rospy.loginfo("System check status for: {}".format(request.systems))
        try: 
            result = self.camera.system_status(request.systems) 
            result = result if result is not None else {}
            statuses = {}
            for system in result: 
                statuses[system] = json.dumps(result[system])
            rospy.loginfo("System check status result: {}".format(statuses))
            return system_service_pb2.SystemStatusResponse(statuses = statuses)
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def watch_status(self, request, context):
        """Watch the system status, response in stream
        """
        rospy.loginfo("System watch status")
        ## hook on the rpc exit 
        stop_event = threading.Event()
        def on_rpc_done():
            rospy.loginfo("System watch status cancelling...")
            stop_event.set()   
        context.add_callback(on_rpc_done)

        ## queue for status from system 
        status_queue = queue.Queue() 
        def on_status(statuses): 
            try: 
                system_status = statuses["system_status"]
                status_queue.put(system_status)
                rospy.logdebug("queue: {}".format(system_status))
            except Exception as e: 
                rospy.logwarn("System watch status error: " + str(e))

        rospy.loginfo("Subscribe status message") 
        self.camera.subscribe_status(on_status) 

        ## waiting until client cancel or exception
        rospy.loginfo("System watch status waiting on status")
        while not stop_event.is_set():
            try: 
                system_status = status_queue.get(timeout = 2)
                statuses = {}
                for system in system_status: 
                    statuses[system] = json.dumps(system_status[system])
                yield system_service_pb2.SystemStatusResponse(statuses = statuses) 
                rospy.logdebug("yield: {}".format(statuses))
            except queue.Empty:
                rospy.logwarn("System watch status queue is empty, could be avoid by larger timeout.") 
                pass 
            except: 
                rospy.logwarn("What exception raised by yield when rpc is done?")
                pass 
        rospy.loginfo("Unsubscribe status message")
        self.camera.unsubscribe_status() 
        rospy.loginfo("Recording watch status done")


class SystemServer(object):
    def __init__(self): 
        ## gRPC server  
        num_threads = 4 
        ropy.loginfo("Service thread pool size: {}".format(num_threads))
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=num_threads))

        rospy.loginfo("Serve system service")
        system_service_pb2_grpc.add_SystemServiceServicer_to_server(
            SystemServicer(),
            server
        )
        
        service_port = 50051
        ropy.loginfo("Listen on port: {}".format(service_port))
        self.server.add_insecure_port("[::]:{}".format(service_port))
        self.server.start()


    def wait_for_shutdown(self): 
        self.server.stop( )
        self.server.wait_for_termination()


if __name__ == "__main__":
    rospy.init_node("system_server", log_level=rospy.DEBUG)
    server = SystemServer() 
    try:
        rospy.spin()
    except rospy.ROSInterruptException:
        print("ROS interrupted")
    server.wait_for_shutdown() 
    print("Service shutdown")
