#ifndef __FAST_WARPERS_H
#define __FAST_WARPERS_H

#include <opencv2/core.hpp>
#include <opencv2/core/cuda.hpp>
#include <opencv2/core/cuda_stream_accessor.hpp>
#include <opencv2/stitching/detail/warpers.hpp>

namespace videostitching {

class FastWarper 
{
public: 
    FastWarper(int interpolation = cv::INTER_LINEAR, 
               int border_mode = cv::BORDER_CONSTANT, 
               cv::Scalar border_value = cv::Scalar())
    : _interpolation(interpolation)
    , _border_mode(border_mode)
    , _border_value(border_value)
    {
    }

    virtual ~FastWarper() 
    {
    }; 

    virtual void warp(cv::InputArray src, cv::OutputArray dst, 
                      cv::cuda::Stream& stream = cv::cuda::Stream::Null()); 

protected:
    int _interpolation; 
    int _border_mode; 
    cv::Scalar _border_value; 

    cv::cuda::GpuMat _xmap; 
    cv::cuda::GpuMat _ymap; 
}; 

class UndistortWarper : public FastWarper 
{
public: 
    UndistortWarper(int interpolation = cv::INTER_LINEAR, 
                  int border_mode = cv::BORDER_CONSTANT, 
                  cv::Scalar border_value = cv::Scalar()) 
    : FastWarper(interpolation, border_mode, border_value) 
    {
    }

    virtual cv::Rect prepare(const cv::Size& src_size, cv::InputArray K, cv::InputArray D);

protected: 
    cv::Rect _dst_roi;
}; 

class ProjectWarper : public FastWarper 
{
public: 
    ProjectWarper(int interpolation = cv::INTER_LINEAR, 
                  int border_mode = cv::BORDER_CONSTANT, 
                  cv::Scalar border_value = cv::Scalar()) 
    : FastWarper(interpolation, border_mode, border_value) 
    {
    }

    virtual void set_scale(float scale) = 0; 
    virtual cv::Rect prepare(const cv::Size& src_size, cv::InputArray K, cv::InputArray R) = 0;
    virtual cv::Point2f warpPoint(const cv::Point2f &pt, cv::InputArray K, cv::InputArray R) = 0;

protected: 
    cv::Rect _dst_roi;
}; 

class PlaneWarper : public ProjectWarper, public cv::detail::PlaneWarper
{
public:
    PlaneWarper(float scale = 1, 
                int interpolation = cv::INTER_LINEAR, 
                int border_mode = cv::BORDER_CONSTANT, 
                cv::Scalar border_value = cv::Scalar())
    : ProjectWarper(interpolation, border_mode, border_value) 
    , cv::detail::PlaneWarper(scale) 
    {
    }

    virtual void set_scale(float scale) { setScale(scale); };
    virtual cv::Rect prepare(const cv::Size& src_size, cv::InputArray K, cv::InputArray R);
    virtual cv::Rect prepare(const cv::Size& src_size, cv::InputArray K, cv::InputArray R, cv::InputArray T);

    virtual cv::Point2f warpPoint(const cv::Point2f &pt, cv::InputArray K, cv::InputArray R);
};

class SphericalWarper : public ProjectWarper, public cv::detail::SphericalWarper
{
public:
    SphericalWarper(float scale = 1, 
                    int interpolation = cv::INTER_LINEAR, 
                    int border_mode = cv::BORDER_CONSTANT, 
                    cv::Scalar border_value = cv::Scalar())
    : ProjectWarper(interpolation, border_mode, border_value) 
    , cv::detail::SphericalWarper(scale) 
    {
    }

    virtual void set_scale(float scale) { setScale(scale); };
    virtual cv::Rect prepare(const cv::Size& src_size, cv::InputArray K, cv::InputArray R) CV_OVERRIDE;

    virtual cv::Point2f warpPoint(const cv::Point2f &pt, cv::InputArray K, cv::InputArray R);
};

class CylindricalWarper : public ProjectWarper, public cv::detail::CylindricalWarper
{
public:
    CylindricalWarper(float scale = 1, 
                      int interpolation = cv::INTER_LINEAR, 
                      int border_mode = cv::BORDER_CONSTANT, 
                      cv::Scalar border_value = cv::Scalar())
    : ProjectWarper(interpolation, border_mode, border_value) 
    , cv::detail::CylindricalWarper(scale) 
    {
    }

    virtual void set_scale(float scale) { setScale(scale); };
    virtual cv::Rect prepare(const cv::Size& src_size, cv::InputArray K, cv::InputArray R);

    virtual cv::Point2f warpPoint(const cv::Point2f &pt, cv::InputArray K, cv::InputArray R);
};

} // namespace videostitching 

#endif 
