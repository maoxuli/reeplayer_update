#ifndef __NVGST_SINK_BIN_H__
#define __NVGST_SINK_BIN_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <nvgstpipeline/nvgst_common.h>
#include <nvgstpipeline/nvgst_video_bin.h>
#include <nvgstpipeline/nvgst_snapshot.h>

typedef enum
{
  NVGST_SINK_FAKE,
  NVGST_SINK_RENDER_EGL,
  NVGST_SINK_RENDER_OVERLAY,
  NVGST_SINK_ENCODE_FILE,
  NVGST_SINK_ENCODE_UDP,
  NVGST_SINK_ENCODE_SPLIT_FILES,
} NvGstSinkType;

typedef enum
{
  NVGST_CONTAINER_MP4 = 1,
  NVGST_CONTAINER_MKV
} NvGstContainerType;

typedef enum
{
  NVGST_ENCODER_H264 = 1,
  NVGST_ENCODER_H265,
  NVGST_ENCODER_VP8,
  NVGST_ENCODER_VP9, 
  NVGST_ENCODER_JPEG
} NvGstEncoderFormat;

typedef enum
{
  NVGST_ENCODER_TYPE_HW,
  NVGST_ENCODER_TYPE_SW
}NvGstEncoderType;

typedef struct
{
  NvGstSinkType type;
  NvGstVideoConfig in_config;
  gboolean sync;
  NvGstContainerType container;
  NvGstEncoderFormat codec;
  NvGstEncoderType enc_type;
  gint rate_control;
  gint quant;
  gint bitrate;
  guint profile;
  guint gpu_id;
  gchar *file_location;
  guint udp_port;
  guint rtsp_port;
  guint64 udp_buffer_size;
  guint iframeinterval;
  guint64 max_size_time;
  guint64 max_size_bytes;
  guint64 max_files;
} NvGstSinkEncoderConfig;

typedef struct
{
  NvGstSinkType type;
  NvGstVideoConfig in_config;
  gboolean sync;
  gboolean qos;
  gboolean qos_value_specified;
  guint gpu_id;
  guint nvbuf_memory_type;
  guint display_id;
  guint overlay_id;
  guint offset_x;
  guint offset_y;
  guint width;
  guint height;
} NvGstSinkRenderConfig;

typedef struct
{
  gboolean enable;
  NvGstSinkType type;
  NvGstSinkRenderConfig render_config;
  NvGstSinkEncoderConfig encoder_config;
  gchar *source; 
  guint source_idx;
} NvGstSinkConfig;

typedef struct
{
  GstElement *bin;
  NvGstVideoConvBin in_bin; 
  GstElement *encoder;
  GstElement *codecparse;
  GstElement *mux;
  GstElement *transform; 
  GstElement *sink;
  GstElement *rtppay;
  // support dynamic link to tee 
  GstElement *owner; 
  GstElement *tee; 
  GstPad *teepad;
} NvGstSinkBin;

typedef struct
{
  GstElement *bin;
  NvGstSinkBin sub_bins[MAX_SINK_BINS];
  gint num_bins;
  GMutex lock; 
} NvGstMultiSinkBin;

gboolean parse_sink_config (NvGstSinkConfig * config, 
  GKeyFile * key_file, gchar * group); 

gboolean create_multi_sink_bin (guint num_bins, 
  NvGstSinkConfig * config_array, NvGstMultiSinkBin * bin);

void destroy_dynamic_sink_bin (NvGstMultiSinkBin * bin);

gboolean enable_dynamic_sink (NvGstMultiSinkBin * bin, guint sink_idx);
gboolean disable_dynamic_sink (NvGstMultiSinkBin * bin, guint sink_idx);
gboolean check_dynamic_sink (NvGstMultiSinkBin * bin, guint sink_idx);

gboolean set_file_location (NvGstMultiSinkBin * bin, gchar * location, int idx); 
gchar * get_file_location (NvGstMultiSinkBin * bin, int idx); 

#ifdef __cplusplus
}
#endif

#endif
