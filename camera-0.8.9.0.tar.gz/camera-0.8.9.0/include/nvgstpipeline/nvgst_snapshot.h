#ifndef __NVGST_SNAPSHOT_H__
#define __NVGST_SNAPSHOT_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <nvgstpipeline/nvgst_common.h>

#define MAX_SNAPSHOT_IMAGES 2

typedef struct 
{
  guint color_format;
  guint width;
  guint height;
  guint pitch; 
  guint bytes_per_pixel;
  guint data_size; 
  gchar *buffer;
  guint buffer_size; 
} NvGstImage;

typedef struct 
{
  GstPad *pad; 
  gulong probe;
  GMutex lock;
  GCond cond;
  gboolean trigger; 
  guint image_count; 
  NvGstImage images[MAX_SNAPSHOT_IMAGES]; 
} NvGstSnapshot;

gboolean setup_snapshot (NvGstSnapshot * snapshot, GstPad * pad);
gboolean trigger_snapshop (NvGstSnapshot * snapshot);

#ifdef __cplusplus
}
#endif

#endif
