
"use strict";

let JsonTaskGoal = require('./JsonTaskGoal.js');
let JsonTaskActionFeedback = require('./JsonTaskActionFeedback.js');
let JsonTaskFeedback = require('./JsonTaskFeedback.js');
let JsonTaskActionGoal = require('./JsonTaskActionGoal.js');
let JsonTaskAction = require('./JsonTaskAction.js');
let JsonTaskResult = require('./JsonTaskResult.js');
let JsonTaskActionResult = require('./JsonTaskActionResult.js');

module.exports = {
  JsonTaskGoal: JsonTaskGoal,
  JsonTaskActionFeedback: JsonTaskActionFeedback,
  JsonTaskFeedback: JsonTaskFeedback,
  JsonTaskActionGoal: JsonTaskActionGoal,
  JsonTaskAction: JsonTaskAction,
  JsonTaskResult: JsonTaskResult,
  JsonTaskActionResult: JsonTaskActionResult,
};
