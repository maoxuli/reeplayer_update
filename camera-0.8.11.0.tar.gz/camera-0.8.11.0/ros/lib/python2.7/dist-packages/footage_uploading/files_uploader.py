#!/usr/bin/env python

import os
import threading 
import requests
from concurrent.futures import *

try:
    from urllib.parse import urlparse
except ImportError:
     from urlparse import urlparse

## The files will be pushed into the uploading threads, and transit 
## among below status. We use a file id to indentify the file.  
## there is no limit of the concurrent files number. 

class FilesUploader(object):
    STOPPED = 0 
    FAILED = 1 
    WAITING = 2
    UPLOADING = 3
    UPLOADED = 4 

    def __init__(self, status_callback, max_workers = 5): 
        self.status_callback = status_callback 
        self.executer = ThreadPoolExecutor(max_workers)
        self.futures = {}
        self.lock = threading.Lock()

    ## enqueue a file for uploading, the file will be set to waiting 
    ## state if it is successfully submitted. 
    def add(self, object_id, file_path, url):
        print("files uploader add: {}".format(object_id))
        with self.lock: 
            if object_id not in self.futures: 
                print("submit task {} to the queue".format(object_id))
                future = self.executer.submit(self.uploading, object_id, file_path, url)
                self.futures[object_id] = future 
                future.add_done_callback(self.uploading_done)
    
    ## remove a file form uploading queue. The process may be delayed to complete, 
    ## so the caller should set the status to Stopped if return True 
    def remove(self, object_id): 
        with self.lock: 
            if object_id in self.futures: 
                if not self.futures[object_id].cancel():  
                    raise Exception("Cancle uploading task error")
                del self.futures[object_id]
            
    def uploading(self, object_id, file_path, url):
        print("uploading: {}, {}".format(object_id, file_path)) 
        self.status_callback(object_id, self.UPLOADING)
        try: 
            with open(file_path, "rb") as data:
                resp = requests.put(url, data=data)
                return object_id, resp.status_code, resp.reason
        except Exception as e: 
            print("uploading error: " + str(e))
            return object_id, 499, str(e)

    def uploading_done(self, future): 
        try: 
            object_id, status_code, status_message = future.result() 
            print("uploading done: {}, {}, {}".format(object_id, status_code, status_message))
            with self.lock: 
                print("remove task {} from queue".format(object_id))
                del self.futures[object_id]
            if status_code < 400: 
                self.status_callback(object_id, self.UPLOADED) 
            else: 
                self.status_callback(object_id, self.FAILED, status_message) 
        except CancelledError as e: 
            print("uploading canceled before done")
