#!/usr/bin/env python

import json 
import requests

class UploadingAPI(object):
    def __init__(self, service_url, token, serial_no): 
        self.service_url = service_url  
        self.token = token 
        self.serial_no = serial_no 

    def post_request(self, endpoint, data):
        url = "{}/{}".format(self.service_url, endpoint) 
        print("URL: {}".format(url))
        headers = {
            "accept": "*/*", 
            "Content-Type": "application/json",
            "Authorization": "Bearer {}".format(self.token)
        }
        print("Headers: {}".format(headers))
        data["serial_no"] = str(self.serial_no)
        print("data: {}".format(data))
        print("requests.post(URL, json=data, headers=Headers)")
        resp = requests.post(url, json=data, headers=headers)
        if resp.status_code < 400: 
            try: 
                resp_data = resp.json()
                print("response: {} {}".format(resp.status_code, resp_data))
                return resp_data
            except requests.exceptions.JSONDecodeError as e: 
                print("response status: {} {}".format(resp.status_code, resp.reason))
                pass 
        else: 
            try: 
                resp_data = resp.json() 
            except requests.exceptions.JSONDecodeError as e: 
                resp_data = {"statusCode": resp.status_code, "message": resp.reason}
            print("response error: {}".format(resp_data))
            raise Exception(json.dumps(resp_data))

    def footage_upload(self, footage_id):
        print("footage-upload")
        try: 
            resp_data = self.post_request(
                "footages/footage-upload", 
                {
                    "footage_id": footage_id
                }
            )
        except Exception as e: 
            print("footage-upload error: " + str(e))
            raise e 

    def footage_meta_upload(self, footage_id):
        print("footage-meta-upload")
        try: 
            resp_data = self.post_request(
                "footages/footage-meta-upload", 
                {
                    "footage_id": footage_id
                }
            )
            return resp_data["corners_file_address"]
        except Exception as e: 
            print("footage-meta-upload error: " + str(e))
            raise e 

    def footage_part_upload(self, footage_id, part_id):
        print("footage-part-upload")
        try: 
            resp_data = self.post_request(
                "footages/footage-part-upload",
                {
                    "footage_id": footage_id, 
                    "part_id": part_id,
                }
            )
            return resp_data["file_address"]
        except Exception as e: 
            print("footage-part-upload error: " + str(e))
            raise e 

    def footage_part_upload_progress(self, footage_id, part_id, finished, progress):
        print("footage-part-upload-progress")
        try: 
            resp_data = self.post_request(
                "footages/footage-part-upload-progress",
                {
                    "footage_id": footage_id,
                    "part_id": part_id,
                    "finished": finished,
                    "progress": progress,
                }
            )
        except Exception as e: 
            print("footage-part-upload-progress error: " + str(e))
            raise e

    def footage_upload_progress(self, footage_id, finished, progress):
        print("footage-upload-progress")
        try: 
            resp_data = self.post_request(
                "footages/footage-upload-progress",
                {
                    "footage_id": footage_id, 
                    "finished": finished, 
                    "progress": progress, 
                }
            )
        except Exception as e: 
            print("footage-upload-progress error: " + str(e))
            raise e
