#pragma once

#include <opencv2/core/cuda.hpp>

/**
 * CUDA kernel that calculates the intensity of each pixel in an image,
 * given by: sqrt(ch1^2 + ch2^2 + ch3^2)
 *
 * @param src GpuMat image of type CV_8UC3
 * @param dst GpuMat returns image of type CV_32F
 */
void cudaMagnitude(const cv::cuda::GpuMat& src, cv::cuda::GpuMat& dst);

/**
 * CUDA kernel that performs multiplication between an image and a gain matrix
 *
 * @param src1 GpuMat image of type CV_8UC3
 * @param src2 GpuMat gains matrix of type CV_32F (single channel)
 * @param dst GpuMat returns image adjusted by gain, of type CV_8UC3
 */
void cudaMultiply(const cv::cuda::GpuMat& src1, const cv::cuda::GpuMat& src2, cv::cuda::GpuMat& dst);

/**
 * CUDA kernel that performs computations in each overlap region for each pair of blocks
 *
 * @param block_locations GpuMat with rows containing the blocks corners coordinates
 * @param block_images vector of GpuMat containing all blocks in the panorama
 * @param block_masks vector of GpuMat containing the mask for each block
 * @param I GpuMat mean intensity in the overlap region between each pair of blocks
 * @param N GpuMat number of pixels in the overlap region between each pair of blocks
 * @param skip GpuMat indicates which pair of blocks overlap and which ones don't
 */
void cudaBlockOverlapIntensity(
    const cv::cuda::GpuMat& block_locations,
    const std::vector<cv::cuda::GpuMat>& block_images,
    const std::vector<cv::cuda::GpuMat>& block_masks,
    cv::cuda::GpuMat& I,
    cv::cuda::GpuMat& N,
    cv::cuda::GpuMat& skip);

