#!/bin/bash

VERSION=0.3.1.0