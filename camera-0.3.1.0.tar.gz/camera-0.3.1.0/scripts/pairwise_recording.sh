#!/bin/bash

CAMERA_MODE=1080p
FLIP_METHOD=0
BITRATE=16000000

function print_help { 
  echo "Usage: $0 [-m ${CAMERA_MODE}] [-r ${FLIP_METHOD}] [-q ${BITRATE}] [-h]"
  echo "-m: camera sesnor mode:"
  echo -e "\t 1080p: 1920x1080@30 (default)" 
  echo -e "\t 1440p: 2560x1440@30"
  echo -e "\t 1944p: 2592x1944@30"
  echo -e "\t 3040p: 4032x3040@30"
  echo -e "\t 1848p: 3264x1848@28"
  echo -e "\t 2464p: 3264x2464@21"
  echo "-r: roation of input image:" 
  echo -e "\t 0: no rotation (default)" 
  echo -e "\t 1: counterclockwise - 90 degrees"
  echo -e "\t 2: rotate - 180 degrees"
  echo -e "\t 3: clockwise - 90 degrees"
  echo -e "\t 4: horizontal flip"
  echo -e "\t 5: upper right diagonal flip"
  echo -e "\t 6: vertical flip"
  echo -e "\t 7: upper-left diagonal"
  echo "-q: quality (bitrate in bps)" 
  echo "-h: help"
} 

while getopts ":m:r:q:h" opt; do
  case $opt in
    m) CAMERA_MODE="$OPTARG";;
    r) FLIP_METHOD="$OPTARG";;
    q) BITRATE="$OPTARG";;
    \? | h | *) print_help; exit 0;;
  esac
done

# input 
WIDTH=1920
HEIGHT=1080
FPS=30
# output
OUT_WIDTH=1920
OUT_HEIGHT=1080

case $CAMERA_MODE in
  "1080p") WIDTH=1920; HEIGHT=1080; FPS=30; OUT_WIDTH=1920; OUT_HEIGHT=1080;;
  "1440p") WIDTH=2560; HEIGHT=1440; FPS=30; OUT_WIDTH=2560; OUT_HEIGHT=1440;;
  "1944p") WIDTH=2592; HEIGHT=1944; FPS=30; OUT_WIDTH=2592; OUT_HEIGHT=1944;;
  "3040p") WIDTH=4032; HEIGHT=3040; FPS=30; OUT_WIDTH=4032; OUT_HEIGHT=2160;;
  "1848p") WIDTH=3264; HEIGHT=1848; FPS=28; OUT_WIDTH=3264; OUT_HEIGHT=1848;;
  "2464p") WIDTH=3264; HEIGHT=2464; FPS=21; OUT_WIDTH=3264; OUT_HEIGHT=2160;;
  *) echo "Unknown camera mode: ${CAMERA_MODE}";;
esac

echo "INPUT: ${WIDTH}x${HEIGHT}@${FPS}"
echo "OUTPUT: ${OUT_WIDTH}x${OUT_HEIGHT}@${FPS}"
echo "FLIP_METHOD: ${FLIP_METHOD}" 
echo "BITRATE: ${BITRATE}" 

# cropping 
LEFT_0=$((WIDTH - OUT_WIDTH))
TOP_0=$(((HEIGHT - OUT_HEIGHT) / 2))
RIGHT_0=$((LEFT + OUT_WIDTH))
BOTTOM_0=$((TOP + OUT_HEIGHT))

LEFT_1=0
TOP_1=$(((HEIGHT - OUT_HEIGHT) / 2))
RIGHT_1=$((LEFT + OUT_WIDTH))
BOTTOM_1=$((TOP + OUT_HEIGHT))

echo "LEFT_0: ${LEFT_0}"
echo "TOP_0: ${TOP_0}"
echo "RIGHT_0: ${RIGHT_0}"
echo "BOTTOM_0: ${BOTTOM_0}"

echo "LEFT_1: ${LEFT_1}"
echo "TOP_1: ${TOP_1}"
echo "RIGHT_1: ${RIGHT_1}"
echo "BOTTOM_1: ${BOTTOM_1}"

# file name 
DATE_TIME="$(date +"%Y%m%d_%H_%M_%S_%N")"
FILE_NAME="cam_0_1_${CAMERA_MODE}_${DATE_TIME}.mp4"

set -x

gst-launch-1.0 nvarguscamerasrc sensor-id=0 ! "video/x-raw(memory:NVMM),format=(string)NV12,width=(int)${WIDTH},height=(int)${HEIGHT},framerate=(fraction)${FPS}/1" ! nvvidconv flip-method=${FLIP_METHOD} left=${LEFT_0} top=${TOP_0} bottom=${BOTTOM_0} right=${RIGHT_0} ! "video/x-raw(memory:NVMM),format=(string)NV12,width=(int)${OUT_WIDTH},height=(int)${OUT_HEIGHT},pixel-aspect-ratio=1/1" ! queue ! nvv4l2h264enc maxperf-enable=true bitrate=${BITRATE} ! queue ! h264parse ! muxer.video_0 nvarguscamerasrc sensor-id=1 ! "video/x-raw(memory:NVMM),format=(string)NV12,width=(int)${WIDTH},height=(int)${HEIGHT},framerate=(fraction)${FPS}/1" ! nvvidconv flip-method=${FLIP_METHOD} left=${LEFT_1} top=${TOP_1} bottom=${BOTTOM_1} right=${RIGHT_1} ! "video/x-raw(memory:NVMM),format=(string)NV12,width=(int)${OUT_WIDTH},height=(int)${OUT_HEIGHT},pixel-aspect-ratio=1/1" ! queue ! nvv4l2h264enc maxperf-enable=true bitrate=${BITRATE} ! queue ! h264parse ! muxer.video_1 qtmux name=muxer ! filesink location="${FILE_NAME}" sync=false async=false -e

set +x 