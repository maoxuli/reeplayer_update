#!/bin/bash

set -x 

echo "export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${HOME}/Reeplayer/camera/lib" >> ~/.bashrc 
echo "export GST_PLUGIN_PATH=${GST_PLUGIN_PATH}:${HOME}/Reeplayer/camera/lib/gst-plugins" >> ~/.bashrc 
echo "export PATH=$PATH:${HOME}/Reeplayer/camera/bin" >> ~/.bashrc 

mkdir -p "${HOME}/Reeplayer/camera_log"

set +x 
