#!/usr/bin/env bash

## This script install/uninstall systemd service: camera.service 
##
## Run script camera.sh to launch camera software with system 
## power on and exit the software with power off. 

## systemd units 
SYSTEMD="/etc/systemd/system"
CAMERA_SERVICE="camera.service"

install_camera_service () {
  echo "Prepare to install systemd service..."

  SCRIPTS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  echo "SCRIPTS_DIR: ${SCRIPTS_DIR}"

  ## load setup is exists 
  SETUP_SCRIPT="${SCRIPTS_DIR}/setup.sh"
  if [ -f "${SETUP_SCRIPT}" ]; then
    . "${SETUP_SCRIPT}" load
  else 
    echo "Not found ${SETUP_SCRIPT}"
  fi 
  
  echo ""
  echo "Install ${CAMERA_SERVICE}..."

  if [ -z "${CAMERA_LOG_DIR}" ]; then 
    echo "CAMERA_LOG_DIR is not set, using default!"
    CAMERA_LOG_DIR="camera_log"
  fi 
  CAMERA_LOG_DIR="$HOME/${CAMERA_LOG_DIR}"
  echo "Prepare directory for camera log: ${CAMERA_LOG_DIR}"
  mkdir -p "${CAMERA_LOG_DIR}"

  CAMERA_SERVICE_LOG="${CAMERA_LOG_DIR}/camera_service.log"
  CAMERA_SERVICE_LOG_OLD="${CAMERA_LOG_DIR}/camera_service_old.log"
  echo "Log file for ${CAMERA_SERVICE}: ${CAMERA_SERVICE_LOG}"

  CAMERA_SCRIPT="${SCRIPTS_DIR}/camera.sh"
  echo "Script file for ${CAMERA_SERVICE}: ${CAMERA_SCRIPT}"

  ## compose systemd unit file
  echo "Compose file: ${SCRIPTS_DIR}/${CAMERA_SERVICE}"
  cat >${SCRIPTS_DIR}/${CAMERA_SERVICE} <<EOF
[Unit]
Description=${CAMERA_SERVICE}
Requires=docker.service
After=docker.service
[Service]
Type=simple
User=${USER}
ExecStartPre=$(which bash) -c "mkdir -p ${CAMERA_LOG_DIR} && mv ${CAMERA_SERVICE_LOG} ${CAMERA_SERVICE_LOG_OLD} || true"
ExecStart=${CAMERA_SCRIPT} run 
ExecReload=$(which kill) -s -HUP $MAINPID
Restart=on-failure
RestartSec=5
TimeoutSec=30
StandardOutput=file:${CAMERA_SERVICE_LOG}
StandardError=file:${CAMERA_SERVICE_LOG} 
[Install]
WantedBy=multi-user.target
EOF

  echo ""
  cat ${SCRIPTS_DIR}/${CAMERA_SERVICE}
  echo ""

  ## install systemd unit
  echo "Copy ${SCRIPTS_DIR}/${CAMERA_SERVICE} to ${SYSTEMD}"
  sudo cp ${SCRIPTS_DIR}/${CAMERA_SERVICE} ${SYSTEMD}
  echo "Enable ${CAMERA_SERVICE}"
  sudo systemctl enable ${CAMERA_SERVICE} 
}

uninstall_camera_service () {
  echo "Uninstall ${CAMERA_SERVICE}..."
  if [ -f "${SYSTEMD}/${CAMERA_SERVICE}" ]; then
    echo "Stop ${CAMERA_SERVICE}"
    sudo systemctl stop ${CAMERA_SERVICE}
    echo "Disable ${CAMERA_SERVICE}"
    sudo systemctl disable ${CAMERA_SERVICE}
    echo "Remove ${SYSTEMD}/${CAMERA_SERVICE}"
    sudo rm -f ${SYSTEMD}/${CAMERA_SERVICE}
  fi 
}

case "$1" in
  "") 
    echo "Usage: $(basename $0) {install|uninstall}"
    exit 1
    ;;
  install) 
    shift 
    install_camera_service "$@"
    ;;
  uninstall)
    shift 
    uninstall_camera_service "$@"
    ;;
  *) 
    echo "Unknown command: $(basename $0) $1"
    exit 2
    ;;
esac 
