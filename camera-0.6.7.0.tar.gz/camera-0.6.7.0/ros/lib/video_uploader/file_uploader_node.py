#!/usr/bin/env python3

import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse
import json
from concurrent.futures import ThreadPoolExecutor
import requests as r
import os
from enum import IntEnum
from urllib.parse import urlparse


JSON_PARSE_ERROR = -32700
RPC_INVALID_REQUEST = -32600
RPC_METHOD_NOT_FOUND = -32601
RPC_INVALID_PARAMS = -32602
RPC_INTERNAL_ERROR = -32603
RPC_SERVER_ERROR = -32000

jsonrpc_error_messages = dict(
    [
        (JSON_PARSE_ERROR, "Invalid JSON was received by the server"),
        (RPC_INVALID_REQUEST, "The JSON sent is not a valid Request object"),
        (RPC_METHOD_NOT_FOUND, "The method does not exist / is not available"),
        (RPC_INVALID_PARAMS, "Invalid method parameter(s)"),
        (RPC_INTERNAL_ERROR, "Internal JSON-RPC error"),
        (RPC_SERVER_ERROR, "General server error"),
    ]
)


class JSONRPCError(Exception):
    def __init__(self, error_code):
        self.error_code = error_code
        self.error_message = get_error_message(self.error_code)


def get_error_message(code):
    if code not in jsonrpc_error_messages:
        return ""
    return jsonrpc_error_messages[code]


def jsonrpc_wrap_error(request, code, message):
    response = {"jsonrpc": 2.0, "error": {"code": code, "message": message}}
    if request is not None and "id" in request:
        response["id"] = request["id"]
    return response


def jsonrpc_wrap_result(request, result):
    response = {"jsonrpc": 2.0, "result": result}
    if request is not None and "id" in request:
        response["id"] = request["id"]
    return response


# validate a single JSON-RPC 2.0 request object


def validate_request_fields(request):
    # be a dictionary
    if not isinstance(request, dict):
        print("request is not a dict object")
        return False
    # be jsonrpc 2.0 object
    # if "jsonrpc" not in request or request["jsonrpc"] != "2.0": # be jsonrpc 2.0 object
    #     return false
    # method exists
    if not ("method" in request and isinstance(request["method"], str)):
        return False
    # id is integer, string, or None if it exists
    if "id" in request and not (
        isinstance(request["id"], int)
        or isinstance(request["id"], str)
        or request["id"] is None
    ):
        print("Invalid id")
        return False
    # params is dict, list, or None if it exists
    if "params" in request and not (
        isinstance(request["params"], dict)
        or isinstance(request["params"], list)
        or request["params"] is None
    ):
        print("Invalid params")
        return False
    return True


class UploadingStatus(IntEnum):
    Waiting = 0
    Uploading = 1
    Uploaded = 2
    Failed = 3


class FileUploaderNode:
    def __init__(self) -> None:
        service_name = rospy.get_param("~file_uploader_service")
        status_topic_name = rospy.get_param("~status_topic_name")
        self.config_file_path  = rospy.get_param("~config_file_path")
        self.default_config_file_path  = rospy.get_param("~default_config_file_path")
        self.config = json.loads(open(self.config_file_path, "r").read())
        self.service_handlers = {
            "check_config": self.check_config,
            "update_config": self.update_config,
            "reset_config": self.reset_config,
            "start_upload": self.start_upload,
            "stop_upload": self.stop_upload,
        }
        self.serial_no = os.environ["SERIAL_NUMBER"]
        self.executer = ThreadPoolExecutor(5)
        self.upload_threads_futures = {}
        self.upload_queue_status = {}
        rospy.loginfo("Starting service: {}".format(service_name))
        rospy.Service(service_name, JsonService, self.service_handler)

        self.uploading_status_pub = rospy.Publisher(
            status_topic_name, JsonString, queue_size=2
        )

    def service_handler(self, request):
        rospy.loginfo("camera servcie request: {}".format(request.data))
        json_response = {}
        try:
            json_request = json.loads(request.data)
            json_response = self.handle_json_request(json_request)
        except:
            json_response = jsonrpc_wrap_error(
                None,
                JSON_PARSE_ERROR,
                get_error_message(JSON_PARSE_ERROR),
            )
        response = json.dumps(json_response)
        rospy.loginfo("service response: {}".format(response))
        return JsonServiceResponse(response)

    ## handle JSON-RPC 2.0 request
    def handle_json_request(self, request):
        rospy.loginfo("handle json request: {}".format(request))
        if isinstance(request, list):
            return self.handle_batch_request(request)
        elif isinstance(request, dict):
            return self.handle_single_request(request)
        else:
            return jsonrpc_wrap_error(
                None,
                RPC_INVALID_REQUEST,
                get_error_message(RPC_INVALID_REQUEST),
            )

    ## handle batch request
    def handle_batch_request(self, request):
        rospy.loginfo("handle batch request: {}".format(request))
        if len(request) == 0:
            return jsonrpc_wrap_error(
                None,
                RPC_INVALID_REQUEST,
                get_error_message(RPC_INVALID_REQUEST),
            )
        else:
            response = []
            for requ in request:
                resp = self.handle_single_request(requ)
                response.append(resp)
            return response

    ## handle single request
    def handle_single_request(self, request):
        rospy.loginfo("handle single request: {}".format(request))
        return self.process_request(request)

    ## process request
    def process_request(self, request):
        rospy.loginfo("process request: {}".format(request))
        method = request["method"]
        rospy.loginfo("method: {}".format(method))
        if method in self.service_handlers:
            rospy.loginfo("local handle request: {}".format(request))
            try:
                return self.service_handlers[method](request)
            except KeyError:
                return jsonrpc_wrap_error(
                    request,
                    RPC_INVALID_PARAMS,
                    get_error_message(RPC_INVALID_PARAMS),
                )
        else:
            rospy.loginfo("system handle request: {}".format(request))
            return self.handle_system_request(request)

    def upload_file(self, url, file_path):
        files = {"file": (urlparse(url).path[1:], open(file_path, "rb"))}
        self.upload_queue_status[file_path]["status"] = UploadingStatus.Uploading
        # Note that 
        resp = r.put(url, files=files)
        return file_path, resp.status_code

    def uploading_done(self, file_path, status):
        rospy.loginfo(f"uploading finished {file_path}, {status}")
        if status:
            self.upload_queue_status[file_path]["status"] = UploadingStatus.Uploaded
        else:
            self.upload_queue_status[file_path]["status"] = UploadingStatus.Failed

        update_msg = {
            "file_path": self.upload_queue_status[file_path]["file_path"],
            "status": self.upload_queue_status[file_path]["status"],
            "footage_id": self.upload_queue_status[file_path]["footage_id"],
        }
        self.uploading_status_pub.publish(json.dumps(update_msg))
        return self.upload_queue_status[file_path]["status"] == UploadingStatus.Uploaded

    def add_file_to_queue(self, url, file_path):
        if file_path not in self.upload_threads_futures:
            self.upload_threads_futures[file_path] = self.executer.submit(
                self.upload_file, url, file_path
            )
            return True
        else:
            return False

    def check_config(self, request):
        pass
    def update_config(self, request):
        pass
    def reset_config(self, request):
        pass

    def start_upload(self, request):
        params = request["params"]
        footage_id = params["footage_id"]
        url = params["url"]
        file_path = params["file_path"]
        self.upload_queue_status[file_path] = {
            "file_path": file_path,
            "status": UploadingStatus.Waiting,
            "footage_id": footage_id,
            "url": url,
        }
        return jsonrpc_wrap_result(request, self.add_file_to_queue(url, file_path))

    def stop_upload(self, request):
        params = request["params"]
        file_path = params["file_path"]
        if file_path not in self.upload_threads_futures:
            return jsonrpc_wrap_result(request, True)
        else:
            res = self.upload_threads_futures[file_path].cancel()
            if res:
                self.upload_queue_status.pop(file_path, None)
                self.upload_threads_futures.pop(file_path, None)
                return jsonrpc_wrap_result(request, True)
            else:
                return jsonrpc_wrap_result(request, False)

    def update(self):
        to_remove = []
        to_retry = []

        for file_path, fut in self.upload_threads_futures.items():
            if fut.done():
                file_path, status = fut.result()
                result = self.uploading_done(file_path, status)
                if result:
                    to_remove.append(file_path)
                else:
                    to_retry.append(file_path)

        for item in to_retry:
            self.upload_threads_futures.pop(item, None)
            self.upload_queue_status[item]["status"] = UploadingStatus.Waiting
            self.add_file_to_queue(
                self.upload_queue_status[item]["url"],
                self.upload_queue_status[item]["file_path"],
            )

        for item in to_remove:
            self.upload_queue_status.pop(item, None)
            self.upload_threads_futures.pop(item, None)


if __name__ == "__main__":
    rospy.init_node("file_uploader", log_level=rospy.DEBUG)
    node = FileUploaderNode()
    rate = rospy.Rate(10)  # 10hz
    while not rospy.is_shutdown():
        node.update()
        rate.sleep()
