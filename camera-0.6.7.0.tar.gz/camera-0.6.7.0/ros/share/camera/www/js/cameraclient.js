// ROS bridge connection 
function CameraConnection(callback_error, callback_connected, callback_close) {
    this.ros = new ROSLIB.Ros();

    this.ros.on('error', function(error) {
        callback_error(error);
    });

    this.ros.on('connection', function() {
        callback_connected();
    });

    this.ros.on('close', function() {
        callback_close();
    });

    this.connect = function(hostname) {
        var service_url = 'ws://' + hostname + ":9090";
        this.ros.connect(service_url); 
    }

    this.connected = function() {
        return this.ros.isConnected(); 
    }
}

// Camera API  
// Provided by camera node and cam_status node
function Camera(connection) {
    var statusTopic = new ROSLIB.Topic({
        ros : connection.ros, 
        name: 'camera/status', 
        messageType : 'std_msgs/String'
    });

    this.subscribe = function(callback_status) {
        statusTopic.subscribe(function(message) {
            callback_status(JSON.parse(message.data));  
        });
    }

    var rpcService = new ROSLIB.Service({
        ros : connection.ros,
        name : 'camera/rpc',
        serviceType : 'camera/JsonService'
    });

    var rpcRequest = new ROSLIB.ServiceRequest({
        data : "" 
    });

    var id = 1; 

    this.call_rpc_service = function(request, callback_success, callback_error) {
        request.jsonrpc = "2.0"
        request.id = id++; 
        rpcRequest.data = JSON.stringify(request); 
        rpcService.callService(rpcRequest, function(rpcResponse) {
            response = JSON.parse(rpcResponse.data);
            if (response.hasOwnProperty("result")) {
                var id = response.hasOwnProperty("id") ? response.id : null
                callback_success(id, response.result); 
            }
            else if (response.hasOwnProperty("error")) {
                if (callback_error != null)
                    callback_error(response.error.code, response.error.message);
            }
            else {
                if (callback_error != null)
                    callback_error(-32001, "Invalid RPC response: " + response);
            }
        });
        return id - 1; 
    }
}

// Configuration 
Camera.prototype.check_config = function(params, callback_success, callback_error) {
    var request = {"method": "check_config", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.update_config = function(params, callback_success, callback_error) {
    var request = {"method": "update_config", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.reset_config = function(params, callback_success, callback_error) {
    var request = {"method": "reset_config", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.save_config = function(params, callback_success, callback_error) {
    var request = {"method": "save_config", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// System 
Camera.prototype.shutdown_system = function(callback_success, callback_error) {
    var request = {"method": "shutdown_system"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.restart_system = function(callback_success, callback_error) {
    var request = {"method": "restart_system"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// Network 
Camera.prototype.connect_wifi = function(params, callback_success, callback_error) {
    var request = {"method": "connect_wifi", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.disconnect_wifi = function(callback_success, callback_error) {
    var request = {"method": "disconnect_wifi"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.network_status = function(params, callback_success, callback_error) {
    var request = {"method": "network_status", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// Software update  
Camera.prototype.check_software = function(callback_success, callback_error) {
    var request = {"method": "check_software"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.download_software = function(version, callback_success, callback_error) {
    var request = {"method": "download_software", "params": {"version": version}}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.install_software = function(version, callback_success, callback_error) {
    var request = {"method": "install_software", "params": {"version": version}}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.software_status = function(params, callback_success, callback_error) {
    var request = {"method": "software_status", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// docker image update 
Camera.prototype.check_docker = function(params, callback_success, callback_error) {
    var request = {"method": "check_docker", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.pull_docker = function(params, callback_success, callback_error) {
    var request = {"method": "pull_docker", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.docker_status = function(params, callback_success, callback_error) {
    var request = {"method": "docker_status", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// battery status 
Camera.prototype.battery_status = function(params, callback_success, callback_error) {
    var request = {"method": "battery_status", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// processor status 
Camera.prototype.processor_status = function(params, callback_success, callback_error) {
    var request = {"method": "processor_status", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// memory status 
Camera.prototype.memory_status = function(params, callback_success, callback_error) {
    var request = {"method": "memory_status", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// storage status 
Camera.prototype.storage_status = function(params, callback_success, callback_error) {
    var request = {"method": "storage_status", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// files management
Camera.prototype.delete_files = function(params, callback_success, callback_error) {
    var request = {"method": "delete_files", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Camera.prototype.files_status = function(params, callback_success, callback_error) {
    var request = {"method": "files_status", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// footage management (hide file system level information)
Camera.prototype.footage_status = function(params, callback_success, callback_error) {
    var request = {"method": "footage_status", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// Recorder API
// provided by recorder node  
function Recorder(connection) {
    var statusTopic = new ROSLIB.Topic({
        ros : connection.ros, 
        name: 'recorder/status', 
        messageType : 'std_msgs/String'
    });

    this.subscribe = function(callback_status) {
        statusTopic.subscribe(function(message) {
            callback_status(JSON.parse(message.data));  
        });
    }

    var rpcService = new ROSLIB.Service({
        ros : connection.ros,
        name : 'recorder/rpc_service',
        serviceType : 'camera/JsonService'
    });

    var rpcRequest = new ROSLIB.ServiceRequest({
        data : "" 
    });

    var id = 1; 

    this.call_rpc_service = function(request, callback_success, callback_error) {
        request.jsonrpc = "2.0"
        request.id = id++; 
        rpcRequest.data = JSON.stringify(request); 
        rpcService.callService(rpcRequest, function(rpcResponse) {
            response = JSON.parse(rpcResponse.data);
            if (response.hasOwnProperty("result")) {
                var id = response.hasOwnProperty("id") ? response.id : null
                callback_success(id, response.result); 
            }
            else if (response.hasOwnProperty("error")) {
                if (callback_error != null)
                    callback_error(response.error.code, response.error.message);
            }
            else {
                if (callback_error != null)
                    callback_error(-32001, "Invalid RPC response: " + response);
            }
        });
        return id - 1; 
    }
}

// Configuration 
Recorder.prototype.check_config = function(params, callback_success, callback_error) {
    var request = {"method": "check_config", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.update_config = function(params, callback_success, callback_error) {
    var request = {"method": "update_config", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.reset_config = function(params, callback_success, callback_error) {
    var request = {"method": "reset_config", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.save_config = function(params, callback_success, callback_error) {
    var request = {"method": "save_config", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// Realtime control
Recorder.prototype.enable_recording = function(mode, callback_success, callback_error) {
    var request = {"method": "enable_recording", "params": {"mode": mode}}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.disable_recording = function(callback_success, callback_error) {
    var request = {"method": "disable_recording"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.start_record = function(uuid, callback_success, callback_error) {
    var request = {"method": "start_record", "params": {"uuid": uuid}}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.stop_record = function(callback_success, callback_error) {
    var request = {"method": "stop_record"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.start_stream = function(params, callback_success, callback_error) {
    var request = {"method": "start_stream", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.stop_stream = function(params, callback_success, callback_error) {
    var request = {"method": "stop_stream", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.stitching_snapshot = function(params, callback_success, callback_error) {
    var request = {"method": "stitching_snapshot", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
}; 

Recorder.prototype.recording_snapshot = function(params, callback_success, callback_error) {
    var request = {"method": "recording_snapshot", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Recorder.prototype.recording_status = function(callback_success, callback_error) {
    var request = {"method": "recording_status"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
}; 

// Calibrator API 
// provided by calbirator node 
function Calibrator(connection) {
    var statusTopic = new ROSLIB.Topic({
        ros : connection.ros, 
        name: 'calibrator/status', 
        messageType : 'std_msgs/String'
    });

    this.subscribe = function(callback_status) {
        statusTopic.subscribe(function(message) {
            callback_status(JSON.parse(message.data));  
        });
    }

    var rpcService = new ROSLIB.Service({
        ros : connection.ros,
        name : 'calibrator/rpc_service',
        serviceType : 'camera/JsonService'
    });

    var rpcRequest = new ROSLIB.ServiceRequest({
        data : "" 
    });

    var id = 1; 

    this.call_rpc_service = function(request, callback_success, callback_error) {
        request.jsonrpc = "2.0"
        request.id = id++; 
        rpcRequest.data = JSON.stringify(request); 
        rpcService.callService(rpcRequest, function(rpcResponse) {
            response = JSON.parse(rpcResponse.data);
            if (response.hasOwnProperty("result")) {
                var id = response.hasOwnProperty("id") ? response.id : null
                callback_success(id, response.result); 
            }
            else if (response.hasOwnProperty("error")) {
                if (callback_error != null)
                    callback_error(response.error.code, response.error.message);
            }
            else {
                if (callback_error != null)
                    callback_error(-32001, "Invalid RPC response: " + response);
            }
        });
        return id - 1; 
    }
}

// Configuration
Calibrator.prototype.check_config = function(params, callback_success, callback_error) {
    var request = {"method": "check_config", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.update_config = function(params, callback_success, callback_error) {
    var request = {"method": "update_config", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.reset_config = function(params, callback_success, callback_error) {
    var request = {"method": "reset_config", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.save_config = function(params, callback_success, callback_error) {
    var request = {"method": "save_config", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// Realtime control 
Calibrator.prototype.enable_calibration = function(callback_success, callback_error) {
    var request = {"method": "enable_calibration"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.disable_calibration = function(callback_success, callback_error) {
    var request = {"method": "disable_calibration"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.set_mode = function(mode, callback_success, callback_error) {
    var request = {"method": "set_mode", "params": {"mode": mode}}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.set_source = function(location, callback_success, callback_error) {
    var request = {"method": "set_source", "params": {"location": location}}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.next_frame = function(frame_id, callback_success, callback_error) {
    var request = {"method": "next_frame", "params": {"frame_id": frame_id}}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.prev_frame = function(frame_id, callback_success, callback_error) {
    var request = {"method": "prev_frame", "params": {"frame_id": frame_id}}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.add_frame = function(frame_id, callback_success, callback_error) {
    var request = {"method": "add_frame", "params": {"frame_id": frame_id}}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.remove_frame = function(frame_id, callback_success, callback_error) {
    var request = {"method": "remove_frame", "params": {"frame_id": frame_id}}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.estimate_calib = function(callback_success, callback_error) {
    var request = {"method": "estimate_calib"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.reset_calib = function(callback_success, callback_error) {
    var request = {"method": "reset_calib"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.save_calib = function(location, callback_success, callback_error) {
    var request = {"method": "save_calib", "params": {"location": location}}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Calibrator.prototype.calibration_status = function(callback_success, callback_error) {
    var request = {"method": "calibration_status"};  
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// Uploader API 
// provided by uploader node 
function Uploader(connection) {
    var statusTopic = new ROSLIB.Topic({
        ros : connection.ros, 
        name: 'uploader/status', 
        messageType : 'std_msgs/String'
    });

    this.subscribe = function(callback_status) {
        statusTopic.subscribe(function(message) {
            callback_status(JSON.parse(message.data));  
        });
    }

    var rpcService = new ROSLIB.Service({
        ros : connection.ros,
        name : 'uploader/rpc_service',
        serviceType : 'camera/JsonService'
    });

    var rpcRequest = new ROSLIB.ServiceRequest({
        data : "" 
    });

    var id = 1; 

    this.call_rpc_service = function(request, callback_success, callback_error) {
        request.jsonrpc = "2.0"
        request.id = id++; 
        rpcRequest.data = JSON.stringify(request); 
        rpcService.callService(rpcRequest, function(rpcResponse) {
            response = JSON.parse(rpcResponse.data);
            if (response.hasOwnProperty("result")) {
                var id = response.hasOwnProperty("id") ? response.id : null
                callback_success(id, response.result); 
            }
            else if (response.hasOwnProperty("error")) {
                if (callback_error != null)
                    callback_error(response.error.code, response.error.message);
            }
            else {
                if (callback_error != null)
                    callback_error(-32001, "Invalid RPC response: " + response);
            }
        });
        return id - 1; 
    }
}

// Configuration
Uploader.prototype.check_config = function(params, callback_success, callback_error) {
    var request = {"method": "check_config", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Uploader.prototype.update_config = function(params, callback_success, callback_error) {
    var request = {"method": "update_config", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Uploader.prototype.reset_config = function(params, callback_success, callback_error) {
    var request = {"method": "reset_config", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Uploader.prototype.save_config = function(params, callback_success, callback_error) {
    var request = {"method": "save_config", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

// Realtime control 
Uploader.prototype.enable_uploading = function(callback_success, callback_error) {
    var request = {"method": "enable_uploading"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Uploader.prototype.disable_uploading = function(callback_success, callback_error) {
    var request = {"method": "disable_uploading"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Uploader.prototype.start_uploading = function(params, callback_success, callback_error) {
    var request = {"method": "start_uploading", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Uploader.prototype.pause_uploading = function(params, callback_success, callback_error) {
    var request = {"method": "pause_uploading", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Uploader.prototype.stop_uploading = function(params, callback_success, callback_error) {
    var request = {"method": "stop_uploading", "params": params}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};

Uploader.prototype.uploading_status = function(callback_success, callback_error) {
    var request = {"method": "uploading_status"}; 
    return this.call_rpc_service(request, callback_success, callback_error); 
};
