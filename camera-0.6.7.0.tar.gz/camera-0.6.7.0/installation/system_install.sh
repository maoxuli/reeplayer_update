#!/usr/bin/env bash 
set -e 


## check if current user in docker group 
echo "Add current user to group docker"
sudo usermod -aG docker ${USER}

## enable docker service 
echo "Enable docker service"
sudo systemctl enable docker 

sudo apt-get update

## install docker compose with pip3 
echo "Install docker-compose"
sudo apt-get install -y python3-pip 
sudo -H pip3 install --upgrade pip 
sudo -H pip3 install setuptools docker-compose

## install tools 
echo "Install extra tools"
sudo apt-get install -y v4l-utils curl hostapd libjsoncpp-dev

## prepare installation path 
INSTALL_DIR="/opt/reeplayer"
echo "Prepare install dir: ${INSTALL_DIR}"
sudo mkdir -p ${INSTALL_DIR}
sudo chown $(id -u):$(id -g) ${INSTALL_DIR}

LOG_DIR="$HOME/camera_log"
echo "Prepare log dir: ${LOG_DIR}"
mkdir -p ${LOG_DIR}

DATA_DIR="$HOME/camera_data"
echo "Prepare data dir: ${DATA_DIR}"
mkdir -p ${DATA_DIR}

CALIB_DIR="$HOME/camera_data/calibration"
echo "Prepare calibration dir: ${CALIB_DIR}"
mkdir -p ${CALIB_DIR}

echo "!!! Installation is done, please reboot the system to apply the changes !!!"

set +e 
