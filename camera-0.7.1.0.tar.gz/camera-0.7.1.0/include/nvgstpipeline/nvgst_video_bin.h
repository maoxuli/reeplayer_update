#ifndef __NVGST_VIDEO_BIN_H__
#define __NVGST_VIDEO_BIN_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <nvgstpipeline/nvgst_common.h>

typedef struct 
{
  gchar *format;
  guint flip_method;
  gint left;
  gint top; 
  gint right;
  gint bottom; 
  gint width;
  gint height;  
} NvGstVideoConfig;

typedef struct
{
  GstElement *bin;
  GstElement *queue;
  GstElement *conv;
  GstElement *caps_filter;
} NvGstVideoConvBin;

gboolean create_video_conv_bin (NvGstVideoConfig * config, NvGstVideoConvBin * bin); 

#ifdef __cplusplus
}
#endif

#endif
