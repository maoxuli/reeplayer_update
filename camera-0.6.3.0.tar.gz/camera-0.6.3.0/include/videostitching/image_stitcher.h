#ifndef __IMAGE_STITCHER_H
#define __IMAGE_STITCHER_H

#include <opencv2/opencv.hpp>
#include <opencv2/stitching.hpp>

#include <vector>

namespace videostitching {

class ImageStitcher 
{
public: 
    struct Settings 
    {
        bool divide_images = false;
        cv::Stitcher::Mode mode = cv::Stitcher::PANORAMA;

        Settings() {}
        Settings(int argc, char* argv[]);

        std::string description() const; 
    };

    ImageStitcher(const Settings& settings = Settings()); 

    bool Stitch(const std::vector<cv::Mat>& in_images, cv::Mat& out_image); 

private: 
    Settings _settings;
};

} // namespace videostitching 

#endif 
