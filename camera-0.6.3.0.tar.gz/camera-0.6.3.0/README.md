# Camera

The software system for camera device. 


## Build software system from source code 

By default, the source code on camera device was arranged in file system as below: 

    ~/reeplayer 
    ~/reeplayer/camera                      [camera repo]
    ~/reeplayer/camera_ros/src/camera_ros   [camera_ros repo]
    ~/reeplayer/camera-core                 [camera-core repo]

Before build the software, create the target directory in file system and set its ownership as below: 

    sudo mkdir -p /opt/reeplayer
    sudo chown $(id -u):$(id -g) /opt/reeplayer 

Then the software could be built and installed in docker container, as below: 

    cd ~/reeplayer/camera/docker 
    ./docker_start.sh 
    [In docker container]
    cd camera 
    ./build.sh   

The build process will install the binary version of the system to "~/opt/reeplayer/camera", and meanwhile, it will also generate an installation package, which could be used to deploy the software system to other devices. 

The installation package will be in "~/reeplayer/camera", with name like "camera-0.6.0.tar.gz". 


## Run software for development, debugging, and testing 

On the camera device that used for development, the software system could be built as above and the binary software system was installed in "~/opt/reeplayer/camera". To make the software run with the startup of the device, run below command to "install" the systemd services: 

    cd /opt/reeplayer/camera 
    ./install.sh

To stop the camera software run with system startup, run below script: 

    cd /opt/reeplayer/camera
    ./uninstall.sh 

In addition, all the software modules could be start and stop seperately for debugging and testing. The software modules could also run in its source code location for debugging and testing. Please refer to relevant documents for more details.  

## Install and run software on other target camera devices 

On a new camera device, follow below steps to install the software system: 

1. Download the camera software installation package to local system, for example: 

    ~/Downloads/camera-0.6.0.0.tar.gz 

2. Extract the software to installation directory as below: 

    sudo mkdir /opt/reeplayer
    sudo chown $(id -u):$(id -g) /opt/reeplayer
    tar -xzvf ~/Downloads/camera-0.6.0.0.tar.gz -C /opt/reeplayer 

3. Install the software to make it launch with system startup: 

    cd /opt/reeplayer/camera-0.6.0.0 
    ./install.sh 

After above installation, the "/opt/reeplayer/camera" will be set as the symbol link to "/opt/reeplayer/camera-0.6.0.0". In the future, the upgraded software version will be installed in, e.g. "/opt/reeplayer/camera-0.6.1.0", but the symbol link "/opt/reeplayer/camera" will not change. 

To uninstall the software, run below script: 

    cd /opt/reeplayer/camera 
    ./uninstall.sh 
