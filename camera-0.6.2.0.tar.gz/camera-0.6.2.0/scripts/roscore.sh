#!/usr/bin/env bash

## The script used to start and stop roscore/rosmaster 

## ROS setup 
[ -d "/opt/ros/kinetic" ] && . /opt/ros/kinetic/setup.sh 
[ -d "/opt/ros/melodic" ] && . /opt/ros/melodic/setup.sh 

start_roscore () {
  echo "$(date +"%Y-%m-%d %T"): start roscore/rosmaster..."

  if [ "$USER" == "root" ]; then 
    echo "Supposed to run with non-root user!"
    return 1
  fi 

  SCRIPTS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  echo "SCRIPTS_DIR: ${SCRIPTS_DIR}"

  ## load setup is exists 
  SETUP_SCRIPT="${SCRIPTS_DIR}/setup.sh"
  if [ -f "${SETUP_SCRIPT}" ]; then
    . "${SETUP_SCRIPT}" load
  else 
    echo "Not found ${SETUP_SCRIPT}"
  fi 

  ## log path
  if [ -z "${CAMERA_LOG_DIR}" ]; then 
    echo "CAMERA_LOG_DIR is not set, using default!"
    CAMERA_LOG_DIR="camera_log"
  fi 
  CAMERA_LOG_DIR="$HOME/${CAMERA_LOG_DIR}"
  echo "CAMERA_LOG_DIR: ${CAMERA_LOG_DIR}"
  mkdir -p ${CAMERA_LOG_DIR}

  ## redirect roscore/rosmaster log 
  ROS_LOG="${CAMERA_LOG_DIR}/ros.log"
  echo "ROS_LOG: ${ROS_LOG}"

  echo "Starting roscore/rosmaster"
  roscore >> ${ROS_LOG} 2>&1 &
  ## disable rosout node using below command instead 
  #rosmaster --core >> ${ROS_LOG} 2>&1 &

  ## wait until roscore is launched completly 
  ## to avoid race condition with roslaunch --wait 
  ## ??? may need to wait rosout ???
  wait_cnt=1
  until fff="$(ps ax | grep -i python | grep -i rosmaster)"
  do
    echo "Waiting...${wait_cnt}"
    sleep 1
    wait_cnt=$((wait_cnt+1))
    if [ $wait_cnt -eq 30 ]; then
      echo "Timed out!"
      break
    fi
  done
  sleep 1

  echo "$(date +"%Y-%m-%d %T"): start roscore/rosmaster done!"
}

stop_roscore () {
  echo "$(date +"%Y-%m-%d %T"): stop roscore/rosmaster..."
  echo "Killing roscore/rosmaster"
  killall roscore
  killall rosmaster
  echo "$(date +"%Y-%m-%d %T"): stop roscore/rosmaster done!"
}

case "$1" in
  "") 
    echo "Usage: $(basename $0) {start|stop}"
    exit 1
    ;;
  start) 
    shift 
    start_roscore "$@"
    ;;
  stop) 
    shfit 
    stop_roscore "$@"
    ;;
  *) 
    echo "Unknown command: $(basename $0) $1()"
    exit 2
    ;;
esac 
