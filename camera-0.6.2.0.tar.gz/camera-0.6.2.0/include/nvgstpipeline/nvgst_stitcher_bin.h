#ifndef __NVGST_STITCHER_BIN_H__
#define __NVGST_STITCHER_BIN_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <nvgstpipeline/nvgst_common.h>
#include <nvgstpipeline/nvgst_video_bin.h>

#define NVGST_ELEM_STITCHER "videostitcher"

typedef struct 
{
  gboolean enable; 
  NvGstVideoConfig in_config; 
  NvGstVideoConfig out_config; 
  gboolean passthrough; 
  gchar *stitching_config;
} NvGstStitcherConfig; 

typedef struct
{
  GstElement *bin;
  NvGstVideoConvBin in_bins[MAX_SOURCE_BINS];
  GstElement *stitcher; 
  NvGstVideoConvBin out_bin;
  // snapshot on sink of out_bin
  gulong sink_buffer_probe; 
} NvGstStitcherBin;

// gboolean parse_stitcher_config (NvGstStitcherConfig * config, GKeyFile * key_file, gchar * group); 

gboolean create_stitcher_bin (NvGstStitcherConfig * config, NvGstStitcherBin * bin);

#ifdef __cplusplus
}
#endif

#endif
