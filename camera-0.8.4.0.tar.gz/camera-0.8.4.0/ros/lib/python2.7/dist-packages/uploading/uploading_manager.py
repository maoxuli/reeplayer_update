#!/usr/bin/env python

import os 
import logging 
import threading 
import json
from enum import IntEnum

from uploading_api import UploadingAPI 
from files_uploader import FilesUploader 

## In terms of the uploading status, the footage could be in 
## one of below status. Based on this status. The user's actions 
## of start, stop, pause, resume will transit the status. 
## the status is persitent in .recording file in the footage folder
## with status:code  
class UploadingStatus(IntEnum):
    Stopped = 0
    Paused = 1
    Uploading = 2
    Uploaded = 3


## The footage manages the list of file if the footage is in the status 
## of Paused and Uploading. In this case, the footage will calculate a 
## progress based on the uploading status of each file. 
## In other status, the footage will not mange the file list, the uploading
## progress is either 0 or 100 percent. 

## For each file of the footage, the uploading status only valid when the 
## footage is in uploading or paused status. The uploading status will 
## trinsit among: idle, waiting, uploading, failed, uploaded. 

class Footage(object): 
    def __init__(self, path, api, uploader, settings): 
        self.path = path
        self.api = api 
        self.uploader = uploader 
        self.settings = settings 

        ## retrieve footage id from meta file 
        meta_file_name = self.settings["meta_file"] if "meta_file" in self.settings else "meta.json"
        self.meta_file = os.path.join(self.path, meta_file_name)
        try: 
            logging.info("Loading meta file: {}".format(self.meta_file))
            with open(self.meta_file) as f: 
                self.meta = json.load(f)
                self.id = self.meta["id"]
            logging.info("Footage id: {}".format(self.id))
        except Exception as e: 
            logging.error("Failed loading meta for footage {}: {}".format(path, str(e)))
            raise e

        ## retrieve uploading status from uploading file
        uploading_file_name = self.settings["uploading_file"] if "uploading_file" in self.settings else ".uploading"
        self.uploading_file = os.path.join(self.path, uploading_file_name) 
        if os.path.exists(self.uploading_file): 
            try: 
                logging.info("Loading uploading status file: {}".format(self.uploading_file))
                with open(self.uploading_file) as f: 
                    self.uploading = json.load(f)
                logging.info(self.uploading)
            except Exception as e: 
                print("Failed loading uploading status for footage {}: {}".format(path, str(e)))
                self.uploading = {"status": UploadingStatus.Stopped.value}
                logging.info(self.uploading)
                self.save_uploading_status() 
        else: 
            logging.info("Initialize uploading status for footage: {}".format(path))
            self.uploading = {"status": UploadingStatus.Stopped.value}
            logging.info(self.uploading)
            self.save_uploading_status() 


    ## save the uploading info to file 
    def save_uploading_status(self): 
        try: 
            print("Save uploading status...")
            with open(self.uploading_file, "w+") as f: 
                json.dump(self.uploading, f) 
        except Exception as e: 
            print("Failed save uploading status: " + str(e)) 


    def uploading_status(self): 
        return {"state": UploadingStatus.Stopped.value, "progress": 0}


    ## when we try to start/pause/stop the uploading status 
    ## just set the target status, and waiting for the worker thread to update 
    ## the uploading status 
    def set_status(self, status): 
        self.uploading["status"] = status.value


    def start_file_uploading(self, file): 
        self.api 
        self.uploader 

    
    ## set 
    def set_file_status(self, file_path, status): 
        if file_path in self.meta_files: 
            return self.meta_files[file_path]
        elif file_path in self.video_files: 
            return self.video_files[file_path]
        else: 
            raise FileNotFoundError("Not found {} in {}".format(file_path, self.id))

    ## sync the uploading info with the files in file system 
    def sync_files(self): 
        for filename in os.listdir(self.path):
            file_path = os.path.join(self.path, filename)
            if os.path.isfile(file_path):
                file_id = self.id + "/" + filename
                ext = os.path.splitext(filename)[1]
                if ext == ".mp4" or ext == ".mkv": 
                    self.video_files[file_path] = {
                        "file_path": file_path, 
                        "file_id": file_id, 
                        "status": status
                    }
                elif ext == ".json": 
                    elf.meta_files[file_path] = {
                        "file_path": file_path, 
                        "file_id": file_id, 
                        "status": status
                    }
                else: 
                    logging.warning("Unknown file type: {}".format(ext))


    ## a worker thread will periodically check and update the uploading status 
    ## to make the sync of the status between the footage and the files uploader 
    def update(self): 
        ## if a footage in stopped or uploaded status, there is no necessity to keep 
        ## the status of each file 
        if self.uploading["status"] == UploadingStatus.Stopped or self.uploading["status"] == UploadingStatus.Uploaded: 
            if "meta_files" in self.uploading: 
                del self.uploading["meta_files"]
            if "video_files" in self.uploading: 
                del self.uploading["video_files"]
            self.save_uploading_status() 
        ## if the footage is in paused status, the uploading of the files should be 
        ## canceled, but the file status should kept 
        if self.uploading["status"] == UploadingStatus.Paused: 
            self.update_uploading_files()

        ## if the footage is in uploading status, shedule the uploading of 
        ## the files that is in stopped or failed status 
        if self.uploading["status"] == UploadingStatus.Uploading: 
            self.update_uploading_files() 
            if "meta_files" in self.uploading: 
                for file in self.uploading["meta_files"]:
                    if (file["status"] == FileStatus.Stopped or 
                        file["status"] == FileStatus.Failed and file["retry"] < 5): 
                        if self.start_file(file): 
                            file["status"] = FileStatus.Waiting if self.start_file(file) else FileStatus.Failed 

            if "video_files" in self.uploading: 
                for file in self.uploading["video_files"]:
                    if (file["status"] == FileStatus.Stopped or 
                        file["status"] == FileStatus.Failed and file["retry"] < 5): 
                        if self.start_file(file): 
                            file["status"] = FileStatus.Waiting if self.start_file(file) else FileStatus.Failed 


class UploadingManager(object): 
    def __init__(self, settings): 
        self.settings = settings 
        self.footage_location = (settings["footage_location"] if "footage_location" in settings 
                                 else os.path.join(os.path.expanduser("~"), "camera_data"))

        ## Initialize the uploading API
        service_url = settings["service_url"] if "service_url" in settings else ""
        logging.info("Service URL: {}".format(service_url))
        token_file = (settings["token_file"] if "token_file" in settings 
                      else os.path.join(os.path.expanduser("~"), ".camera/token"))
        logging.info("Token file: {}".format(token_file))
        try: 
            logging.info("Loading toke form file: {}".format(token_file))
            with open(token_file) as f: 
                token = json.load(f) 
            logging.info(token)
        except: 
            logging.error("Failed loading token from file: {}".format(token_file))
            raise Exception("Failed loading token from file: {}".format(token_file))

        serial_file = (settings["serial_file"] if "serial_file" in settings 
                       else os.path.join(os.path.expanduser("~"), ".camera/serial"))
        logging.info("Serial no file: {}".format(serial_file))
        try: 
            logging.info("Loading serial no from file {}".format(serial_file))
            with open(serial_file) as f: 
                serial_no = json.load(f) 
            logging.info(serial_no)
        except: 
            logging.error("Failed loading serial no from file: {}".format(serial_file))
            raise Exception("Failed loading serial no from file: {}".format(serial_file))

        logging.info("Initialize uploading API")
        self.api = UploadingAPI(service_url, token, serial_no) 

        ## Initialize the files uploader 
        uploading_threads = settings["uploading_threads"] if "uploading_thread" in settings else 5 
        logging.info("Initialize files uploader with workers number: {}".format(uploading_threads))
        self.uploader = FilesUploader(self._uploading_status_callback, max_workers=uploading_threads)

        ## the list of footage 
        self.footages = {}
        self.lock = threading.Lock()
        self.stop = threading.Event()
        self.uploading_thread = threading.Thread(target=self._uploading_update_thread)


    def sync_footage(self): 
        with self.lock: 
            ## go through the footage 
            paths = []
            ids = []
            for footage_id in self.footages: 
                footage_path = self.footages[footage_id].path
                if os.path.exists(footage_path): 
                    paths.append(footage_path)
                else:
                    ids.append(footage_id)
            for footage_id in ids: 
                del self.footages[footage_id]
            ## add new footage
            for path in os.listdir(self.footage_location):
                if os.path.join(self.footage_location, path) not in paths:
                    footage = Footage(os.path.join(self.footage_location, path), self.api, self.uploader, self.settings)
                    self.footages[footage.id] = footage 


    def start_footage_uploading(self, footage_id): 
        self.sync_footage() 
        with self.lock: 
            if footage_id not in self.footages: 
                raise Exception("Invalid footage id") 
            self.footages[footage_id].set_status(UploadingStatus.Uploading)


    def stop_footage_uploading(self, footage_id): 
        with self.lock: 
            if footage_id in self.footages: 
                self.footages[footage_id].set_status(UploadingStatus.Stopped)


    def pause_footage_uploading(self, footage_id): 
        with self.lock: 
            if footage_id not in self.footages: 
                raise Exception("Invalid footage id") 
            self.footages[footage_id].set_status(UploadingStatus.Paused)


    def all_footage(self): 
        self.sync_footage() 
        with self.lock: 
            return self.footages.keys()  


    def footage_status(self, footage_id): 
        self.sync_footage() 
        with self.lock: 
            if footage_id not in self.footages: 
                raise Exception("Invalid footage id") 
            return self.footages[footage_id].uploading_status() 


    def _uploading_status_callback(self, file_path, status): 
        logging.info("uploading status: {} {}".format(status, file_path))
        with self.lock:
            for footage_id in self.footages: 
                if self.footages[footage_id].set_file_status(file_path, status): 
                    break 


    def _uploading_update_thread(self): 
        logging.info("uploading update thread in")
        while not self.stop.isSet(): 
            self.sync_footage()
            with self.lock: 
                for footage_id in self.footages: 
                    self.footages[footage_id].update() 
        logging.info("uploading update thread out")
