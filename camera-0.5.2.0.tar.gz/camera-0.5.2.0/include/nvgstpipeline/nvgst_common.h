#ifndef __NVGST_COMMON_H__
#define __NVGST_COMMON_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <gst/gst.h>

GST_DEBUG_CATEGORY_EXTERN (nvgst_pipeline_debug);

#define NVGST_LINK_ELEMENT(elem1, elem2) \
  do { \
    if (!gst_element_link (elem1,elem2)) { \
      GstCaps *src_caps, *sink_caps; \
      src_caps = gst_pad_query_caps ((GstPad *) (elem1)->srcpads->data, NULL); \
      sink_caps = gst_pad_query_caps ((GstPad *) (elem2)->sinkpads->data, NULL); \
      GST_CAT_ERROR (nvgst_pipeline_debug, "Failed to link '%s' (%s) and '%s' (%s)", \
        GST_ELEMENT_NAME (elem1), \
        gst_caps_to_string (src_caps), \
        GST_ELEMENT_NAME (elem2), \
        gst_caps_to_string (sink_caps)); \
      goto done; \
    } \
  } while (0)

#define NVGST_LINK_ELEMENT_FULL(elem1, elem1_pad_name, elem2, elem2_pad_name) \
  do { \
    GstPad *elem1_pad = gst_element_get_static_pad(elem1, elem1_pad_name); \
    GstPad *elem2_pad = gst_element_get_static_pad(elem2, elem2_pad_name); \
    GstPadLinkReturn ret = gst_pad_link (elem1_pad,elem2_pad); \
    if (ret != GST_PAD_LINK_OK) { \
      gchar *n1 = gst_pad_get_name (elem1_pad); \
      gchar *n2 = gst_pad_get_name (elem2_pad); \
      GST_CAT_ERROR (nvgst_pipeline_debug, "Failed to link '%s' and '%s': %d", n1, n2, ret); \
      g_free (n1); \
      g_free (n2); \
      gst_object_unref (elem1_pad); \
      gst_object_unref (elem2_pad); \
      goto done; \
    } \
    gst_object_unref (elem1_pad); \
    gst_object_unref (elem2_pad); \
  } while (0)

#define NVGST_BIN_ADD_GHOST_PAD_NAMED(bin, elem, pad, ghost_pad_name) \
  do { \
    GstPad *gstpad = gst_element_get_static_pad (elem, pad); \
    if (!gstpad) { \
      GST_CAT_ERROR (nvgst_pipeline_debug, "Could not find '%s' in '%s'", pad, GST_ELEMENT_NAME(elem)); \
      goto done; \
    } \
    gst_element_add_pad (bin, gst_ghost_pad_new (ghost_pad_name, gstpad)); \
    gst_object_unref (gstpad); \
  } while (0)

#define NVGST_BIN_ADD_GHOST_PAD(bin, elem, pad) \
  NVGST_BIN_ADD_GHOST_PAD_NAMED (bin, elem, pad, pad)

#define NVGST_BIN_ADD_GHOST_REQUEST_PAD_NAMED(bin, elem, pad, ghost_pad_name) \
  do { \
		GstPad *gstpad = gst_element_get_request_pad (elem, g_strconcat(pad, "_%u", NULL)); \
    if (!gstpad) { \
      GST_CAT_ERROR (nvgst_pipeline_debug, "Could not find '%s' in '%s'", pad, GST_ELEMENT_NAME(elem)); \
      goto done; \
    } \
    gst_element_add_pad (bin, gst_ghost_pad_new (ghost_pad_name, gstpad)); \
    gst_object_unref (gstpad); \
  } while (0) 

#define NVGST_BIN_ADD_GHOST_REQUEST_PAD(bin, elem, pad) \
      NVGST_BIN_ADD_GHOST_REQUEST_PAD_NAMED (bin, elem, pad, pad)

#define NVGST_ELEM_ADD_PROBE(probe_id, elem, pad, probe_func, probe_type, probe_data) \
  do { \
    GstPad *gstpad = gst_element_get_static_pad (elem, pad); \
    if (!gstpad) { \
      GST_CAT_ERROR (nvgst_pipeline_debug, "Could not find '%s' in '%s'", pad, GST_ELEMENT_NAME(elem)); \
      goto done; \
    } \
    probe_id = gst_pad_add_probe(gstpad, (probe_type), probe_func, probe_data, NULL); \
    gst_object_unref (gstpad); \
  } while (0)

#define NVGST_ELEM_REMOVE_PROBE(probe_id, elem, pad) \
  do { \
    if (probe_id == 0 || !elem) { \
        break; \
    } \
    GstPad *gstpad = gst_element_get_static_pad (elem, pad); \
    if (!gstpad) { \
      GST_CAT_ERROR (nvgst_pipeline_debug, "Could not find '%s' in '%s'", pad, GST_ELEMENT_NAME(elem)); \
      break; \
    } \
    gst_pad_remove_probe(gstpad, probe_id); \
    gst_object_unref (gstpad); \
  } while (0)

/**
 * Function to link sink pad of an element to source pad of tee.
 *
 * @param[in] tee Tee element.
 * @param[in] sinkelem downstream element.
 *
 * @return true if link successful.
 */
gboolean link_element_to_tee_src_pad (GstElement * tee, GstElement * sinkelem);

/*
 * Function to replace string with another string.
 * Make sure @ref src is big enough to accommodate replacements.
 *
 * @param[in] str string to search in.
 * @param[in] replace string to replace.
 * @param[in] replace_with string to replace @ref replace with.
 */
void str_replace (gchar * str, const gchar * replace, const gchar * replace_with);

#define NVGST_ELEM_SRC_CAMERA_CSI "nvarguscamerasrc"
#define NVGST_ELEM_CAPS_FILTER "capsfilter"
#define NVGST_ELEM_QUEUE "queue"
#define NVGST_ELEM_TEE "tee"
#define NVGST_ELEM_VIDEO_CONV "nvvidconv"
#define NVGST_ELEM_SINK_FAKESINK "fakesink"
#define NVGST_ELEM_SINK_FILE "filesink"
#define NVGST_ELEM_SINK_OVERLAY "nv3dsink"
#define NVGST_ELEM_EGLTRANSFORM "nvegltransform"
#define NVGST_ELEM_SINK_EGL "nveglglessink"
#define NVGST_ELEM_MUX_MP4 "qtmux"
#define NVGST_ELEM_MKV "matroskamux"
#define NVGST_ELEM_ENC_H264_HW "nvv4l2h264enc"
#define NVGST_ELEM_ENC_H265_HW "nvv4l2h265enc"

#define MAX_SOURCE_BINS 4
#define MAX_SINK_BINS 8

#ifdef __cplusplus
}
#endif

#endif
