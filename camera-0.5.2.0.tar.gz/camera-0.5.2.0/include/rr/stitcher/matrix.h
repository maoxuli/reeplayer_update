/*
 * Copyright (C) 2020 RidgeRun, LLC (http://www.ridgerun.com)
 * All Rights Reserved.
 *
 * The contents of this software are proprietary and confidential to RidgeRun,
 * LLC.  No part of this program may be photocopied, reproduced or translated
 * into another programming language without prior written consent of
 * RidgeRun, LLC.  The user is free to modify the source code after obtaining
 * a software license from RidgeRun.  All source code changes must be provided
 * back to RidgeRun without any encumbrance.
 */

#ifndef __RR_STITCHER_MATRIX_H__
#define __RR_STITCHER_MATRIX_H__

#include <memory>

namespace rr {
namespace stitcher {

/**
* Matrix:
* @rows: Number of rows of the matrix.
* @columns: Number of columns of the matrix.
* @sizeOfType: size of the data type.
* @data: Data array.
*
* Data information.
*/

template <typename T>
class Matrix {
 private:
  int _rows = 0;
  int _columns = 0;
  int _sizeOfType = sizeof(T);

 public:
  void *stream = nullptr;
  std::shared_ptr<T[]> data;

  Matrix() {}

  Matrix(int rows, int columns) : _rows(rows), _columns(columns) {
    data = std::shared_ptr<T[]>(new T[rows * columns], free);
  }

  Matrix(int rows, int columns, std::shared_ptr<T[]> inputData) : _rows(rows),
    _columns(columns), data(inputData) {
  }

  int rows() const {
    return _rows;
  }

  int columns() const {
    return _columns;
  }

  int sizeOfType() const {
    return _sizeOfType;
  }

  int size() const {
    return _rows * _columns * _sizeOfType;
  }
};

} // namespace stitcher
} // namespace rr

#endif //__RR_STITCHER_MATRIX_H__
