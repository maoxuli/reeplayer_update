#!/usr/bin/env bash

IMAGE="reeplayer/camera:ros-opencv-4.4.0-deepstream-l4t-6.0-samples"
DOCKER=""

OPTIONS="-it"
DIPLAY_ENV=""
USER_ENV="-e CAMERA_UID=$(id -u) -e CAMERA_GID=$(id -g)"
DOCKER_NAME=""

# Display help 
function usage()
{
cat <<EOF
Usage: $(basename $0) [options] ...
OPTIONS:
    -h, --help             Display this help and exit.
    -i, --image <image>    Specify the docker image.
    -d, --daemon           Run the conatiner in background mode.
    -g, --gui              Run container for GUI application.  
    -r, --root             Run container with root user.  
    -n, --name <name>      Specify the name of the docker container.
EOF
exit 0
}

while [ $# -gt 0 ]
do
    case "$1" in
    -h | --help )       usage
                        exit
                        ;;
    -i | --image )      shift
                        IMAGE=$1
                        ;;
    -d | --daemon )     OPTIONS="-itd"
                        ;;
    -g | --gui )        DISPLAY_ENV="-e DISPLAY=$DISPLAY"
                        ;;
    -r | --root )       USER_ENV=""
                        ;;
    -n | --name )       shift
                        DOCKER=$1
                        ;;    
    *)                  usage
                        exit 1
    esac
    shift
done

echo "Docker image: $IMAGE"

if [[ "$(docker images -q $IMAGE 2> /dev/null)" == "" ]] ; then
    echo "Pulling docker image $IMAGE"
    docker pull $IMAGE 
    if [ $? -ne 0 ] ; then 
        error "Failed to pull docker image."
        exit 1
    fi
    echo "Pulled docker image." 
fi

if [ ! -z "$DOCKER" ] ; then 
    echo "Docker name: $DOCKER"
    DOCKER_NAME="--name $DOCKER"
    # kill running container 
    if [ "$(docker ps -qa -f name=^/$DOCKER$)" ]; then
        echo "Remove running container: $DOCKER"
        docker stop "$DOCKER" >/dev/null
        docker rm -v -f "$DOCKER" 2>/dev/null
    fi
fi 

# by default the docker container mount two directories 
# from host system: a installation directory in any position 
# and a development directory in home directory. 
INSTALL_DIR="/opt/reeplayer"
SOURCE_DIR="reeplayer"

# prepare installation directory 
echo "Prepare directory: ${INSTALL_DIR}"
if [ ! -d "${INSTALL_DIR}" ]; then
    mkdir "${INSTALL_DIR}"
fi

# prepare source code directory 
echo "Prepare directory: $HOME/${SOURCE_DIR}"
if [ ! -d "$HOME/${SOURCE_DIR}" ]; then
    mkdir "$HOME/${SOURCE_DIR}"
fi

# docker run 
echo "Starting docker container $DOCKER"
docker run ${OPTIONS} \
    --rm \
    --privileged \
    --net=host \
    ${DISPLAY_ENV} \
    ${USER_ENV} \
    -e NVIDIA_VISIBLE_DEVICES=all \
    -e NVIDIA_DRIVER_CAPABILITIES=compute,utility,video \
    -v $HOME/.Xauthority:/root/.Xauthority:rw \
    -v /tmp/.X11-unix/:/tmp/.X11-unix \
    -v /tmp/argus_socket:/tmp/argus_socket \
    -v /usr/src:/usr/src \
    -v /usr/lib/pkgconfig:/usr/lib/pkgconfig \
    -v ${INSTALL_DIR}:${INSTALL_DIR} \
    -v $HOME/.ros:/home/camera/.ros \
    -v $HOME/camera_log:/home/camera/camera_log \
    -v $HOME/camera_data:/home/camera/camera_data \
    -v $HOME/${SOURCE_DIR}:/home/camera/${SOURCE_DIR} \
    -w /home/camera/${SOURCE_DIR} \
    ${DOCKER_NAME} \
    $IMAGE
