#ifndef __LIVE_STITCHER_H
#define __LIVE_STITCHER_H

#include <opencv2/opencv.hpp>
#include <opencv2/stitching.hpp>
#include <opencv2/cudabgsegm.hpp>
#include "opencv2/cudafilters.hpp"

#include <videostitching/fast_warpers.h>
#include <videostitching/fast_blenders.h>
#include <videostitching/fast_compensator.h>
#include <videostitching/cudaBlocksGainCompensator.h>
#include <videostitching/gpu_seam_finder.hpp>

#include <thread>
#include <atomic>
#include <mutex>
#include <condition_variable>

namespace videostitching {

class LiveStitcher
{
public: 
    struct Settings
    {
        std::string camera_info; 
        std::string camera_params;
        std::string warp_type = "spherical"; // shperical | cylindrical | plane 
        std::string expos_comp_type = "no"; // no, gain, gain_blocks
        int expos_comp_nr_feeds = 3;
        int expos_comp_nr_filtering = 3;
        int expos_comp_block_size = 32;
        double expos_comp_scale = -1; 
        int expos_comp_interval = 1800; 
        std::string seam_type = "no"; // no, graphcut
        int seam_find_iterations = 10;
        int seam_find_terminal_cost = (int)1e7;
        int seam_find_window_min = 9;
        int seam_find_window_max = 23;
        int seam_find_bad_penalty = (int)1e7;
        int seam_find_gap_width = 5;
        double seam_scale = 0.1; 
        std::string blend_type = "no"; // no, feather, multiband 
        int blend_margin = 10; 
        int num_bands = 5; 

        int buffer_size = 4;

        explicit Settings(const std::string& config = ""); 
        std::string to_string() const; 
    };

    LiveStitcher(const Settings& settings);
    ~LiveStitcher();

    // initialize the stitcher for input image size 
    void prepare(const cv::Size& in_size, bool enable_async = false); 

    // the application may need to know the output size
    // to complete configuration before processing
    cv::Size output_size() const { return _output_size; };

    // sync processing 
	bool process(const std::vector<cv::cuda::GpuMat>& in_images, cv::cuda::GpuMat& out_image, 
                 cv::cuda::Stream& stream = cv::cuda::Stream::Null()); 

    // async input 
    bool feed(const std::vector<cv::cuda::GpuMat>& in_images, uint64_t timestamp = 0, 
              cv::cuda::Stream& stream = cv::cuda::Stream::Null()); 

    // async output 
    bool fetch(cv::cuda::GpuMat& out_image, uint64_t& timestamp); 

    // async callback for output 
    typedef std::function<void (cv::cuda::GpuMat&, uint64_t)> callback_t;
    void set_output_callback(const callback_t& cb) { _output_callback = cb; };

private:
    Settings _settings;
    int _num_cameras;     
    uint64_t _frame_count;

    cv::Size _input_size; 
    cv::Size _output_size;
    cv::cuda::GpuMat _output_image; // BGR 

    // undistortion 
    void prepare_undistortion(); 
    cv::Ptr<UndistortWarper> _undistorter; 
    cv::Rect _undistorted_roi;   
    std::vector<cv::cuda::GpuMat> _undistorted_images;

    // projection warping 
    void prepare_warping();
    std::vector<cv::Ptr<ProjectWarper> > _warpers;
    std::vector<cv::Rect> _warped_rects;
    std::vector<cv::Point> _warped_corners; 
    std::vector<cv::Size> _warped_sizes; 
    std::vector<cv::Rect> _crop_rects; 
    std::vector<cv::Rect> _output_rects; 
    std::vector<cv::cuda::GpuMat> _warped_masks; 
    std::vector<cv::cuda::GpuMat> _warped_images;

    // compensate exposure for warped images 
    void prepare_compensation(); 
    cv::Ptr<ExposureCompensator> _compensator;
    std::vector<cv::Point> _expos_comp_corners; // after scale 
    std::vector<cv::UMat> _expos_comp_images;
    std::vector<cv::UMat> _expos_comp_masks; // after scale, so indicate scaled size n
    std::vector<cv::cuda::GpuMat> _expos_comp_maps; // same size of warped images

    // blend overalap region of the warped images 
    void prepare_blending(); 
    cv::Ptr<FastBlender> _blender; 
    std::vector<cv::Rect> _blend_rects; 
    std::vector<cv::Point> _blend_corners;
    std::vector<cv::Size> _blend_sizes; 
    std::vector<cv::cuda::GpuMat> _blend_masks; 
    std::vector<cv::cuda::GpuMat> _seam_masks; 
    cv::cuda::GpuMat _blended_image; 
    cv::Rect _blended_rect; 

    // seam finding for blending 
    void prepare_seam_finding(); 
    cv::Ptr<cv::detail::CudaGraphCutSeamFinder> _seam_finder; 

    void enable_async_processing();
    void disable_async_processing(); 

    std::atomic<bool> _async_processing; 
    callback_t _output_callback; 

    // we use a series of buffer queues and processing threads to 
    // work as a circle pipeline. Each processing thread waiting on 
    // the previous buffer queue, processing on the frame buffer, 
    // and push the buffer to next buffer queue. 

    struct FrameBuffer
    {
        uint64_t frame_id; 
        uint64_t timestamp;
        std::vector<cv::cuda::GpuMat> input_images; // BGR
        std::vector<cv::cuda::GpuMat> warped_images; 
        cv::cuda::GpuMat output_image; // RGBA
    };

    // buffer pool
    std::deque<std::shared_ptr<FrameBuffer> > _buffer_pool; 
    std::mutex _buffer_pool_mutex; 
    std::condition_variable _buffer_pool_cond;

    // after pre-processing
    std::deque<std::shared_ptr<FrameBuffer> > _input_queue; 
    std::mutex _input_queue_mutex; 
    std::condition_variable _input_queue_cond;

    // after warping 
    std::deque<std::shared_ptr<FrameBuffer> > _warped_queue; 
    std::mutex _warped_queue_mutex; 
    std::condition_variable _warped_queue_cond; 

    // after post-processing
    std::deque<std::shared_ptr<FrameBuffer> > _output_queue; 
    std::mutex _output_queue_mutex; 
    std::condition_variable _output_queue_cond; 

    // warping  
    void warping_thread(); 
    std::thread _warping_thread; 

    // stitching     
    void stitching_thread(); 
    std::thread _stitching_thread; 

    // async output 
    void output_thread(); 
    std::thread _output_thread; 
};

} // namespace videostitching

#endif 
