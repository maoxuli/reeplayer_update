#ifndef __NVGST_SOURCE_BIN_H__
#define __NVGST_SOURCE_BIN_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <nvgstpipeline/nvgst_common.h>

typedef struct
{
  gchar *sensors; 
  gint master_sensor; 
  gint sensor_mode; 
  gint fps_n;
  gint fps_d;
  gint width;
  gint height;
  gchar *format; 
  guint flip_method; 
  guint sync_threshold;
} NvGstSourceConfig;

typedef struct
{
  GstElement *bin;
  GstElement *src_elem;
  GstElement *caps_filter;
} NvGstSourceBin;

gboolean parse_source_config (NvGstSourceConfig * config, GKeyFile * key_file, gchar * group);

gboolean create_source_bin (NvGstSourceConfig * config, NvGstSourceBin * bin); 

// dynamic settings for sensor 
float set_source_contrast (GstElement *src_ele, float value);
float set_source_saturation (GstElement *src_ele, float value);
int set_source_auto_exposure_mode (GstElement *src_ele, int value);
float set_source_exposure_time (GstElement *src_ele, float value);
int set_source_auto_exposure_lock(GstElement *src_ele, int value);
int set_source_whitebalance_mode(GstElement *src_ele, int value);
int set_source_scene_mode(GstElement *src_ele, int value);
int set_source_color_effect_mode(GstElement *src_ele, int value);
int set_source_ee_mode(GstElement *src_ele, int value);
float set_source_ee_strength (GstElement *src_ele, float value);
int set_source_flash_mode(GstElement *src_ele, int value);
int set_source_flicker_mode(GstElement *src_ele, int value);
int set_source_tnr_mode (GstElement *src_ele,  int value);
float set_source_tnr_strength (GstElement *src_ele, float value);

#ifdef __cplusplus
}
#endif

#endif
