import random

JSON_PARSE_ERROR = -32700
RPC_INVALID_REQUEST = -32600
RPC_METHOD_NOT_FOUND = -32601
RPC_INVALID_PARAMS = -32602
RPC_INTERNAL_ERROR = -32603
RPC_SERVER_ERROR = -32000

jsonrpc_error_messages = dict([
    (JSON_PARSE_ERROR, "Invalid JSON was received by the server"),
    (RPC_INVALID_REQUEST, "The JSON sent is not a valid Request object"),
    (RPC_METHOD_NOT_FOUND, "The method does not exist / is not available"),
    (RPC_INVALID_PARAMS, "Invalid method parameter(s)"),
    (RPC_INTERNAL_ERROR, "Internal JSON-RPC error"),
    (RPC_SERVER_ERROR, "General server error"),
])


def get_error_message(code):
    if code not in jsonrpc_error_messages:
        return ""
    return jsonrpc_error_messages[code]


class JsonRpcError(Exception):
    def __init__(self, code, message = None):
        self.code = code
        self.message = get_error_message(self.code)
        if self.message and message: 
            self.message = "{} - {}".format(self.message, message) 
        elif message: 
            self.message = message 
        super(JsonRpcError, self).__init__("{} - {}".format(self.code, self.message))


def jsonrpc_wrap_exception(request, e): 
    response = {"jsonrpc": 2.0, "error": {"code": e.code, "message": e.message}}
    if request is not None and "id" in request:
        response["id"] = request["id"]
    return response


def jsonrpc_wrap_error(request, code, message):
    error_message = get_error_message(code)
    if error_message and message: 
        error_message = "{} - {}".format(error_message, message) 
    elif message: 
        error_message = message 
    response = {"jsonrpc": 2.0, "error": {"code": code, "message": error_message}}
    if request is not None and "id" in request:
        response["id"] = request["id"]
    return response


def jsonrpc_wrap_result(request, result):
    response = {"jsonrpc": 2.0, "result": result}
    if request is not None and "id" in request:
        response["id"] = request["id"]
    return response


def jsonrpc_wrap_request(method, params = None): 
    request = {"id": random.randint(0, 1000), "jsonrpc": 2.0, "method": method}
    if params: 
        request["params"] = params 
    return request 


# validate a single JSON-RPC 2.0 request object
def jsonrpc_validate_request(request):
    ## be a dictionary 
    if not isinstance(request, dict): 
        print("request is not a dict object")
        return False 
    ## be jsonrpc 2.0 object 
    # if "jsonrpc" not in request or request["jsonrpc"] != "2.0": # be jsonrpc 2.0 object 
    #     return false
    ## method exists 
    if not ("method" in request and isinstance(request["method"], basestring)): 
        return False 
    ## id is integer, string, or None if it exists 
    if "id" in request and not (isinstance(request["id"], int) or isinstance(request["id"], basestring) or request["id"] is None): 
        print("Invalid id")
        return False
    ## params is dict, list, or None if it exists 
    # if "params" in request and not (isinstance(request["params"], dict) or isinstance(request["params"], list) or request["params"] is None): 
    #     print("Invalid params")
    #     return False 
    return True  
