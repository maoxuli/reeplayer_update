#ifndef __NVGST_SOURCE_BIN_H__
#define __NVGST_SOURCE_BIN_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <nvgstpipeline/nvgst_common.h>

typedef struct
{
  gchar *sensors; 
  gint master_sensor; 
  gint sensor_mode; 
  gint fps_n;
  gint fps_d;
  gint width;
  gint height;
  gchar *format; 
  guint flip_method; 
  guint sync_threshold;
} NvGstSourceConfig;

typedef struct
{
  GstElement *bin;
  GstElement *src_elem;
  GstElement *caps_filter;
} NvGstSourceBin;

gboolean parse_source_config (NvGstSourceConfig * config, GKeyFile * key_file, gchar * group);

gboolean create_source_bin (NvGstSourceConfig * config, NvGstSourceBin * bin); 

// dynamic settings for sensor 

// wbmode
// White balance affects the color temperature of the photo
// flags: readable, writable
// Enum "GstNvArgusCamWBMode" Default: 1, "auto"
//     (0): off              - GST_NVCAM_WB_MODE_OFF
//     (1): auto             - GST_NVCAM_WB_MODE_AUTO
//     (2): incandescent     - GST_NVCAM_WB_MODE_INCANDESCENT
//     (3): fluorescent      - GST_NVCAM_WB_MODE_FLUORESCENT
//     (4): warm-fluorescent - GST_NVCAM_WB_MODE_WARM_FLUORESCENT
//     (5): daylight         - GST_NVCAM_WB_MODE_DAYLIGHT
//     (6): cloudy-daylight  - GST_NVCAM_WB_MODE_CLOUDY_DAYLIGHT
//     (7): twilight         - GST_NVCAM_WB_MODE_TWILIGHT
//     (8): shade            - GST_NVCAM_WB_MODE_SHADE
//     (9): manual           - GST_NVCAM_WB_MODE_MANUAL

int set_source_white_balance (GstElement *src_ele, int value);

// saturation
// Property to adjust saturation value
// flags: readable, writable
// Float. Range: 0 - 2 
// Default: 1

float set_source_saturation (GstElement *src_ele, float value);

// exposuretimerange
// Property to adjust exposure time range in nanoseconds
// Use string with values of Exposure Time Range (low, high)
// in that order, to set the property.
// eg: exposuretimerange="34000 358733000"
// flags: readable, writable
// String. Default: null

gchar* set_source_exposure_time_range (GstElement *src_ele, gchar *value);

// gainrange 
// Property to adjust gain range
// Use string with values of Gain Time Range (low, high)
// in that order, to set the property.
// eg: gainrange="1 16"
// flags: readable, writable
// String. Default: null

gchar* set_source_gain_range (GstElement *src_ele, gchar *value);

// ispdigitalgainrange
// Property to adjust digital gain range
// Use string with values of ISP Digital Gain Range (low, high)
// in that order, to set the property.
// eg: ispdigitalgainrange="1 8"
// flags: readable, writable
// String. Default: null

gchar* set_source_digital_gain_range (GstElement *src_ele, gchar *value);

// tnr-strength
// property to adjust temporal noise reduction strength
// flags: readable, writable
// Float. Range: -1 - 1 
// Default: -1 

float set_source_tnr_strength (GstElement *src_ele, float value);

// tnr-mode
// property to select temporal noise reduction mode
// flags: readable, writable
// Enum "GstNvArgusCamTNRMode" Default: 1, "NoiseReduction_Fast"
//     (0): NoiseReduction_Off - GST_NVCAM_NR_OFF
//     (1): NoiseReduction_Fast - GST_NVCAM_NR_FAST
//     (2): NoiseReduction_HighQuality - GST_NVCAM_NR_HIGHQUALITY

int set_source_tnr_mode (GstElement *src_ele,  int value);

// ee-mode
// property to select edge enhnacement mode
// flags: readable, writable
// Enum "GstNvArgusCamEEMode" Default: 1, "EdgeEnhancement_Fast"
//     (0): EdgeEnhancement_Off - GST_NVCAM_EE_OFF
//     (1): EdgeEnhancement_Fast - GST_NVCAM_EE_FAST
//     (2): EdgeEnhancement_HighQuality - GST_NVCAM_EE_HIGHQUALITY

int set_source_edge_enhancement_mode (GstElement *src_ele, int value);

// ee-strength
// property to adjust edge enhancement strength
// flags: readable, writable
// Float. Range: -1 - 1 
// Default: -1 

float set_source_edge_enhancement_strength (GstElement *src_ele, float value);

// aeantibanding
// property to set the auto exposure antibanding mode
// flags: readable, writable
// Enum "GstNvArgusCamAeAntiBandingMode" Default: 1, "AeAntibandingMode_Auto"
//     (0): AeAntibandingMode_Off - GST_NVCAM_AEANTIBANDING_OFF
//     (1): AeAntibandingMode_Auto - GST_NVCAM_AEANTIBANDING_AUTO
//     (2): AeAntibandingMode_50HZ - GST_NVCAM_AEANTIBANDING_50HZ
//     (3): AeAntibandingMode_60HZ - GST_NVCAM_AEANTIBANDING_60HZ

int set_source_aeantibanding_mode (GstElement *src_ele, int value);

// exposurecompensation
// property to adjust exposure compensation
// flags: readable, writable
// Float. Range: -2 - 2 
// Default: 0 

float set_source_exposure_compensation (GstElement *src_ele, float value);

// aelock
// set or unset the auto exposure lock
// flags: readable, writable
// Boolean. Default: false

gboolean set_source_ae_lock(GstElement *src_ele, gboolean value);

// awblock
// set or unset the auto white balance lock
// flags: readable, writable
// Boolean. Default: false

gboolean set_source_awb_lock(GstElement *src_ele, gboolean value);


#ifdef __cplusplus
}
#endif

#endif
