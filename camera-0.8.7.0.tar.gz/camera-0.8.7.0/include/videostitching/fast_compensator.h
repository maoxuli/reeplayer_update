#pragma once

#if defined(NO)
#  warning Detected Apple 'NO' macro definition, it can cause build conflicts. Please, include this header before any Apple headers.
#endif

#include "opencv2/core.hpp"
#include <opencv2/stitching/detail/exposure_compensate.hpp>
#include <opencv2/core/cuda.hpp>
#include <vector>
#include <mutex>

using namespace cv; 

namespace videostitching {

class ExposureCompensator
{
public:
    ExposureCompensator(): updateGain(true) {}
    virtual ~ExposureCompensator() {}

    enum { NO, GAIN, GAIN_BLOCKS, CHANNELS, CHANNELS_BLOCKS };
    static Ptr<ExposureCompensator> createDefault(int type);

    void feed(const std::vector<Point> &corners, const std::vector<UMat> &images, const std::vector<UMat> &masks);
    virtual void feed(const std::vector<Point> &corners, const std::vector<UMat> &images,
                      const std::vector<std::pair<UMat, uchar> > &masks) = 0;

    virtual void apply(int index, Point corner, InputOutputArray image, InputArray mask) = 0;
    virtual void getMatGains(CV_OUT std::vector<Mat>& ) {CV_Error(Error::StsInternal, "");};
    virtual void setMatGains(std::vector<Mat>& ) { CV_Error(Error::StsInternal, ""); };
    void setUpdateGain(bool b) { updateGain = b; };
    bool getUpdateGain() { return updateGain; };

    virtual void gain_maps(std::vector<cv::UMat>& maps) = 0; 

protected :
    bool updateGain;
};

class NoExposureCompensator : public ExposureCompensator
{
public:
    void feed(const std::vector<Point> &/*corners*/, const std::vector<UMat> &/*images*/,
              const std::vector<std::pair<UMat,uchar> > &/*masks*/) {}
    void apply(int /*index*/, Point /*corner*/, InputOutputArray /*image*/, InputArray /*mask*/) {}
    void getMatGains(CV_OUT std::vector<Mat>& umv) { umv.clear(); };
    void setMatGains(std::vector<Mat>& umv) { umv.clear(); };

    void gain_maps(std::vector<cv::UMat>& maps) { maps.clear(); } 
};

class GainCompensator : public ExposureCompensator
{
public:
    // This Constructor only exists to make source level compatibility detector happy
    GainCompensator() : GainCompensator(1) {}
    GainCompensator(int nr_feeds) : nr_feeds_(nr_feeds), similarity_threshold_(1) {}
    void feed(const std::vector<Point> &corners, const std::vector<UMat> &images,
              const std::vector<std::pair<UMat,uchar> > &masks);
    void singleFeed(const std::vector<Point> &corners, const std::vector<UMat> &images,
                    const std::vector<std::pair<UMat,uchar> > &masks);
    void apply(int index, Point corner, InputOutputArray image, InputArray mask);
    void getMatGains(CV_OUT std::vector<Mat>& umv);
    void setMatGains(std::vector<Mat>& umv);
    void setNrFeeds(int nr_feeds) { nr_feeds_ = nr_feeds; }
    int getNrFeeds() { return nr_feeds_; }
    void setSimilarityThreshold(double similarity_threshold) { similarity_threshold_ = similarity_threshold; }
    double getSimilarityThreshold() const { return similarity_threshold_; }
    void prepareSimilarityMask(const std::vector<Point> &corners, const std::vector<UMat> &images);
    std::vector<double> gains() const;

    void gain_maps(std::vector<cv::UMat>& maps) { maps.clear(); }; 

private:
    UMat buildSimilarityMask(InputArray src_array1, InputArray src_array2);

    Mat_<double> gains_;
    int nr_feeds_;
    double similarity_threshold_;
    std::vector<UMat> similarities_;
};

class ChannelsCompensator : public ExposureCompensator
{
public:
    ChannelsCompensator(int nr_feeds=1) : nr_feeds_(nr_feeds), similarity_threshold_(1) {}
    void feed(const std::vector<Point> &corners, const std::vector<UMat> &images,
              const std::vector<std::pair<UMat,uchar> > &masks);
    void apply(int index, Point corner, InputOutputArray image, InputArray mask);
    void getMatGains(CV_OUT std::vector<Mat>& umv);
    void setMatGains(std::vector<Mat>& umv);
    void setNrFeeds(int nr_feeds) { nr_feeds_ = nr_feeds; }
    int getNrFeeds() { return nr_feeds_; }
    void setSimilarityThreshold(double similarity_threshold) { similarity_threshold_ = similarity_threshold; }
    double getSimilarityThreshold() const { return similarity_threshold_; }
    std::vector<Scalar> gains() const { return gains_; }

    void gain_maps(std::vector<cv::UMat>& maps) { maps.clear(); }

private:
    std::vector<Scalar> gains_;
    int nr_feeds_;
    double similarity_threshold_;
};

class BlocksCompensator : public ExposureCompensator
{
public:
    BlocksCompensator(int bl_width=32, int bl_height=32, int nr_feeds=1)
            : bl_width_(bl_width), bl_height_(bl_height), nr_feeds_(nr_feeds), nr_gain_filtering_iterations_(2),
              similarity_threshold_(1) {}
    void apply(int index, Point corner, InputOutputArray image, InputArray mask);
    void getMatGains(CV_OUT std::vector<Mat>& umv);
    void setMatGains(std::vector<Mat>& umv);
    void setNrFeeds(int nr_feeds) { nr_feeds_ = nr_feeds; }
    int getNrFeeds() { return nr_feeds_; }
    void setSimilarityThreshold(double similarity_threshold) { similarity_threshold_ = similarity_threshold; }
    double getSimilarityThreshold() const { return similarity_threshold_; }
    void setBlockSize(int width, int height) { bl_width_ = width; bl_height_ = height; }
    void setBlockSize(Size size) { setBlockSize(size.width, size.height); }
    Size getBlockSize() const { return Size(bl_width_, bl_height_); }
    void setNrGainsFilteringIterations(int nr_iterations) { nr_gain_filtering_iterations_ = nr_iterations; }
    int getNrGainsFilteringIterations() const { return nr_gain_filtering_iterations_; }

    void gain_maps(std::vector<cv::UMat>& maps);

protected:
    template<class Compensator>
    void feed(const std::vector<Point> &corners, const std::vector<UMat> &images,
              const std::vector<std::pair<UMat,uchar> > &masks);

private:
    UMat getGainMap(const GainCompensator& compensator, int bl_idx, Size bl_per_img);
    UMat getGainMap(const ChannelsCompensator& compensator, int bl_idx, Size bl_per_img);

    int bl_width_, bl_height_;
    std::vector<UMat> gain_maps_;
    int nr_feeds_;
    int nr_gain_filtering_iterations_;
    double similarity_threshold_;
};

class BlocksGainCompensator : public BlocksCompensator
{
public:
    // This Constructor only exists to make source level compatibility detector happy
    CV_WRAP BlocksGainCompensator(int bl_width = 32, int bl_height = 32)
            : BlocksGainCompensator(bl_width, bl_height, 1) {}
    CV_WRAP BlocksGainCompensator(int bl_width, int bl_height, int nr_feeds)
            : BlocksCompensator(bl_width, bl_height, nr_feeds) {}

    void feed(const std::vector<Point> &corners, const std::vector<UMat> &images,
              const std::vector<std::pair<UMat,uchar> > &masks);

    // This function only exists to make source level compatibility detector happy
    void apply(int index, Point corner, InputOutputArray image, InputArray mask) {
        BlocksCompensator::apply(index, corner, image, mask); }
    // This function only exists to make source level compatibility detector happy
    void getMatGains(CV_OUT std::vector<Mat>& umv) { BlocksCompensator::getMatGains(umv); }
    // This function only exists to make source level compatibility detector happy
    void setMatGains(std::vector<Mat>& umv) { BlocksCompensator::setMatGains(umv); }
};

class BlocksChannelsCompensator : public BlocksCompensator
{
public:
    CV_WRAP BlocksChannelsCompensator(int bl_width=32, int bl_height=32, int nr_feeds=1)
            : BlocksCompensator(bl_width, bl_height, nr_feeds) {}

    void feed(const std::vector<Point> &corners, const std::vector<UMat> &images,
              const std::vector<std::pair<UMat,uchar> > &masks);
};

}  // namespace videostitching 