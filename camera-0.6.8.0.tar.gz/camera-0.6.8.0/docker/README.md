# Docker images for camera system 

1. Build docker images for OpenCV 

Docker images for OpenCV versions based on Ubuntu or L4T. See READMD.md in opencv folder. 

2. Build docker images for ROS 

Docker images for ROS melodic based on Ubuntu or L4T with or without OpenCV. See README.md in ros-melodic folder. 

3. Build docker images for camera 

Docker images for camera system based on Ubuntu or L4T with or without ROS and/or OpenCV. See REAMD.md in camera folder. 


# Run docker container

    docker_start.sh -h 

    docker_start.sh [-i <image>] [-n <name>]

    docker_into.sh [-d] [-i <image>] [-n <name>]
    docker_into.sh [-n <name>]
    docker_stop.sh [-n <name>]
