#!/usr/bin/env python3

import rospy
from std_msgs.msg import String
from camera.srv import JsonService, JsonServiceResponse
import json
from random import randint
from glob import glob
import os
from pathlib import Path

footage = {
    "3a795a08-e4f1-4211-b5b9-cfac3f1704b7": glob(
        "/home/reeplayer_dev/workspace/footage_root/3a795a08-e4f1-4211-b5b9-cfac3f1704b7/*"
    ),
    "8e2c83c1-9dd1-45eb-b68e-b49afc747dfc": glob(
        "/home/reeplayer_dev/workspace/footage_root/8e2c83c1-9dd1-45eb-b68e-b49afc747dfc/*"
    ),
}

token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIwZTdhNjEwMy1iNTEyLTQ1N2MtOGUxZC0zZTdiYjhjMzQ0ODkiLCJjaWQiOiJiYWIwODc5Yy1mZDNmLTQzY2QtODU2Ny1jNDcxZjIwODA0NmIiLCJhdWQiOiJjYyIsImlhdCI6MTY0NjE2NDg2ODY4OCwiZXhwIjoxOTYxNTI0ODY4Njg4fQ.gRNO6QHQ3cfYBYoPESzIsQMmy3o7s94ul793szIvHl8"


def filename(path):
    return os.path.basename(path)

def file_extension(path):
    return Path(path).suffix

def filename_no_extension(path):
    p = Path(os.path.basename(path))
    return str(p.with_suffix(""))

def footage_id(path):
    return os.path.basename(os.path.split(path)[0])


def send_json_rpc(service, method, params):
    request = {
        "jsonrpc": 2.0,
        "id": randint(0, 100),
        "method": method,
        "params": params,
    }
    return json.loads(service(json.dumps(request)).data)


def upload_status_callback(msg):
    rospy.loginfo(msg.data)


def test(i, backend_rpc, uploading_rpc):
    if i == 0:
        for k, v in footage.items():
            ret = send_json_rpc(
                backend_rpc, "footage_upload", {"token": token, "footage_id": k}
            )
            assert ret
            for file in v:
                if filename(file) == "corners.json":
                    ret = send_json_rpc(
                        backend_rpc,
                        "footage_meta_upload",
                        {"token": token, "footage_id": k},
                    )["result"]
                    footage_id = ret["footage_id"]
                    file_address = ret["corners_file_address"]
                    ret = send_json_rpc(
                        uploading_rpc,
                        "start_upload",
                        {
                            "footage_id": footage_id,
                            "url": file_address,
                            "file_path": file,
                        },
                    )

                else:
                    ret = send_json_rpc(
                        backend_rpc,
                        "footage_part_upload",
                        {"token": token, "footage_id": k, "part_id": filename_no_extension(file)},
                    )["result"]
                    footage_id = ret["footage_id"]
                    file_address = ret["file_address"]
                    ret = send_json_rpc(
                        uploading_rpc,
                        "start_upload",
                        {
                            "footage_id": footage_id,
                            "url": file_address,
                            "file_path": file,
                        },
                    )

    else:
        pass


if __name__ == "__main__":
    rospy.init_node("file_uploader_test", log_level=rospy.DEBUG)
    rospy.wait_for_service("uploader/rpc")
    rospy.wait_for_service("backend/rpc")
    uploading_rpc = rospy.ServiceProxy("uploader/rpc", JsonService)
    backend_rpc = rospy.ServiceProxy("backend/rpc", JsonService)
    rospy.Subscriber("upload_status", String, upload_status_callback)
    r = rospy.Rate(10)  # 10hz
    i = 0
    while not rospy.is_shutdown():
        test(i, backend_rpc, uploading_rpc)
        i += 1
        r.sleep()

