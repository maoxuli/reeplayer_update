#ifndef JSONRPC_EXCEPTION_H_
#define JSONRPC_EXCEPTION_H_

#include "errors.h"
#include <string>
#include <exception>
#include <nlohmann/json.hpp>
using json = nlohmann::json;

namespace jsonrpc {

class Exception : public std::exception 
{
public:
    Exception(int code);
    Exception(int code, const std::string &message);
    Exception(int code, const std::string &message, const json &data);
    Exception(const std::string &message);

    virtual ~Exception() throw();

    int GetCode() const;
    const std::string& GetMessage() const;
    const json& GetData() const;

    virtual const char* what() const throw();

private:
    int code;
    std::string message;
    std::string whatString;
    json data;
    void setWhatMessage();
};

} // namespace jsonrpc 

#endif
