#ifndef JSONRPC_H_
#define JSONRPC_H_

#include "errors.h"
#include "exception.h"

#include <string>
#include <nlohmann/json.hpp>
using json = nlohmann::json;

#define JSONRPC_VERSION2 "2.0"
#define JSONRPC_KEY_VERSION "jsonrpc"
#define JSONRPC_KEY_METHOD "method"
#define JSONRPC_KEY_PARAMS "params"
#define JSONRPC_KEY_ID "id"
#define JSONRPC_KEY_ERROR "error"
#define JSONRPC_KEY_RESULT "result"

namespace jsonrpc {

bool ValidateRequestFields(const json &request);
void WrapError(const json &request, int code, const std::string &message, json &response); 
void WrapException(const json &request, const Exception &exception, json &response); 
void WrapResult(const json& request, json& result, json& response);
bool WrapRequest(int id, const std::string& method, const json& params, json& request);

} // namespace jsonrpc 

#endif 
