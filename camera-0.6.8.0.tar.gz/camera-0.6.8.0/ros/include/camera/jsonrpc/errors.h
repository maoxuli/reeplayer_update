#ifndef JSONRPC_ERRORS_H_
#define JSONRPC_ERRORS_H_

#include <map>
#include <string>

namespace jsonrpc {

// Official JSON-RPC 2.0 errors
const int JSON_PARSE_ERROR = -32700;
const int RPC_INVALID_REQUEST = -32600;
const int RPC_METHOD_NOT_FOUND = -32601;
const int RPC_INVALID_PARAMS = -32602;
const int RPC_INTERNAL_ERROR = -32603;
const int RPC_MISMATCHING_STATE = -32604; 
const int RPC_SERVER_ERROR = -32000;

// Get error message for error code 
std::string GetErrorMessage(int code); 

} // namespace jsonrpc 

#endif 
