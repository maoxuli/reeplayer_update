#ifndef __NVGST_REC_PIPELINE_H
#define __NVGST_REC_PIPELINE_H

#ifdef __cplusplus
extern "C"
{
#endif

#include <nvgstpipeline/nvgst_common.h>
#include <nvgstpipeline/nvgst_source_bin.h>
#include <nvgstpipeline/nvgst_sink_bin.h>
#include <nvgstpipeline/nvgst_stitcher_bin.h>

typedef struct
{
    guint num_recorders;
    guint num_streams;
    NvGstSourceConfig source_config;
    NvGstStitcherConfig stitcher_config;
    NvGstSinkConfig multi_rec_config[MAX_SINK_BINS];
    NvGstSinkConfig multi_stream_config[MAX_SINK_BINS];
} NvGstConfig;

typedef struct 
{
    GMutex app_lock;
    GCond app_cond;
    gboolean initialized; 

    NvGstConfig config;
    guint bus_id;
    GstElement *pipeline;
    NvGstSourceBin source_bin; 
    NvGstStitcherBin stitcher_bin; 
    GstElement *stitcher_tee;
    NvGstMultiSinkBin multi_rec_bin; 
    NvGstMultiSinkBin multi_stream_bin; 
} AppCtx;

gboolean create_pipeline(AppCtx *appCtx); 
void destroy_pipeline(AppCtx *appCtx); 
gboolean start_pipeline(AppCtx * appCtx); 
void stop_pipeline(AppCtx * appCtx); 

// sink commands and status 
gboolean set_recording_file(AppCtx * appCtx, gchar * filename, int idx); 
gchar * get_recording_file(AppCtx * appCtx, int idx); 
gboolean start_recording(AppCtx * appCtx, int idx); 
gboolean stop_recording(AppCtx * appCtx, int idx); 
gboolean check_recording_status(AppCtx * appCtx, int idx); 

gboolean start_streaming(AppCtx * appCtx, int idx); 
gboolean stop_streaming(AppCtx * appCtx, int idx); 
gboolean check_streaming_status(AppCtx * appCtx, int idx); 

#ifdef __cplusplus
}
#endif

#endif 
