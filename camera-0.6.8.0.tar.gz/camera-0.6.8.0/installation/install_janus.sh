#!/usr/bin/env bash 
set -e 

sudo apt-get update && sudo apt install -y \
    libjansson-dev \
    libconfig-dev \
    openssl \
    libssl-dev \
    libglib2.0-dev \
    libsrtp2-dev \
    libmicrohttpd-dev \
    libcurl4-openssl-dev \
    gengetopt \
    autogen \
    autoconf \
    automake 
    
WHEREAMI=$PWD 

## 0.1.16 is the last version using the make tool by default
## following version start to use meson
wget https://libnice.freedesktop.org/releases/libnice-0.1.16.tar.gz
tar -xzvf libnice-0.1.16.tar.gz 
cd libnice-0.1.16
./configure && make && sudo make install

cd $WHEREAMI 

## libsrtp from source code
wget https://github.com/cisco/libsrtp/archive/v2.2.0.tar.gz
tar -xzf v2.2.0.tar.gz 
cd libsrtp-2.2.0 
./configure --enable-openssl
make shared_library 
sudo make install 

cd $WHEREAMI

## janus from source code 
git clone https://github.com/meetecho/janus-gateway.git
cd janus-gateway 
./autogen.sh
./configure --prefix=/opt/janus
make
sudo make install

set +e 
