#!/usr/bin/env python

import os 
import threading 
import json

## A footage correponding to a folder in the file system, 
## Except for the meta files and the video files, the application 
## may define "status" for the footage, corresponding to the operations on 
## the footage, for example, the "recording", "uploading", "playing" status. 

## general footage 
class Footage(object):
    def __init__(self, path, settings):  
        self.path = path 
        self.settings = settings 
        ## footage info  
        self.info = None
        self.info_file = self.settings["footage_info"] if "footage_info" in self.settings else ".footage" 
        self.load_info()
        self.id = self.info["id"]
        print("Footage id: {}".format(self.id))
        ## footage status
        self.status_files = {}
        self.statuses = {} 
        if "footage_status" in self.settings: 
            for status in self.settings["footage_status"]: 
                try: 
                    self.status_files[status] = self.settings["footage_status"][status] 
                    self.load_status(status)
                except Exception as e: 
                    pass 

    def load_info(self): 
        try: 
            print("Loading footage file: {}".format(self.info_file))
            with open(os.path.join(self.path, self.info_file)) as f: 
                self.info = json.load(f)
        except Exception as e: 
            print("Failed loading footage file {}: {}".format(self.info_file, str(e)))
            raise e 

    def save_info(self):
        try: 
            print("Saving footage file: {}".format(self.info_file))
            with open(os.path.join(self.path, self.info_file), "w+") as f: 
                json.dump(self.info, f, indent=4)
        except Exception as e: 
            print("Failed saving footage file {}: {}".format(self.info_file, str(e)))
            raise e 

    def load_status(self, status): 
        try:
            status_file = self.status_files[status]
            print("Loading status file: {}".format(status_file))
            with open(os.path.join(self.path, status_file)) as f: 
                self.statuses[status] = json.load(f)
        except Exception as e: 
            print("Failed loading status file {}: {}".format(status_file, str(e)))
            raise e 

    def save_status(self, status): 
        try: 
            status_file = self.status_files[status]
            # print("Saving status file: {}".format(status_file))
            with open(os.path.join(self.path, status_file), "w+") as f: 
                json.dump(self.statuses[status], f, indent=4)
        except Exception as e: 
            print("Failed saving status file {}: {}".format(status_file, str(e)))
            raise e 


## general footage management 
class FootageManager(object): 
    def __init__(self, settings): 
        self.settings = settings 
        self.footage_instance_creator = self._create_footage

        self.footage_location = self.settings["footage_location"]
        self.footages = {}

    def _create_footage(self, path): 
        return Footage(path, self.settings) 

    def _sync_footage(self): 
        ## go through the footage 
        paths = []
        del_ids = []
        for footage_id in self.footages: 
            footage_path = self.footages[footage_id].path
            if os.path.exists(footage_path): 
                paths.append(footage_path)
            else:
                del_ids.append(footage_id)
        for footage_id in del_ids: 
            del self.footages[footage_id]
        ## add new footage
        for path in os.listdir(self.footage_location):
            if not path.startswith('.'): 
                footage_path = os.path.join(self.footage_location, path)
                if footage_path not in paths:
                    try: 
                        footage = self.footage_instance_creator(footage_path) 
                        self.footages[footage.id] = footage
                    except Exception as e: 
                        print("sync footage error: " + str(e))
                        pass 
        # print(self.footages)
