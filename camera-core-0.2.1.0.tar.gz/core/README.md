# Camera Core 

    ./build -ai  

The libraries and c/c++ header files are by default installed in /opt/reeplayer/camera/core. 

The installation package is camera-core-x.x.x.x.tar.gz. 
