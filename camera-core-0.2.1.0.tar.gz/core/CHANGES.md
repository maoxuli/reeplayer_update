## [0.2.1] - 2021-11-30
### changed 
- divide the videostitching and videostitcher lib 
- test programs for calibrator and stitcher 

## [0.2.0] - 2021-11-20
### changed
- Return JSON string from action signal of the cudastitcher plugin 
- Return JSON string from signal function of the algorithm interface

## [0.1.0] - 2021-11-14
- GStreamer plugin for video stitching
- The library for video stitching algorithms   
