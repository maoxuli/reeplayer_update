/*
 * Copyright (C) 2017 RidgeRun, LLC (http://www.ridgerun.com)
 * All Rights Reserved.
 *
 * The contents of this software are proprietary and confidential to RidgeRun,
 * LLC.  No part of this program may be photocopied, reproduced or translated
 * into another programming language without prior written consent of
 * RidgeRun, LLC.  The user is free to modify the source code after obtaining
 * a software license from RidgeRun.  All source code changes must be provided
 * back to RidgeRun without any encumbrance.
 */

#ifndef __GST_CUDA_ALGORITHM_MUX_HPP__
#define __GST_CUDA_ALGORITHM_MUX_HPP__

#include <gmodule.h>
#include <sys/cuda/gstcuda.h>
#include <vector>

namespace Gst
{
  namespace Cuda
  {
    namespace Algorithm
    {
      class Mux
      {
      public:

	/**
	 * open:
	 *
	 * Hook to allow the cuda algorithm initialization routine.
	 *
	 * Returns: true if initialization is successfull, false otherwise.
	 */
	virtual bool open () = 0;

	/**
	 * close:
	 *
	 * Hook to allow the cuda algorithm finalization routine.
	 *
	 * Returns: true if finalization is successfull, false otherwise.
	 */
	virtual bool close () = 0;

	/**
	 * process:
	 * @input_buffers: (in) (transfer none): The input buffers vector that
	 * contains the data to be processed on the GPU.
	 * @output_buffer: (out) (transfer none): The output buffer that contains
	 * the data processed by the GPU.
	 *
	 * Hook to allow the cuda algorithm process routine. This function
	 * is the responsible for the CUDA algorithm processing execution.
	 * This function will be called when in_place is not configured for
	 * processing the inconming buffers.
	 * In this function the inputs and output buffers are different,
	 * so the results of the CUDA algorithm processing only will be
	 * reflected on the output_buffer, that means that the
	 * input_buffers remains unmodified.
	 *
	 * Returns: true if process is successfull, false otherwise.
	 */
	virtual bool process (std::vector<GstCudaData> input_buffers, GstCudaData &output_buffer) = 0;

	/**
	 * process_ip:
	 *
	 * @input_buffers: (in) (transfer none): The input buffers vector that
	 * contains the data to be processed on the GPU.
	 * @output_buffer: (out) (transfer none): The output buffer that contains
	 * the data processed by the GPU. This buffer is a reference to the
	 * input vector first buffer.
	 *
	 * Hook to allow the cuda algorithm process_ip (proccess in place)
	 * routine. This function is the responsible for the CUDA algorithm
	 * processing execution.
	 * This function will be called when in_place is configured for
	 * processing the incoming buffers.
	 * In this function the first input buffer of the vector and the output buffer
	 * are the same. That means that the results of the CUDA algorithm processing
	 * will directly modify the input buffer, so its original incoming data will
	 * be modified accordinlgy to the CUDA algorithm.
	 *
	 * Returns: true if process_ip is successfull, false otherwise.
	 */
	virtual bool process_ip (std::vector<GstCudaData> input_buffers, GstCudaData &output_buffer) = 0;

	virtual ~Mux() {};
      };
    };
  };
};

extern "C" {

     /**
      * factory_make:
      *
      * Return a newly allocated algorithm to be used by cudamux
      *
      * Returns: A newly allocated algorithm to be used by cudamux
      */
  G_MODULE_EXPORT Gst::Cuda::Algorithm::Mux * factory_make (void);
}

#endif //__GST_CUDA_ALGORITHM_MUX_HPP_
