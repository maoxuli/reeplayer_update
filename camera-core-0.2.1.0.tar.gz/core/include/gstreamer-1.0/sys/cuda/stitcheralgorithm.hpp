/*
 * Copyright (C) 2021 Reeplayer
 * All Rights Reserved.
 */

#ifndef __GST_CUDA_ALGORITHM_STITCHER_HPP__
#define __GST_CUDA_ALGORITHM_STITCHER_HPP__

#include <gmodule.h>
#include <sys/cuda/gstcuda.h>
#include <vector>
#include <functional>

namespace Gst {
namespace Cuda {
namespace Algorithm {

class Stitcher
{
public:	
	virtual ~Stitcher() {};

	/**
	 * open:
	 * @width: (in): The input image with 
	 * @height: (in): The input image height
	 * @format: (in): The input image format in GstCudaFormat 
	 * 
	 * Hook to allow the cuda algorithm initialization routine.
	 *
	 * Returns: true if initialization is successfull, false otherwise.
	 */
	virtual bool open (const std::string& config, int width, int height, int format = GST_CUDA_RGBA) = 0;

	/**
	 * close:
	 *
	 * Hook to allow the cuda algorithm finalization routine.
	 *
	 * Returns: true if finalization is successfull, false otherwise.
	 */
	virtual bool close () = 0;

	/**
	 * output_size:
	 * @width: (out): The output image with 
	 * @height: (out): The output image height
	 * 
	 * Returns: true if is successfull, false otherwise.
	 */
	virtual bool output_size (int &width, int &height) = 0;

	/**
	 * set_output_size_callback:
	 *
	 * @cb: (in) callback function 
	 *
	 * Callback is triggered by output size change 
	 *
	 * Returns: void
	 */
	typedef std::function<void (int width, int height)> OutputSizeCallback;
	virtual void set_output_size_callback (const OutputSizeCallback& cb) = 0;

	/**
	 * process:
	 * @input_buffers: (in): The input buffers vector that
	 * contains the data to be processed on the GPU.
	 * @output_buffer: (out: The output buffer that contains
	 * the data processed by the GPU.
	 *
	 * Hook to allow the cuda algorithm process routine. This function
	 * is the responsible for the CUDA algorithm processing execution.
	 * This function could be called when sync mode is set to true.
	 * 
	 * In this function the inputs and output buffers are different,
	 * so the results of the CUDA algorithm processing only will be
	 * reflected on the output_buffer, that means that the
	 * input_buffers remains unmodified.
	 *
	 * Returns: true if process is successfull, false otherwise.
	 */
	virtual bool process (const std::vector<GstCudaFrame*>& input_buffers, GstCudaFrame *output_buffer) = 0;

	/**
	 * signal:
	 *
	 * @message: (in) message in JSON string,
	 *
	 * The message could be command or notification. 
	 *
	 * Returns: response message in JSON string 
	 */
	virtual std::string signal (const std::string& message) = 0;	

	/**
	 * status:
	 *
	 * @filter: (in) filter for status message, in JSON string  
	 *
	 * Synchronouse status query 
	 *
	 * Returns: status message in JOSN string  
	 */
	virtual std::string status (const std::string& filter = "") = 0;

	/**
	 * set_status_callback:
	 *
	 * @cb: (in) callback function 
	 *
	 * Callback is triggered by status change or update signal 
	 *
	 * Returns: void
	 */
	typedef std::function<void (const char *message)> StatusCallback;
	virtual void set_status_callback (const StatusCallback& cb) = 0;
};
    
} } } // Gst::Cuda::Algorithm

extern "C" {

	/**
	 * factory_make:
	 *
	 * Return a newly allocated algorithm to be used by cudaprocessor
	 *
	 * Returns: A newly allocated algorithm to be used by cudaprocessor
	 */
  	G_MODULE_EXPORT Gst::Cuda::Algorithm::Stitcher * factory_make (void);
}

#endif //__GST_CUDA_ALGORITHM_STITCHER_HPP__
