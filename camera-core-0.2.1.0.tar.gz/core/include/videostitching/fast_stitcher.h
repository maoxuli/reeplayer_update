#ifndef __FASE_STITCHER_H
#define __FAST_STITCHER_H

#include <opencv2/opencv.hpp>
#include <opencv2/stitching.hpp>
#include <opencv2/cudabgsegm.hpp>
#include "opencv2/cudafilters.hpp"

#include "cameras_calibration.h"
#include "fast_warpers.h"
#include "fast_blenders.h"

#include "fast_compensator.h"
#include "gpu_seam_finder.hpp"

namespace videostitching {

class FastStitcher
{
public: 
    struct Settings
    {
        int num_cameras = 2; 
        std::vector<std::string> camera_info_files; 
        std::vector<std::string> camera_params_files; 
        cv::Size image_size; 
        cv::Size undistort_size = cv::Size(0,0);
        std::string camera_model = "pinhole"; // pinhole | fisheye 
        std::string warp_type = "spherical"; // spherical | cylindrical
        std::string expos_comp_type = "gain_blocks"; // no, gain, gain_blocks
        int expos_comp_nr_feeds = 3;
        int expos_comp_nr_filtering = 3;
        int expos_comp_block_size = 32;
        int expos_comp_interval = 150; 
        double expos_comp_scale = 0.2; 
        std::string seam_type = "graphcut"; // no, graphcut
        int seam_find_iterations = 10;
        int seam_find_terminal_cost = (int)1e7;
        int seam_find_window_min = 9;
        int seam_find_window_max = 23;
        int seam_find_bad_penalty = (int)1e7;
        int seam_find_gap_width = 5;
        double seam_scale = 0.16; 
        std::string blend_type = "multiband"; // simple, feather, multiband 
        int num_bands = 5;  
        int blend_margin = 100; 
        Settings() {}
    };

    FastStitcher(const Settings& settings = Settings());

    cv::Size output_size() { return _output_size; } 

    void stitch(std::vector<cv::cuda::GpuMat>& in_images, 
                cv::cuda::GpuMat& out_image, unsigned long stamp); 

private:
    Settings _settings;
    int _num_cameras; 
    unsigned long _frame_count;  
    char filename[256];

    // undistort input images 
    void prepare_undistortion(); 
    std::vector<cv::Ptr<UndistortWarper> > _undistort_warpers; 
    std::vector<cv::cuda::GpuMat> _undistort_images; 
    std::vector<cv::Rect> _undistort_rects; 
    cv::Size _undistort_size; // same for two camera and smaller than input size 

    // project rectified images 
    void PrepareProjection(); 
    std::vector<cv::Ptr<ProjectWarper> > _proj_warpers;
    std::vector<cv::Rect> _warped_rects;
    std::vector<cv::Point> _warped_corners; 
    std::vector<cv::Size> _warped_sizes; 
    std::vector<cv::cuda::GpuMat> _warped_masks; 
    std::vector<cv::cuda::GpuMat> _warped_images; 
    // cv::cuda::GpuMat _out_image; 
    cv::Size _output_size; 

    // compensate exposure for warped images 
    void PrepareCompensation(); 
    cv::Ptr<ExposureCompensator> _compensator;
    std::vector<cv::Point> _expos_comp_corners; 
    std::vector<cv::UMat> _expos_comp_masks;
    std::vector<cv::UMat> _expos_comp_images;

    // blend overalap region of the warped images 
    void PrepareBlending(); 
    cv::Ptr<FastBlender> _blender; 
    std::vector<cv::Rect> _blend_rects; 
    std::vector<cv::Point> _blend_corners;
    std::vector<cv::Size> _blend_sizes; 
    std::vector<cv::cuda::GpuMat> _blend_masks; 
    cv::cuda::GpuMat _blended_image; 
    cv::Rect _blended_rect; 

    // find seam for blending 
    void PrepareSeamFinding(); 
    cv::Ptr<cv::detail::SeamFinder> _cv_seam_finder; 
    cv::Ptr<cv::detail::CudaGraphCutSeamFinder> _seam_finder;
    std::vector<cv::Point> _seam_find_corners;
    std::vector<cv::cuda::GpuMat> _seam_find_masks;
    std::vector<cv::cuda::GpuMat> _seam_find_images; 
    std::vector<cv::cuda::GpuMat> _seam_found_masks; 
    std::vector<cv::cuda::GpuMat> _seam_masks; 
    cv::Ptr<cv::cuda::Filter>  _dilater; 
    std::vector<cv::Ptr<cv::cuda::BackgroundSubtractorMOG2> > _fg_detectors; 
    std::vector<cv::cuda::GpuMat> _seam_fg_masks; 
    std::vector<cv::cuda::GpuMat> _dilated_masks; 
};

} // namespace videostitching

#endif 
