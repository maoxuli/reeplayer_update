#ifndef __FAST_ESTIMATORS_H
#define __FAST_ESTIMATORS_H

#include <opencv2/core.hpp>
#include <opencv2/core/cuda.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/cudafeatures2d.hpp>
#include <opencv2/xfeatures2d.hpp>
#include <opencv2/xfeatures2d/cuda.hpp>
#include <opencv2/calib3d.hpp>

#include <opencv2/stitching/detail/util.hpp>
#include <opencv2/stitching/detail/camera.hpp>
#include <opencv2/stitching/detail/autocalib.hpp>

#include <videostitching/fast_matchers.h>

using namespace cv; 
using namespace cv::cuda; 
using namespace cv::detail;

namespace videostitching {

/** @brief Rotation estimator base class.

It takes features of all images, pairwise matches between all images and estimates rotations of all
cameras.

@note The coordinate system origin is implementation-dependent, but you can always normalize the
rotations in respect to the first camera, for instance. :
 */
class Estimator
{
public:
    virtual ~Estimator() {}

    /** @brief Estimates camera parameters.

    @param features Features of images
    @param pairwise_matches Pairwise matches of images
    @param cameras Estimated camera parameters
    @return True in case of success, false otherwise
     */
    bool operator ()(const std::vector<ImageFeatures> &features,
        const std::vector<MatchesInfo> &pairwise_matches,
        std::vector<CameraParams> &cameras)
    {
        return estimate(features, pairwise_matches, cameras);
    }

protected:
    /** @brief This method must implement camera parameters estimation logic in order to make the wrapper
    detail::Estimator::operator()_ work.

    @param features Features of images
    @param pairwise_matches Pairwise matches of images
    @param cameras Estimated camera parameters
    @return True in case of success, false otherwise
     */
    virtual bool estimate(const std::vector<ImageFeatures> &features,
                          const std::vector<MatchesInfo> &pairwise_matches,
                          CV_OUT std::vector<CameraParams> &cameras) = 0;
};

/////////////////////////////////////////////////////////////////////////////////////////

/** @brief Homography based rotation estimator.
 */
class HomographyBasedEstimator : public Estimator
{
public:
    HomographyBasedEstimator(bool is_focals_estimated = false)
        : is_focals_estimated_(is_focals_estimated) {}

private:
    virtual bool estimate(const std::vector<ImageFeatures> &features,
                          const std::vector<MatchesInfo> &pairwise_matches,
                          std::vector<CameraParams> &cameras) CV_OVERRIDE;

    bool is_focals_estimated_;
};

/** @brief Affine transformation based estimator.

This estimator uses pairwise transformations estimated by matcher to estimate
final transformation for each camera.

@sa cv::detail::HomographyBasedEstimator
 */
class AffineBasedEstimator : public Estimator
{
public:
    AffineBasedEstimator(){}
private:
    virtual bool estimate(const std::vector<ImageFeatures> &features,
                          const std::vector<MatchesInfo> &pairwise_matches,
                          std::vector<CameraParams> &cameras) CV_OVERRIDE;
};

/////////////////////////////////////////////////////////////////////////////////////////

/** @brief Base class for all camera parameters refinement methods.
 */
class BundleAdjusterBase : public Estimator
{
public:
    const Mat refinementMask() const { return refinement_mask_.clone(); }
    void setRefinementMask(const Mat &mask)
    {
        CV_Assert(mask.type() == CV_8U && mask.size() == Size(3, 3));
        refinement_mask_ = mask.clone();
    }

    double confThresh() const { return conf_thresh_; }
    void setConfThresh(double conf_thresh) { conf_thresh_ = conf_thresh; }

    TermCriteria termCriteria() { return term_criteria_; }
    void setTermCriteria(const TermCriteria& term_criteria) { term_criteria_ = term_criteria; }

protected:
    /** @brief Construct a bundle adjuster base instance.

    @param num_params_per_cam Number of parameters per camera
    @param num_errs_per_measurement Number of error terms (components) per match
     */
    BundleAdjusterBase(int num_params_per_cam, int num_errs_per_measurement)
        : num_images_(0), total_num_matches_(0),
          num_params_per_cam_(num_params_per_cam),
          num_errs_per_measurement_(num_errs_per_measurement),
          features_(0), pairwise_matches_(0), conf_thresh_(0)
    {
        setRefinementMask(Mat::ones(3, 3, CV_8U));
        setConfThresh(1.);
        setTermCriteria(TermCriteria(TermCriteria::EPS + TermCriteria::COUNT, 1000, DBL_EPSILON));
    }

    // Runs bundle adjustment
    virtual bool estimate(const std::vector<ImageFeatures> &features,
                          const std::vector<MatchesInfo> &pairwise_matches,
                          std::vector<CameraParams> &cameras) CV_OVERRIDE;

    /** @brief Sets initial camera parameter to refine.

    @param cameras Camera parameters
     */
    virtual void setUpInitialCameraParams(const std::vector<CameraParams> &cameras) = 0;
    /** @brief Gets the refined camera parameters.

    @param cameras Refined camera parameters
     */
    virtual void obtainRefinedCameraParams(std::vector<CameraParams> &cameras) const = 0;
    /** @brief Calculates error vector.

    @param err Error column-vector of length total_num_matches \* num_errs_per_measurement
     */
    virtual void calcError(Mat &err) = 0;
    /** @brief Calculates the cost function jacobian.

    @param jac Jacobian matrix of dimensions
    (total_num_matches \* num_errs_per_measurement) x (num_images \* num_params_per_cam)
     */
    virtual void calcJacobian(Mat &jac) = 0;

    // 3x3 8U mask, where 0 means don't refine respective parameter, != 0 means refine
    Mat refinement_mask_;

    int num_images_;
    int total_num_matches_;

    int num_params_per_cam_;
    int num_errs_per_measurement_;

    const ImageFeatures *features_;
    const MatchesInfo *pairwise_matches_;

    // Threshold to filter out poorly matched image pairs
    double conf_thresh_;

    //Levenberg-Marquardt algorithm termination criteria
    TermCriteria term_criteria_;

    // Camera parameters matrix (CV_64F)
    Mat cam_params_;

    // Connected images pairs
    std::vector<std::pair<int,int> > edges_;
};


/** @brief Stub bundle adjuster that does nothing.
 */
class NoBundleAdjuster : public BundleAdjusterBase
{
public:
    NoBundleAdjuster() : BundleAdjusterBase(0, 0) {}

private:
    bool estimate(const std::vector<ImageFeatures> &, const std::vector<MatchesInfo> &,
                  std::vector<CameraParams> &) CV_OVERRIDE
    {
        return true;
    }
    void setUpInitialCameraParams(const std::vector<CameraParams> &) CV_OVERRIDE {}
    void obtainRefinedCameraParams(std::vector<CameraParams> &) const CV_OVERRIDE {}
    void calcError(Mat &) CV_OVERRIDE {}
    void calcJacobian(Mat &) CV_OVERRIDE {}
};


/** @brief Implementation of the camera parameters refinement algorithm which minimizes sum of the reprojection
error squares

It can estimate focal length, aspect ratio, principal point.
You can affect only on them via the refinement mask.
 */
class BundleAdjusterReproj : public BundleAdjusterBase
{
public:
    BundleAdjusterReproj() : BundleAdjusterBase(7, 2) {}

private:
    void setUpInitialCameraParams(const std::vector<CameraParams> &cameras) CV_OVERRIDE;
    void obtainRefinedCameraParams(std::vector<CameraParams> &cameras) const CV_OVERRIDE;
    void calcError(Mat &err) CV_OVERRIDE;
    void calcJacobian(Mat &jac) CV_OVERRIDE;

    Mat err1_, err2_;
};


/** @brief Implementation of the camera parameters refinement algorithm which minimizes sum of the distances
between the rays passing through the camera center and a feature. :

It can estimate focal length. It ignores the refinement mask for now.
 */
class BundleAdjusterRay : public BundleAdjusterBase
{
public:
    BundleAdjusterRay() : BundleAdjusterBase(4, 3) {}

private:
    void setUpInitialCameraParams(const std::vector<CameraParams> &cameras) CV_OVERRIDE;
    void obtainRefinedCameraParams(std::vector<CameraParams> &cameras) const CV_OVERRIDE;
    void calcError(Mat &err) CV_OVERRIDE;
    void calcJacobian(Mat &jac) CV_OVERRIDE;

    Mat err1_, err2_;
};


/** @brief Bundle adjuster that expects affine transformation
represented in homogeneous coordinates in R for each camera param. Implements
camera parameters refinement algorithm which minimizes sum of the reprojection
error squares

It estimates all transformation parameters. Refinement mask is ignored.

@sa AffineBasedEstimator AffineBestOf2NearestMatcher BundleAdjusterAffinePartial
 */
class BundleAdjusterAffine : public BundleAdjusterBase
{
public:
    BundleAdjusterAffine() : BundleAdjusterBase(6, 2) {}

private:
    void setUpInitialCameraParams(const std::vector<CameraParams> &cameras) CV_OVERRIDE;
    void obtainRefinedCameraParams(std::vector<CameraParams> &cameras) const CV_OVERRIDE;
    void calcError(Mat &err) CV_OVERRIDE;
    void calcJacobian(Mat &jac) CV_OVERRIDE;

    Mat err1_, err2_;
};


/** @brief Bundle adjuster that expects affine transformation with 4 DOF
represented in homogeneous coordinates in R for each camera param. Implements
camera parameters refinement algorithm which minimizes sum of the reprojection
error squares

It estimates all transformation parameters. Refinement mask is ignored.

@sa AffineBasedEstimator AffineBestOf2NearestMatcher BundleAdjusterAffine
 */
class BundleAdjusterAffinePartial : public BundleAdjusterBase
{
public:
    BundleAdjusterAffinePartial() : BundleAdjusterBase(4, 2) {}

private:
    void setUpInitialCameraParams(const std::vector<CameraParams> &cameras) CV_OVERRIDE;
    void obtainRefinedCameraParams(std::vector<CameraParams> &cameras) const CV_OVERRIDE;
    void calcError(Mat &err) CV_OVERRIDE;
    void calcJacobian(Mat &jac) CV_OVERRIDE;

    Mat err1_, err2_;
};

//////////////////////////////////////////////////////////////////////////////

enum WaveCorrectKind
{
    WAVE_CORRECT_HORIZ,
    WAVE_CORRECT_VERT
};

void waveCorrect(std::vector<Mat> &rmats, WaveCorrectKind kind);

//////////////////////////////////////////////////////////////////////////////
// Auxiliary functions

void pairMatches(const std::vector<ImageFeatures> &features, const MatchesInfo &matches, 
                 std::vector<MatchesInfo> &pairwise_matches); 

void findMaxSpanningTree(int num_images, const std::vector<MatchesInfo> &pairwise_matches,
                         Graph &span_tree, std::vector<int> &centers);

bool estimateFocal(const std::vector<ImageFeatures> &features,
                   const std::vector<MatchesInfo> &pairwise_matches,
                   std::vector<double> &focals);

} // namespace videostitching 

#endif 
