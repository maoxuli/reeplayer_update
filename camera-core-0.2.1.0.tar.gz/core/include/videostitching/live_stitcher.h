#ifndef __LIVE_STITCHER_H
#define __LIVE_STITCHER_H

#include <opencv2/opencv.hpp>
#include <opencv2/stitching.hpp>
#include <opencv2/cudabgsegm.hpp>
#include "opencv2/cudafilters.hpp"

#include <videostitching/image_processor.h>
#include <videostitching/fast_warpers.h>
#include <videostitching/fast_blenders.h>
#include <videostitching/fast_compensator.h>
#include <videostitching/gpu_seam_finder.hpp>

#include <thread>
#include <atomic>
#include <mutex>
#include <condition_variable>


namespace videostitching {

class LiveStitcher : public ImageProcessor
{
public: 
    LiveStitcher(const std::string& config, const cv::Size& image_size);
    ~LiveStitcher();

    bool prepare(const std::vector<cv::detail::CameraParams>& cameras); 

    void evaluate(bool set = true); 

    virtual cv::Size output_size() const; 

	virtual bool process(const std::vector<cv::cuda::GpuMat>& in_mats, cv::cuda::GpuMat& out_mat, 
                         cv::cuda::Stream& stream = cv::cuda::Stream::Null()); 

private:
    int _num_cameras; 
    cv::Size _input_size; 
    cv::Size _output_size;
    cv::Rect _output_roi;
    cv::cuda::GpuMat _output_image;   

    struct InternalSettings
    {
        std::string warp_type = "spherical"; // shperical | cylindrical | plane 
        std::string expos_comp_type = "no"; // no, gain, gain_blocks
        int expos_comp_nr_feeds = 3;
        int expos_comp_nr_filtering = 3;
        int expos_comp_block_size = 32;
        double expos_comp_scale = 0.2; 
        int expos_comp_interval = 30; 
        std::string seam_type = "no"; // no, graphcut
        int seam_find_iterations = 10;
        int seam_find_terminal_cost = (int)1e7;
        int seam_find_window_min = 9;
        int seam_find_window_max = 23;
        int seam_find_bad_penalty = (int)1e7;
        int seam_find_gap_width = 5;
        double seam_scale = 0.1; 
        int blend_margin = 10; 
        std::string blend_type = "no"; // no, feather, multiband 
        int num_bands = 5; 

        InternalSettings(const std::string& config); 
        std::string to_string() const; 
    };
    InternalSettings _settings;

    std::mutex _mutex; 
    bool _evaluating; 
    uint64_t _frame_count;

    // projection warping 
    void prepare_projection(const std::vector<cv::detail::CameraParams>& cameras);
    std::vector<cv::Ptr<ProjectWarper> > _warpers;
    std::vector<cv::Rect> _warped_rects;
    std::vector<cv::Point> _warped_corners; 
    std::vector<cv::Size> _warped_sizes; 
    std::vector<cv::cuda::GpuMat> _warped_masks; 
    std::vector<cv::cuda::GpuMat> _warped_images;
    std::vector<cv::Rect> _crop_rects; 
    std::vector<cv::Rect> _output_rects; 

    // compensate exposure for warped images 
    void prepare_compensation(); 
    cv::Ptr<ExposureCompensator> _compensator;
    std::vector<cv::Point> _expos_comp_corners; // after scale 
    std::vector<cv::UMat> _expos_comp_images;
    std::vector<cv::UMat> _expos_comp_masks; // after scale, so indicate scaled size n
    std::vector<cv::cuda::GpuMat> _expos_comp_maps; // same size of warped images

    // blend overalap region of the warped images 
    void prepare_blending(); 
    cv::Ptr<FastBlender> _blender; 
    std::vector<cv::Rect> _blend_rects; 
    std::vector<cv::Point> _blend_corners;
    std::vector<cv::Size> _blend_sizes; 
    std::vector<cv::cuda::GpuMat> _blend_masks; 
    cv::cuda::GpuMat _blended_image; 
    cv::Rect _blended_rect; 

   // find seam for blending 
    void prepare_seam_finding(); 
    cv::Ptr<cv::detail::CudaGraphCutSeamFinder> _seam_finder;
    std::vector<cv::Point> _seam_find_corners;
    std::vector<cv::cuda::GpuMat> _seam_find_masks;
    std::vector<cv::cuda::GpuMat> _seam_find_images; 
    std::vector<cv::cuda::GpuMat> _seam_found_masks; 
    std::vector<cv::cuda::GpuMat> _seam_masks; 
    cv::Ptr<cv::cuda::Filter>  _dilater; 
    std::vector<cv::cuda::GpuMat> _dilated_masks;
};

} // namespace videostitching

#endif 
