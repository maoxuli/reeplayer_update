#ifndef __LIVE_CALIBRATOR_H__
#define __LIVE_CALIBRATOR_H__

#include <string>
#include <vector>
#include <deque>
#include <memory>
#include <atomic>
#include <thread>
#include <mutex>
#include <condition_variable>

#include <opencv2/core.hpp>
#include <opencv2/core/cuda.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/cudafeatures2d.hpp>
#include <opencv2/xfeatures2d.hpp>
#include <opencv2/xfeatures2d/cuda.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/stitching/detail/camera.hpp>

#include <videostitching/image_processor.h>
#include <videostitching/fast_matchers.h>
#include <videostitching/fast_estimators.h>

namespace videostitching {

class LiveCalibrator : public ImageProcessor 
{
public: 
    LiveCalibrator(const std::string& config, const cv::Size& image_size);
    virtual ~LiveCalibrator(); 

    virtual cv::Size output_size() const { return _output_size; }

	virtual bool process(const std::vector<cv::cuda::GpuMat>& in_mats, cv::cuda::GpuMat& out_mat, 
                         cv::cuda::Stream& stream = cv::cuda::Stream::Null()); 

    void detect(bool auto_accept = false); 
    void procede(bool accept = false); 
    bool calibrate(std::vector<cv::detail::CameraParams>& cameras); 
    void reset(); 

private: 
    const int _num_cameras;
    cv::Size _input_size; 
    cv::Size _output_size; 
    std::vector<cv::Rect> _output_rects; 
    cv::cuda::GpuMat _output_image; 
    cv::cuda::GpuMat _output_overlay;  

    struct InternalSettings 
    {
        float detect_scale = -1; // down scale for input images (0,1) 
        int min_matches = 5; // min matches good for estimation 
        float hessian_threshold = 200; // for SURF
        float match_conf = 0.5f; // for SURF 
        float ransac_threshold = 3; // ransac reproj threshold [1,10]
        std::string ba_cost_func = "reproj";  // reproj | ray | no 
        float conf_thresh = 1.0f;
        std::string ba_refine_mask = "xxxxx";
        bool do_wave_correct = true;

        InternalSettings(const std::string& config); 
        std::string to_string() const; 
    }; 
    InternalSettings _settings; 

    // calibration state 
    std::mutex _mutex; 
    enum STATE { IDLE_STATE, DETECTING_STATE, WAITING_STATE, LAST_STATE }; 
    int _state;  
    bool _auto_accept;  

    void prepare(); 

    // features finding and matching 
    cv::Ptr<cv::cuda::SURF_CUDA> _finder; 
    cv::Ptr<FastMatcher> _matcher; 
    cv::Size _detect_size; // scaled down from undistort size 
    std::vector<cv::cuda::GpuMat> _detect_masks; 
    std::vector<cv::cuda::GpuMat> _detect_images; 
    std::vector<cv::cuda::GpuMat> _gray_images; 
    cv::cuda::GpuMat _visual_detection; 

    // transform estimator 
    std::shared_ptr<Estimator> _estimator;
    std::shared_ptr<BundleAdjusterBase> _adjuster; 

    bool surf_detection(); 
    std::vector<ImageFeatures> _features; 
    MatchesInfo _matches_info; 

    void apply_detection(bool visualize = true); 
    std::vector<ImageFeatures> _all_features; 
    MatchesInfo _all_matches_info; 
    std::set<std::pair<int,int> > _all_matches_set; 
    cv::Mat _visual_matches; // on detect size  

    bool estimate(std::vector<cv::detail::CameraParams>& cameras); 
    void reset_calib(); 
}; 

} // namespace videostitching 

#endif 
