#ifndef __EXTRINSIC_CALIBRATOR_H__
#define __EXTRINSIC_CALIBRATOR_H__

#include <string>
#include <vector>
#include <memory>
#include <mutex>
#include "opencv2/opencv.hpp"
#include "fast_estimators.h"
#include "fast_warpers.h"

namespace videostitching {

class ExtrinsicCalibrator
{
public: 
    ExtrinsicCalibrator(const std::string& config, const cv::Size& size);
    ~ExtrinsicCalibrator(); 

    // output size may be fixed size, which means the output images are in 
    // the exact size, or may be a max size, which mean the output images 
    // are in a variable size but always less than the given size.  
    // (0,0) means the output is in arbitrary size.  
    cv::Size output_size(); 

    // output size may be changed in run-time 
    typedef std::function<void (const cv::Size&)> OutputSizeCallback;
    void set_output_size_callback(const OutputSizeCallback& cb);

    // update the calib process by a new input, the output image is for display. 
    // return value may be varid for functions, but 0 means normal state. 
    // negative values for errors, and positive value for other special state. 
    // int update(cv::InputArray in_images, cv::OutputArray out_image); 
    int update(const std::vector<cv::cuda::GpuMat>& in_images, cv::cuda::GpuMat& out_image);

    // the control of the calib process is done by commands
    // the format of commands is specific to functions and implementations.  
    bool command(const std::string& command); 

    // query status 
    std::string status(const std::string& filter = ""); 

    // status callback 
    type std::function<bool (const char *message)> StatusCallback; 
    void set_status_callback(const StatusCallback& cb);

private: 
    int _num_cameras;
    cv::Size _image_size; 

    struct InternalSettings 
    {
        std::string config_path; 
        std::string camera_info_path; 
        std::string camera_params_path; 
        std::string camera_model = "pinhole"; // pinhole | fisheye 
        std::string warp_type = "spherical"; // shperical | cylindrical 
        bool do_undistort = false; 
        cv::Size undistort_size = cv::Size(0,0); 
        float detect_scale = -1; // down scale for input images (0,1) 
        int min_matches = 10; // min matches good for estimation 
        float hessian_threshold = 200; // for SURF
        float match_conf = 0.5f; // for SURF 
        float ransac_threshold = 3; // ransac reproj threshold [1,10]
        std::string ba_cost_func = "reproj";  // reproj | ray | no 
        float conf_thresh = 1.0f;
        std::string ba_refine_mask = "xxxxx";
        bool do_wave_correct = true;

        InternalSettings(const std::string& config); 
        std::string to_string() const; 
    }; 
    InternalSettings _settings; 

    // The calibrator works in different modes 
    // each mode has a different work flow and maybe different output size 
    enum MODE {CALIB_MODE, PREVIEW_MODE, EVALUATION_MODE, LAST_MODE}; 
    int _mode; 
    void set_mode(int mode); 

    enum RET_VALUE {RET_ERROR = -1, RET_OK = 0, RET_WAITING = 1};
    int calib_update(const std::vector<cv::cuda::GpuMat>& in_images, cv::cuda::GpuMat& out_image); 
    int preview_update(const std::vector<cv::cuda::GpuMat>& in_images, cv::cuda::GpuMat& out_image); 
    int evaluation_update(const std::vector<cv::cuda::GpuMat>& in_images, cv::cuda::GpuMat& out_image); 

    // For calib mode, the calibrator will wait after detection  
    bool _waiting; 
    StatusCallback _status_callback;  

    void reset_calib();
    bool save_calib(); 

    // lock
    std::mutex _calib_mutex; 

private: 
    cv::Size _output_size; // double the undistorted size  
    std::vector<cv::Rect> _output_rects; // half size of the output 
    OutputSizeCallback _output_size_callback; 

    // undistortion warping 
    void prepare_undistortion(); 
    std::vector<cv::Ptr<UndistortWarper> > _undistort_warpers; 
    std::vector<cv::cuda::GpuMat> _undistort_images; 
    std::vector<cv::Rect> _undistort_rects; 
    cv::Size _undistort_size; // same for two camera and smaller than input size 

    // features finding and matching 
    void prepare_detection(); 
    cv::Ptr<cv::cuda::SURF_CUDA> _finder; 
    cv::Ptr<FastMatcher> _matcher; 
    cv::Size _detect_size; // scaled down from undistort size 
    std::vector<cv::cuda::GpuMat> _detect_masks; 
    std::vector<cv::cuda::GpuMat> _detect_images; 
    std::vector<cv::cuda::GpuMat> _gray_images; 

    bool surf_detection(bool visualize); 
    std::vector<ImageFeatures> _features; 
    MatchesInfo _matches_info; 
    cv::Mat _visual_matches; // on detect size 
    cv::Mat _visual_detection; // on output size 

    void apply_detection(bool visualize); 
    std::vector<ImageFeatures> _all_features; 
    MatchesInfo _all_matches_info; 
    std::set<std::pair<int,int> > _all_matches_set; 
    cv::Mat _visual_all_matches; // on detect size  
    cv::cuda::GpuMat _visual_coverage; // on output size 

    // transform estimation  
    void prepare_estimation(); 
    std::shared_ptr<Estimator> _estimator;
    std::shared_ptr<BundleAdjusterBase> _adjuster; 

    bool estimate_transform(); 
    std::vector<cv::detail::CameraParams> _cameras; 

    // projection warping 
    void prepare_projection(const std::vector<cv::detail::CameraParams>& cameras);
    std::vector<cv::Ptr<ProjectWarper> > _project_warpers;
    std::vector<cv::Rect> _warped_rects;
    std::vector<cv::Point> _warped_corners; 
    std::vector<cv::Size> _warped_sizes; 
    std::vector<cv::cuda::GpuMat> _warped_masks; 
    std::vector<cv::cuda::GpuMat> _warped_images;
    cv::Size _stitched_size; 
    cv::cuda::GpuMat _stitched_image; 

    // blending 
    void prepare_blending(); 
    std::vector<cv::Rect> _blend_rects; 
    std::vector<cv::Point> _blend_corners;
    std::vector<cv::Size> _blend_sizes; 
    std::vector<cv::cuda::GpuMat> _blend_masks;
    std::vector<cv::cuda::GpuMat> _blend_alphas;  
    std::vector<cv::cuda::GpuMat> _blend_images; 
    cv::cuda::GpuMat _blended_image; 
    cv::Rect _blended_rect; 
    bool _blending; 
}; 

} // namespace videostitching 

#endif 
