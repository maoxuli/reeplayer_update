#!/bin/bash

## the script is used to update the camera system software.
## download or install given version x.x.x.x: 
## camera_update.sh download x.x.x.x 
## camera_update.sh install x.x.x.x 
## by default, download and install the latest version. 

## Reeplayer/camera/scripts
## INSTALL_DIR/CAMERA_DIR/SCRIPTS_DIR
SCRIPTS_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "SCRIPTS_DIR: ${SCRIPTS_DIR}" 

INSTALL_DIR="$( readlink -m "${SCRIPTS_DIR}/../.." )"
echo "INSTALL_DIR: ${INSTALL_DIR}"

CAMERA_DIR="${INSTALL_DIR}/camera"
echo "CAMERA_DIR: ${CAMERA_DIR}"

## check the current version 
CURRENT_VERSION="0.0.0.0"
CURRENT_VERSION_DIR="$( readlink -f "${CAMERA_DIR}" )"
echo "CURRENT_VERSION_DIR: ${CURRENT_VERSION_DIR}"
VERSION_DIR="$( basename "${CURRENT_VERSION_DIR}" )"
if [ "${VERSION_DIR}" != "camera" ] ; then 
  CURRENT_VERSION="${CURRENT_VERSION_DIR##*-}"
fi 
echo "CURRENT_VERSION: ${CURRENT_VERSION}"

## "1.1.1.1" is expanded to decimal number string "01010101"
## so each version element support two decimal digits in [0, 99]  
ver() {
    printf "%02d%02d%02d%02d" ${1//./ }
}

## check the latest package version 
LATEST_PACKAGE=""
LATEST_PACKAGE_VERSION="0.0.0.0"
shopt -s nullglob
for f in ${INSTALL_DIR}/camera-*.tar.gz ; do
  PACKAGE="$f"
  VERSION_DIR="$( basename "${PACKAGE}" .tar.gz)"
  VERSION="${VERSION_DIR##*-}"
  # echo "VERSION: ${VERSION}"
  if [ "$(ver "${VERSION}")" -gt "$(ver "${LATEST_PACKAGE_VERSION}")" ] ; then 
    LATEST_PACKAGE_VERSION=${VERSION}
    # echo "LATEST_PACKAGE_VERSION: ${LATEST_PACKAGE_VERSION}"
    LATEST_PACKAGE="${PACKAGE}"
  fi
done
shopt -u nullglob
echo "LATEST_PACKAGE: ${LATEST_PACKAGE}" 
echo "LATEST_PACKAGE_VERSION: ${LATEST_PACKAGE_VERSION}" 

## download from UPDATE_URL 
download () {
  echo "$(date +"%Y-%m-%d %T"): camera update download..."

  ## load setup
  echo "Loading setup: ${SCRIPTS_DIR}/camera_setup.sh"
  . "${SCRIPTS_DIR}/camera_setup.sh" 

  ## update URL 
  echo "UPDATE_URL: ${UPDATE_URL}" 
  if [ -z "${UPDATE_URL}" ] ; then 
    echo "UPDATE_URL is not set!"
    return 1 
  fi 

  ## check and download update version info 
  echo "curl ${UPDATE_URL}/version.sh -o ${INSTALL_DIR}/version.sh"
  curl "${UPDATE_URL}/version.sh" -o "${INSTALL_DIR}/version.sh"

  ## load update version info 
  if [ -f "${INSTALL_DIR}/version.sh" ] ; then 
    . "${INSTALL_DIR}/version.sh" 
    echo "VERSION: ${VERSION}" 
  fi 

  if [ ! -z "${VERSION}" ] ; then 
    if [ "$(ver "${VERSION}")" -gt "$(ver "${CURRENT_VERSION}")" ] ; then 
      if [ "$(ver "${VERSION}")" -gt "$(ver "${LATEST_PACKAGE_VERSION}")" ] ; then 
        VERSION_PACKAGE="camera-${VERSION}.tar.gz" 
        echo "VERSION_PACKAGE: ${VERSION_PACKAGE}" 
        curl "${UPDATE_URL}/${VERSION_PACKAGE}" -o "${INSTALL_DIR}/${VERSION_PACKAGE}"
      fi 
    fi 
  fi 

  echo "$(date +"%Y-%m-%d %T"): camera update download done!"
}

## install the downloaded package 
install () {
  echo "$(date +"%Y-%m-%d %T"): camera update install..."

  ## install the latest package version 
  if [ ! -z "${LATEST_PACKAGE_VERSION}" ] ; then 
    if [ "$(ver "${LATEST_PACKAGE_VERSION}")" -gt "$(ver "${CURRENT_VERSION}")" ] ; then 
      LATEST_VERSION_DIR="${INSTALL_DIR}/camera-${LATEST_PACKAGE_VERSION}"
      echo "LATEST_VERSION_DIR: ${LATEST_VERSION_DIR}"
      if [ ! -d "${LATEST_VERSION_DIR}" ] ; then 
        echo "tar -xzf "${LATEST_PACKAGE}" -C "${INSTALL_DIR}""
        tar -xzf "${LATEST_PACKAGE}" -C "${INSTALL_DIR}"
      fi 
      set -x
      ## re-link the camera dir to latest version folder  
      ln -snfr "${LATEST_VERSION_DIR}" "${CAMERA_DIR}"
      ## delete current version folder 
      rm -rf "${CURRENT_VERSION_DIR}"
      set +x 
    fi
  fi 

  echo "$(date +"%Y-%m-%d %T"): camera update install done!"
}

case "$1" in
  download)
    shift 
    download $@
    ;;
  install)
    shift
    install $@
    ;;
  *)
    echo "Usage: $0 {download|install}"
    ;;
esac 
        