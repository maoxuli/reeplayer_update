#ifndef __NVGST_STITCHER_H__
#define __NVGST_STITCHER_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <gst/gst.h>
#include <nvgstpipeline/nvgst_common.h>

typedef struct
{
  gboolean enable; 
  gint input_width; 
  gint input_height; 
  guint flip_method; 
  gint output_left;
  gint output_top;
  gint output_width;
  gint output_height;
  guint mode;
  gchar *settings; 
} NvGstStitcherConfig;

typedef struct
{
  GstElement *bin;
  GstElement *stitcher;
  GstElement *conv;
  GstElement *conv_filter;
} NvGstStitcherBin;

gboolean parse_stitcher_config (NvGstStitcherConfig * config, GKeyFile * key_file, gchar * group);

gboolean create_stitcher_bin (NvGstStitcherConfig * config, NvGstStitcherBin * bin);

#ifdef __cplusplus
}
#endif

#endif
