/*
 * Copyright (C) 2020 RidgeRun, LLC (http://www.ridgerun.com)
 * All Rights Reserved.
 *
 * The contents of this software are proprietary and confidential to RidgeRun,
 * LLC.  No part of this program may be photocopied, reproduced or translated
 * into another programming language without prior written consent of
 * RidgeRun, LLC.  The user is free to modify the source code after obtaining
 * a software license from RidgeRun.  All source code changes must be provided
 * back to RidgeRun without any encumbrance.
 */

#ifndef __RR_STITCHER_RGBA_H__
#define __RR_STITCHER_RGBA_H__

namespace rr {
namespace stitcher {

/**
* RGBA structure:
* @r: Red channel.
* @g: Green channel.
* @b: Blue channel.
* @a: Alpha channel.
*
* Image strcuture of four channels.
*/
template <typename T>
struct RGBA {
  T r;
  T g;
  T b;
  T a;
};

} // namespace stitcher
} // namespace rr

#endif //__RR_STITCHER_RGBA_H__
