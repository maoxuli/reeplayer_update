#!/bin/bash

REFRESH_RATE=0.1
MASTER_VIDEO_DEVICE=/dev/video1
SLAVE_VIDEO_DEVICES=(/dev/video0 /dev/video2)

while true
do
    exposure=$(v4l2-ctl -d $MASTER_VIDEO_DEVICE --get-ctrl=exposure | awk '{print $2}')
    gain=$(v4l2-ctl -d $MASTER_VIDEO_DEVICE --get-ctrl=gain | awk '{print $2}')

    for item in ${SLAVE_VIDEO_DEVICES[*]}
    do
        v4l2-ctl -d $item --set-ctrl=gain=$gain
        v4l2-ctl -d $item --set-ctrl=exposure=$exposure
    done
    sleep $REFRESH_RATE
done
