# Camera

The software system for camera device. 


## Operating system 

The software system id designed to run on Nvidia Jetson platform, so the target operating system is L4T (Linux for Tegra). For the convinience of development and testing, most of the code of the software is implemented to be compatible to the Ubuntu x86/64 system. 

## Build environment 

The code could be built on native system or built with the provided docker container. You need to install and setup the local system to have the same software environment as that in docker. In summary: 

    * GStreamer 
    * OpenCV with support for CUDA (built from source code)
    * ROS melodic for Ubuntu (x86/64 or arm64)


## Source code management 

We suppose the file system structure for the source code is as below: 

    ~/Reeplayer
    ~/Reeplayer/camera
    ~/Reeplayer/camera_ros 

We suppose the binary software is installed to below position: 

    /opt/reeplayer/camera 


## Build and install the software system 

Below script is used to build the software system and create installation package: 

    build.sh [options]

Options: 

    -a: clean and build all from scratch; 
    -i: create installation package; 


## Build and test the system 

The source code of the system is in "~/Reeplayer" if you follow above guide. 

The runtime software is installed in "/opt/reeplayer" by default. 

Some settings are based on the default locations, currently for development. 

To workaround some permission issues, I currently manually create the install directory for current user: 

    mkdir /opt/reeplayer 
    sudo chown -R $(id -u):$(id -g) /opt/reeplayer

1. Build and install common libraries 

    cd ~/Reeplayer/camera
    cd nvgstpipeline 
    make 
    make install 

2. Build and install ROS packages 

    cd ~/Reeplayer/camera_ros 
    catkin_make 
    catkin_make -DCMAKE_INSTALL_PREFIX=/opt/reeplayer/camera/ros install
    
3. Install other stuff 

    cd ~/Reeplayer/camera_ros/src/camera_ros
    cp -r config /opt/reeplayer/camera/
    cp -r scripts /opt/reeplayer/camera/

4. Launch camera software system 

    cd /opt/reeplayer/camera/scripts 
    ./system.sh start 

5. Use the web GUI 

    http://[ip to camera system]:8085/camera

## Build installer and software installation 

Above steps are used to build, install, and test the software on local system, which is used for debugging and testing. 

The runtime software can be installed and run on other systems, as below: 

1. Create the installer 

On the development system, configured as above, create the installer: 

    cd ~/Reeplayer/camera_ros/src/cmaera_ros 
    build.sh -ai 

2. Install the software on other systems 

Distributed the compressed file "camera-1.x.x.tar.gz" created by above step to target systems, and install as below: 

    mkdir -p /opt/reeplayer
    sudo chown -R $(id -u):$(id -g) /opt/reeplayer
    tar -xzvf -C /opt/reeplayer camera-1.x.x.tar.gz 
    cd /opt/reeplayer/camera-1.x.x
    ./install.sh 

Once the software is installed in target system, it will automatically check and update to the latest version. 

The software will launched with the system startup.

To uninstall the software from target system: 

    cd /opt/reeplayer/camera 
    ./uninstall.sh 
