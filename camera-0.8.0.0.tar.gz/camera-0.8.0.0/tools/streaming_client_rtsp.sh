#!/bin/bash

HOST=127.0.0.1
PORT=8554
STREAM=live

function print_help { 
  echo "Usage: $0 [-i ${HOST}] [-p ${PORT}] [-s ${STREAM}] [-h]"
  echo "-i: streaming host IP"
  echo "-p: streaming port"  
  echo "-s: stream name" 
  echo "-h: help"
} 

while getopts ":i:p:s:h" opt; do
  case $opt in
    i) HOST="$OPTARG";;
    p) PORT="$OPTARG";;
    s) STREAM="$OPTARG";;
    \? | h | *) print_help; exit 0;;
  esac
done

echo "rtsp://${HOST}:${PORT}/${STREAM}"

gst-launch-1.0 rtspsrc location=rtsp://${HOST}:${PORT}/${STREAM} ! queue ! rtph264depay ! h264parse ! queue ! avdec_h264 ! autovideosink sync=false async=false -e
