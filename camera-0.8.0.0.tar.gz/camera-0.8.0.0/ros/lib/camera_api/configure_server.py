#!/usr/bin/env python 

import json 
import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse
from camera_ros import Camera, Footage, Uploader, Recorder, Calibrator

from concurrent import futures
import grpc

# Configure service 
from camera_api import configure_service_pb2, configure_service_pb2_grpc


class ConfigureServicer(configure_service_pb2_grpc.ConfigureServiceServicer): 
    """Service to access and update the configuration
    """
    def __init__(self): 
        super(ConfigureServicer, self).__init__()
        ## connect to ROS service of camera node 
        self.camera = Camera() 
        self.footage = Footage()
        self.uploader = Uploader()
        self.recorder = Recorder()
        self.calibrator = Calibrator() 


    def check(self, request, context):
        """Check the configuration for one or more nodes 
        """
        rospy.loginfo("Configure check")
        try: 
            if request.system == "camera": 
                values = self.camera.check_config(request.nodes)
            elif request.system == "footage": 
                values = self.footage.check_config(request.nodes)
            elif request.system == "uploader": 
                values = self.uploader.check_config(request.nodes)
            elif request.system == "recorder": 
                values = self.recorder.check_config(request.nodes)
            elif request.system == "calibrator": 
                values = self.calibrator.check_config(request.nodes)
            else:
                raise Exception("Invalid system: {}".format(request.system))
            return configure_service_pb2.ConfigValues(values=values)
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def update(self, request, context):
        """Update the configuration for one or more nodes
        """
        rospy.loginfo("Configure update")
        try: 
            if request.system == "camera": 
                self.camera.update_config(request.values)
            elif request.system == "footage": 
                self.footage.update_config(request.values)
            elif request.system == "uploader": 
                self.uploader.update_config(request.values)
            elif request.system == "recorder": 
                self.recorder.update_config(request.values)
            elif request.system == "calibrator": 
                self.calibrator.update_config(request.values)
            else:
                raise Exception("Invalid system: {}".format(request.system))
            return configure_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def reset(self, request, context):
        """Reset the configuration for one or more nodes 
        """
        rospy.loginfo("Configure reset")
        try: 
            if request.system == "camera": 
                self.camera.reset_config(request.nodes)
            elif request.system == "footage": 
                self.footage.reset_config(request.nodes)
            elif request.system == "uploader": 
                self.uploader.reset_config(request.nodes)
            elif request.system == "recorder": 
                self.recorder.reset_config(request.nodes)
            elif request.system == "calibrator": 
                self.calibrator.reset_config(request.nodes)
            else:
                raise Exception("Invalid system: {}".format(request.system))
            return configure_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def save(self, request, context):
        """Save the configuration for one or more nodes 
        """
        rospy.loginfo("Configure save")
        try: 
            if request.system == "camera": 
                self.camera.save_config(request.nodes)
            elif request.system == "footage": 
                self.footage.save_config(request.nodes)
            elif request.system == "uploader": 
                self.uploader.save_config(request.nodes)
            elif request.system == "recorder": 
                self.recorder.save_config(request.nodes)
            elif request.system == "calibrator": 
                self.calibrator.save_config(request.nodes)
            else:
                raise Exception("Invalid system: {}".format(request.system))
            return configure_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def apply(self, request, context):
        """Apply the configuration for one or more nodes 
        """
        rospy.loginfo("Configure applay")
        try: 
            if request.system == "camera": 
                self.camera.apply_config(request.nodes)
            elif request.system == "footage": 
                self.footage.apply_config(request.nodes)
            elif request.system == "uploader": 
                self.uploader.apply_config(request.nodes)
            elif request.system == "recorder": 
                self.recorder.apply_config(request.nodes)
            elif request.system == "calibrator": 
                self.calibrator.apply_config(request.nodes)
            else:
                raise Exception("Invalid system: {}".format(request.system))
            return configure_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


class ConfigureServer(object):
    def __init__(self): 
        ## gRPC server  
        num_threads = 4 
        ropy.loginfo("Service thread pool size: {}".format(num_threads))
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=num_threads))

        rospy.loginfo("Serve configure service")
        configure_service_pb2_grpc.add_ConfigureServiceServicer_to_server(
            ConfigureServicer(),
            server
        )
        
        service_port = 50051
        ropy.loginfo("Listen on port: {}".format(service_port))
        self.server.add_insecure_port("[::]:{}".format(service_port))
        self.server.start()


    def wait_for_shutdown(self): 
        self.server.stop( )
        self.server.wait_for_termination()


if __name__ == "__main__":
    rospy.init_node("configure_server", log_level=rospy.DEBUG)
    server = ConfigureServer() 
    try:
        rospy.spin()
    except rospy.ROSInterruptException:
        print("ROS interrupted")
    server.wait_for_shutdown() 
    print("Service shutdown")
