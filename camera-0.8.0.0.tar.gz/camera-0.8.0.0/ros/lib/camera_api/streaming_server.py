#!/usr/bin/env python 

import json 
import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse
from camera_ros import Video  

from concurrent import futures
import grpc

# Streaming service 
from camera_api import streaming_service_pb2, streaming_service_pb2_grpc


class StreamingServicer(streaming_service_pb2_grpc.StreamingServiceServicer):
    """Service to control and monitor streaming 
    """
    def __init__(self): 
        super(StreamingServicer, self).__init__()
        ## connect to ROS service of Video node 
        self.Video = Video() 

    def start(self, request, context):
        """Start streaming 
        """
        rospy.loginfo("Streaming start") 
        try: 
            self.Video.start_streaming()
            return streaming_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))

    def pause(self, request, context):
        """Pause streaming 
        """
        logging.info("Streaming pause") 
        try: 
            self.Video.pause_streaming()
            return streaming_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))

    def resume(self, request, context):
        """Resume the paused streaming 
        """
        logging.info("Streaming resume") 
        try: 
            self.Video.resume_streaming()
            return streaming_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))

    def stop(self, request, context):
        """Stop streaming 
        """
        logging.info("Streaming stop") 
        try: 
            self.Video.stop_streaming()
            return streaming_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))

    def check_status(self, request, context):
        """Check the status of streaming 
        """
        logging.info("Streaming check status")
        try: 
            result = self.Video.check_streaming_status() 
            status = json.dumps(result)
            rospy.loginfo("Streaming check status result: {}".format(status))
            return streaming_service_pb2.StreamingStatusResponse(status=status)
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))

    def watch_status(self, request, context):
        """Watch the status of streaming, in stream 
        """
        logging.info("Streaming watch status")
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def snapshot(self, request, context):
        """Snapshot of the video for streaming
        """
        logging.info("Streaming snapshot: {}".format(request.image_scale))
        try: 
            images = self.recorder.recording_snapshot(request.image_scale) 
            return streaming_service_pb2.camera__api_dot_snapshot__pb2.SnapshotResponse(images=images)
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


class StreamingServer(object):
    def __init__(self): 
        ## gRPC server  
        num_threads = 4 
        ropy.loginfo("Service thread pool size: {}".format(num_threads))
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=num_threads))

        rospy.loginfo("Serve streaming service")
        streaming_service_pb2_grpc.add_StreamingServiceServicer_to_server(
            StreamingServicer(),
            server
        )
        
        service_port = 50051
        rospy.loginfo("Listen on port: {}".format(service_port))
        self.server.add_insecure_port("[::]:{}".format(service_port))
        self.server.start()


    def wait_for_shutdown(self): 
        self.server.stop( )
        self.server.wait_for_termination()


if __name__ == "__main__":
    rospy.init_node("streaming_server", log_level=rospy.DEBUG)
    server = StreamingServer() 
    try:
        rospy.spin()
    except rospy.ROSInterruptException:
        print("ROS interrupted")
    server.wait_for_shutdown() 
    print("Service shutdown")
