#!/usr/bin/env python

import os
import requests
from concurrent.futures import *
from enum import Enum

try:
    from urllib.parse import urlparse
except ImportError:
     from urlparse import urlparse

## The files will be pushed into the uploading threads, and transit 
## in below status.  

class UploadingStatus(Enum):
    Stopped = 0 
    Failed = 1 
    Waiting = 2
    Uploading = 3
    Uploaded = 4 


class FilesUploader(object):
    def __init__(self, status_callback, max_workers = 5): 
        self.status_callback = status_callback 
        self.executer = ThreadPoolExecutor(max_workers)
        self.futures = {}

    ## enqueue a file for uploading, the caller should set the status 
    ## to Waiting if return True. 
    def add(self, file_path, url):
        with self.lock: 
            if file_path not in self.futures: 
                future = self.excuter.submit(self.uploading, file_path, url)
                self.futures[file_path] = future 
                future.add_done_callback(self.uploading_done)
                return True 
            else: 
                return False 
    
    ## remove a file form uploading queue. the caller should set the status 
    ## to Stopped if return True 
    def remove(self, file_path): 
        with self.lock: 
            if file_path in self.futures: 
                if self.futures.cancel():  
                    del self.futures[file_path]
                    return True 
                else: 
                    return False 
            else: 
                return False

    def uploading(self, file_path, url): 
        self.status_callback(file_path, UpoadingStatus.Uploading)
        files = {"file": (urlparse(url).path[1:], open(file_path, "rb"))}
        resp = requests.put(url, files=files)
        return file_path, resp.status_code

    def uploading_done(self, future): 
        logging.info("uploading done")
        try: 
            file_path, status_code = future.result() 
            with self.lock: 
                del self.futures[file_path]
            status = UploadingStatus.Uploaded if status_code == 200 else UploadingStatus.Failed 
            self.status_callback(file_path, status) 
        except CanceledError as e: 
            logging.error("uploading canceled")
