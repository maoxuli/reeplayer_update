import json 
import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService 


class Recorder(object):
    def __init__(self):
        self.status_topic = "recorder_status" 
        self.status_sub = None 

        recorder_rpc_service = "recorder_rpc"
        rospy.loginfo("Connecting to ROS service: {}".format(recorder_rpc_service))
        self.rpc_service = rospy.ServiceProxy(recorder_rpc_service, JsonService)
        # rospy.loginfo("Waiting for ROS service: {}".format(recorder_rpc_service))
        # rospy.wait_for_service(recorder_rpc_service)
        # rospy.loginfo("Connected to ROS service: {}".format(recorder_rpc_service))


    def subscribe_status(self, status_callback): 
        def msg_callback(msg): 
            try: 
                rospy.logdebug(msg)
                notifications = json.loads(msg.data)
                statuses = {}
                for notification in notifications:
                    statuses[notification["method"]] = notification["params"] 
                status_callback(statuses)
            except Exception as e: 
                rospy.logwarn("Recorder status topic callback error: " + str(e))
                
        rospy.loginfo("Subscribe ROS topic: {}".format(self.status_topic))
        self.status_sub = rospy.Subscriber(self.status_topic, JsonString, msg_callback) 


    def unsubscribe_status(self): 
        if self.status_sub: 
            rospy.loginfo("Unsubscribe ROS topic: {}".format(self.status_topic))
            self.status_sub.unregister()


    def _call_ros_service(service, method, params = None):
        request = jsonrpc_wrap_request(method, params)
        if not jsonrpc_validate_request(request): 
            raise Exception("Invalid JSON-RPC request: {}".format(request))
        try: 
            rospy.logdebug("JSON-RPC request: {}".format(request))
            response = json.loads(service(json.dumps(request)).data)
            # rospy.logdebug("JSON-RPC response: {}".format(response))
            return response["result"] if "result" in response else None 
        except rospy.ServiceException as e:
            raise Exception("Call ROS service failed: {}".format(e))
        except ValueError as e: 
            raise Exception("Invalid JSON value: {}".format(e))


    def enable_live(self, mode): 
        return _call_ros_service(self.rpc_service, "enable_live", {"mode": mode})


    def disable_live(self): 
        return _call_ros_service(self.rpc_service, "disable_live")


    def live_status(self):
        return _call_ros_service(self.rpc_service, "live_status")   


    def start_recording(self, footage = None):
        return _call_ros_service(self.rpc_service, "start_recording", {"footage_id": footage})


    def stop_recording(self):
        return _call_ros_service(self.rpc_service, "stop_recording") 


    def pause_recording(self):
        return _call_ros_service(self.rpc_service, "pause_recording")  


    def resume_recording(self):
        return _call_ros_service(self.rpc_service, "resume_recording")  


    def recording_status(self):
        return _call_ros_service(self.rpc_service, "recording_status")   


    def start_streaming(self):
        pass 


    def stop_streaming(self):
        pass 


    def pause_streaming(self):
        pass 


    def resume_streaming(self):
        pass 


    def streaming_status(self): 
        pass 


    def capture_snapshot(self, image_scale = 0): 
        return _call_ros_service(self.rpc_service, "capture_snapshot", {"image_scale": image_scale}) 


    def stitching_snapshot(self, image_scale = 0): 
        return _call_ros_service(self.rpc_service, "stitching_snapshot", {"image_scale": image_scale})


    def recording_snapshot(self, image_scale = 0): 
        return _call_ros_service(self.rpc_service, "recording_snapshot", {"image_scale": image_scale})    


    def streaming_snapshot(self, image_scale = 0): 
        return _call_ros_service(self.rpc_service, "streaming_snapshot", {"image_scale": image_scale})
