import json 
import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService 


class Calibrator(object):
    def __init__(self):
        self.status_topic = "calibrator_status" 
        self.status_sub = None 

        calibrator_rpc_service = "calibrator_rpc"
        rospy.loginfo("Connecting to ROS service: {}".format(calibrator_rpc_service))
        self.rpc_service = rospy.ServiceProxy(calibrator_rpc_service, JsonService)
        # rospy.loginfo("Waiting for ROS service: {}".format(calibrator_rpc_service))
        # rospy.wait_for_service(calibrator_rpc_service)
        # rospy.loginfo("Connected to ROS service: {}".format(calibrator_rpc_service))
 

    def subscribe_status(self, status_callback): 
        def msg_callback(msg): 
            try: 
                rospy.logdebug(msg)
                notifications = json.loads(msg.data)
                statuses = {}
                for notification in notifications:
                    statuses[notification["method"]] = notification["params"] 
                status_callback(statuses)
            except Exception as e: 
                rospy.logwarn("Calibrator status topic callback error: " + str(e))
                
        rospy.loginfo("Subscribe ROS topic: {}".format(self.status_topic))
        self.status_sub = rospy.Subscriber(self.status_topic, JsonString, msg_callback) 


    def unsubscribe_status(self): 
        if self.status_sub: 
            rospy.loginfo("Unsubscribe ROS topic: {}".format(self.status_topic))
            self.status_sub.unregister()


    def _call_ros_service(service, method, params = None):
        request = jsonrpc_wrap_request(method, params)
        if not jsonrpc_validate_request(request): 
            raise Exception("Invalid JSON-RPC request: {}".format(request))
        try: 
            rospy.logdebug("JSON-RPC request: {}".format(request))
            response = json.loads(service(json.dumps(request)).data)
            # rospy.logdebug("JSON-RPC response: {}".format(response))
            return response["result"] if "result" in response else None 
        except rospy.ServiceException as e:
            raise Exception("Call ROS service failed: {}".format(e))
        except ValueError as e: 
            raise Exception("Invalid JSON value: {}".format(e))


    def enable_calibration(self): 
        return _call_ros_service(self.rpc_service, "enable_calibration") 


    def disable_calibration(self): 
        return _call_ros_service(self.rpc_service, "disable_calibration") 


    def calibration_status(self): 
        return _call_ros_service(self.rpc_service, "calibration_status") 


    ## call calibrator's ROS action 
    def online_calib(self): 
        pass 
