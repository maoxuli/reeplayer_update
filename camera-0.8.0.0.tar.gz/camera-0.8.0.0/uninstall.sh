#!/bin/bash

## Uninstall the camera software system  

echo "$(date +"%Y-%m-%d %T"): uninstall camera system..."

## run in camera or camera-x.x.x.x folder 
CAMERA_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "CAMERA_DIR: ${CAMERA_DIR}" 

## disable systemd service 
. ${CAMERA_DIR}/scripts/camera-service.sh uninstall 
. ${CAMERA_DIR}/scripts/system-service.sh uninstall 

echo "$(date +"%Y-%m-%d %T"): uninstall camera system done!"
