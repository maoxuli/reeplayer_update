# Camera

The camera software system. 

## Work on the source code

1. Repositories 

The source code of the camera software system is included in below git repositories: 

    reeplayer-camera  
    reeplayer-camera-core  
    reeplayer-camera-protos  

    reeplayer-camera-api
    reeplayer-camera-uploader
    reeplayer-camera-recorder  
    reeplayer-camera-calibrator  
 
To simplify the setup of the development envioronments, some .repos files are included in the "reeplayer-camemra" repo, so you may use the "vcstool" to manage the source code from other repositories, according to your task. 

    * cmaera_all.repos  

The "camera_all.repos" will download the source code for all software modules, so it could be used to test and debug the system, or build the installation package. 

To work on specific one or more software modules, you may use below ".repos" file. 

    * camera_core.repos 
    * camera_api.repos 
    * camera_upload.repos 
    * camera_calib.repos 
    * camera_video.repos  


2. Download the source code 

The "reeplayer_camera" repo is the base repo of the software system, so you will always start from pulling it to your local system. Let's suppose you use the "camera" as the root folder of the software source code. 

    cd ~ 
    git clone https://github.com/Reeplayer-HQ/reeplayer-camera camera 

You will get the base code/scripts downloaded into the "~/camera" folder. We will use vcstool to manage the source code, use docker and docker-compose to launch the functional services/modules, and use other tools to manage/test the hardware and software states, you need to install the minimum dependencies with the helper script as below:  

    cd ~/camera/installation  
    ./system_install.sh  

 Now according to your task, you need to determine what extra source code you need to pull. You will find multiple ".repos" files inside the "~camera" folder. Let's suppose you will work on the uploading functions. You may pull the code as below: 

    cd ~/camera 
    vcs import src < camera_upload.repos 


## Using docker containers 

We have made some docker containers as the runtime environment for the software system. When the software (modules) is launched with the docker-compose, the corresponding docker container will be started.

The docker container can be used as the development environments, so you do not need to install and setup the development environments on your native system. For example, you may start the default docker container on a Jeson system, which could be used to build all the software modules. 

    cd ~/camera/docker  
    ./docker_start  

The default docker container will mount the "~/camera" folder and the "/opt/reeplayer/camera" folder from native system with the same name inside the docker container. So you may access those folders inside the docker container, in that same way of the native system.  


## Build from source code 

It depends on your task about how to build the software/modules from the source. But first of all, if you try to build from the source on your native system, e.g. you PC with ubuntu 18.04/20.04, or Jetson Xavier NX with L4T, you need to install the necessary dependencies for the software modules you are invovling. The simple way is using the docker container. Either on native system or inside the docker container, the steps to build the software from source code are same. 

Let's support you will build the entire software system, for system debugging, testing, or generating the installation package, you can use the "build.sh" script. 

    cd ~/camera  
    ./build.sh  

We also provide some help scripts to build the software modules, respectively, for example, to build the "camera-core" with "build.sh". 

    cd ~/camera/src/camera-core  
    ./build.sh  

For the ROS packages, you may build with the common ROS tools.

    cd ~/camera  
    catkin_make  

You can always refer to the "README" in the source code folder to get more details. 


## Run the software/modules for testing 

If you work on the source code of the camera software, or you are doing testing work of the hardware or software, you may need to run the software system manually. 

First of all, after you build the software system (or modules) form source code, there will be two copies of the software that can run, one is in your source code folder, and the other is in the installation folder "/opt/reeplayer/camera". You should be aware that when you run the software in differnet location, it will use the scripts and configuration files in the same location. So if you are doing debugging and testing, and may modify the code during the test, you should run the software directly in your source code folder. If you try to test the software you just built from source code to verify the functions, you may run the software in the installation location. And of course you may run the software modules you are now working on in the source code folder, and run other part of the system in the installation location.  

1. Run software modules with docker continers 

In addition, all software modules are supposed to run in docker containers. We use docker-compose to managem the docker containers. You may start and stop one or more docker contianers as below, which will run the software modules inside the docker containers. 

    cd ~/camera   (or cd /opt/reeplayer/camera)
    docker-compose up 

or 

    docker-compose up camera  
    docker-compose up api 
    docker-compose up uploader 

2. Run software modules with bash scripts 

We have a bash script for each software module to start and stop the software module. The docker container also start the corresponding software modules with the bash script. So you may directly run the software modules with the bash script in the docker container or on the native system (if you have install and setup the runtime environment). 

    cd ~/camera/scripts  
    ./camera.sh <start|stop>  
    
    ./launch_camera.sh  
    ./launch_api.sh  
    ./launch_uploader.sh  

3. Run the software modules with ROS commands 

The software is based on ROS framework, so the software modules are developed as the ROS nodes. You may use the ROS commands to run the software modules. We have included the "launch" file for each ROS node, so you may use "roslaunch" command to start and stop the software modules. 

    cd ~/camera
    source devel/setup.bash  

or 

    cd /opt/reeplayer/camera  
    source ros/setup.sh  

    roslaunch camera camera.launch  
    roslaunch camera_api camera_api.launch 
    roslaunch camera_uploader camera_uplaoder.launch 
    roslaunch camera_recorder camera_recorder.launch 


## Install the camera software system 

The "install" here means install and setup the camera software so that it will launched with the operating system. Then you can access the camera system through the "Web UI" or the mobile app. 

1. Install the software system for testing in development environment 

If you are working in development environment and have built the software system from source code, and you would like to debug/test the functions relevant to the installation, you may directly install the software you just built from source code. 

After the building from source code, the software will be installed in the "/opt/reeplayer/camera" folder. You may install the software as below:  

    cd /opt/reeplayer/camera  
    ./install.sh  

2. Install the software system on a new camera device  

You can install the camera software system on a new camera device with the installation package. Let's suppose you have complete the basic installation and setup of the camera device following the "installation" guide, and now it is time to install the "camera software system". 

Let's suppose you have download the installation package "camera-0.8.0.0.tar.gz". 

    cp ~/Downloads/camera-0.8.0.0.tar.gz /opt/reeplayer  
    cd /opt/reeplyaer  
    tar -xzvf camera-0.8.0.0.tar.gz  
    cd camera-0.8.0.0  
    ./install.sh  

3. Uninstall the camera software system  

If you would like to uninstall the camera software so that it will not launched with the operating system, you may uninstall it with script as below:  

    cd /opt/reeplayer/camera  
    ./uninstll.sh  


## Access the camera system with Web UI or mobile app  

The camera is designed to work as a headless system, so you need to use the Web UI or the mobile app to access the camera system over the network. Please refer to the documents for more details to use the Web UI and the mobile app. 
