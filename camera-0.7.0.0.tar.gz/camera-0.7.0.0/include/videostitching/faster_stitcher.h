#ifndef __FASTER_STITCHER_H
#define __FASTER_STITCHER_H

#include <opencv2/opencv.hpp>
#include <opencv2/stitching.hpp>
#include <opencv2/cudaarithm.hpp>
#include <opencv2/cudabgsegm.hpp>
#include "opencv2/cudafilters.hpp"

#include "fast_warpers.h"
#include "fast_blenders.h"
#include "fast_compensator.h"
#include "gpu_seam_finder.hpp"

#include <thread>
#include <atomic>
#include <mutex>
#include <condition_variable>

namespace videostitching {

class FasterStitcher
{
public: 
    struct Settings
    {
        std::string config_path; 
        std::string camera_info_path = "camera_info"; 
        std::string camera_params_path = "camera_params"; 
        std::string camera_model = "pinhole"; // pinhole | fisheye 
        std::string warp_type = "spherical"; // shperical | cylindrical 
        cv::Size undistort_size = cv::Size(0,0); 
        std::string expos_comp_type = "no"; // no, gain, gain_blocks
        int expos_comp_nr_feeds = 3;
        int expos_comp_nr_filtering = 3;
        int expos_comp_block_size = 32;
        double expos_comp_scale = 0.2; 
        int expos_comp_interval = 30; 
        std::string seam_type = "no"; // no, graphcut
        int seam_find_iterations = 10;
        int seam_find_terminal_cost = (int)1e7;
        int seam_find_window_min = 9;
        int seam_find_window_max = 23;
        int seam_find_bad_penalty = (int)1e7;
        int seam_find_gap_width = 5;
        double seam_scale = 0.1; 
        int blend_margin = 100; 
        std::string blend_type = "multiband"; // simple, feather, multiband 
        int num_bands = 5; 
        size_t queue_size = 5;  

        Settings(const std::string& config = ""); 
        std::string to_string() const; 
    };

    struct Settings
    {
        int num_cameras = 2; 
        cv::Size image_size; 
        std::string config_file; 
        Settings() {}
    };

    FasterStitcher(const Settings& settings = Settings()); 
    ~FasterStitcher(); 

    cv::Size output_size() { return _out_roi.size(); } 
    void feed(std::vector<cv::cuda::GpuMat>& in_images, uint64_t timestmap = 0, uint64_t duration = 0);

    typedef std::function<bool (cv::cuda::GpuMat&, uint64_t timestamp, uint64_t duration)> StitcherCallback;
    void set_callback(const StitcherCallback& cb) { _stitcher_callback = cb; };

private:
    int _num_cameras; 
    cv::Size _image_size; 

    
    InternalSettings _settings;

    // undistortion warping 
    void prepare_undistortion(); 
    std::vector<cv::Ptr<UndistortWarper> > _undistort_warpers; 
    std::vector<cv::cuda::GpuMat> _undistort_images; 
    std::vector<cv::Rect> _undistort_rects; 
    cv::Size _undistort_size; // same for two camera and smaller than input size 

    // projection warping 
    void prepare_projection();
    std::vector<cv::Ptr<ProjectWarper> > _project_warpers;
    std::vector<cv::Rect> _warped_rects;
    std::vector<cv::Point> _warped_corners; 
    std::vector<cv::Size> _warped_sizes; 
    std::vector<cv::cuda::GpuMat> _warped_masks; 
    // std::vector<cv::cuda::GpuMat> _warped_images;
    cv::cuda::GpuMat _out_image; 
    cv::Size _stitched_size; 
    cv::Rect _out_roi; 

    // compensate exposure for warped images 
    void prepare_compensation(); 
    cv::Ptr<ExposureCompensator> _compensator;
    std::vector<cv::Point> _expos_comp_corners; // after scale 
    std::vector<cv::UMat> _expos_comp_masks; // after scale, so indicate scaled size n

    void expos_comp_thread(); 
    std::thread _expos_comp_thread; 
    std::atomic<bool> _stop_expos_comp; 
    std::vector<cv::UMat> _expos_comp_queue; // downloaded from warped images 
    bool _expos_comp_queue_empty; 
    std::mutex _expos_comp_queue_mutex; 
    std::condition_variable _expos_comp_condition;

    std::vector<cv::cuda::GpuMat> _expos_comp_maps; // same size of warped images
    std::mutex _expos_comp_maps_mutex; 

    // blend overalap region of the warped images 
    void prepare_blending(); 
    cv::Ptr<FastBlender> _blender; 
    std::vector<cv::Rect> _blend_rects; 
    std::vector<cv::Point> _blend_corners;
    std::vector<cv::Size> _blend_sizes; 
    std::vector<cv::cuda::GpuMat> _blend_masks; 
    cv::cuda::GpuMat _blended_image; 
    cv::Rect _blended_rect; 

    // find seam for blending 
    void prepare_seam_finding(); 
    // cv::Ptr<cv::detail::SeamFinder> _seam_finder; 
    cv::Ptr<cv::detail::CudaGraphCutSeamFinder> _seam_finder;
    std::vector<cv::Point> _seam_find_corners;
    std::vector<cv::cuda::GpuMat> _seam_find_masks;
    std::vector<cv::cuda::GpuMat> _seam_find_images; 
    std::vector<cv::cuda::GpuMat> _seam_found_masks; 

    cv::Ptr<cv::cuda::Filter>  _dilater; 
    std::vector<cv::cuda::GpuMat> _dilated_masks; 
    std::vector<cv::Ptr<cv::cuda::BackgroundSubtractorMOG2> > _fg_detectors; 
    std::vector<cv::cuda::GpuMat> _seam_fg_masks; 

    // processing pool 
    void prepare_pool();  

    // Batch buffer, passed through the pipeline  
    struct Batch
    {
        uint64_t frame_id; 
        uint64_t timestamp;
        uint64_t duration; 
        std::vector<cv::cuda::GpuMat> bgr_images; 
        std::vector<cv::cuda::GpuMat> warped_images; 
        std::vector<cv::cuda::GpuMat> seam_masks; 
    };

    // input  
    std::atomic<bool> _stop_input; 
    std::deque<std::shared_ptr<Batch> > _input_queue; 
    std::mutex _input_mutex; 
    std::condition_variable _input_condition;

    uint64_t _frame_count;
    std::vector<cv::cuda::Stream> _input_streams;
    int _input_count = 0; 
    unsigned long _input_sum = 0; 

    // warping  
    void warp_thread(); 
    std::thread _warp_thread; 
    std::atomic<bool> _stop_warp; 
    std::deque<std::shared_ptr<Batch> > _warp_queue; 
    std::mutex _warp_mutex; 
    std::condition_variable _warp_condition; 

    // seam finding     
    void seam_thread(); 
    std::thread _seam_thread; 
    std::atomic<bool> _stop_seam; 
    std::deque<std::shared_ptr<Batch> > _seam_queue; 
    std::mutex _seam_mutex; 
    std::condition_variable _seam_condition; 

    // blending     
    void blend_thread(); 
    std::thread _blend_thread; 
    std::atomic<bool> _stop_blend; 
    std::deque<std::shared_ptr<Batch> > _blend_queue; 
    std::mutex _blend_mutex; 
    std::condition_variable _blend_condition; 

    // output     
    void output_thread(); 
    std::thread _output_thread; 
    std::atomic<bool> _stop_output; 
    std::deque<std::shared_ptr<Batch> > _output_queue; 
    std::mutex _output_mutex; 
    std::condition_variable _output_condition; 

    StitcherCallback _stitcher_callback; 
};

} // namespace videostitching

#endif 
