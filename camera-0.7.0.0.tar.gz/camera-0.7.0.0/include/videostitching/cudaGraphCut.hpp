#ifndef GPU_CUDA_GRAPH_CUT_HPP
#define GPU_CUDA_GRAPH_CUT_HPP

#include <opencv2/core/cuda.hpp>

#include <iostream>

struct Locations {
    cv::Rect roi;
    cv::Point tl1;
    cv::Point tl2;

    Locations() {}
    Locations(cv::Rect roi_in, cv::Point ptl1, cv::Point ptl2) : roi(roi_in), tl1(ptl1), tl2(ptl2) {}
};


void getAsGpuMat(int* src, cv::cuda::GpuMat& dst, int rows, int cols);
void sign(int* src, cv::cuda::GpuMat& dst, int rows, int cols);
void imagesc(const cv::cuda::GpuMat& gpumat, cv::String str);
void imagesc(int* arr, cv::String str, int rows, int cols);
void saveImagesc(const cv::cuda::GpuMat& gpumat, cv::String filename);
void saveImagesc(int* arr, cv::String filename, int rows, int cols);
void arrayToFile(int* gpuArr, int rows, int cols, cv::String filename);
void fileToArray(cv::String filename, int* gpuArr);

void drawSeam(cv::cuda::GpuMat& subimg1, cv::cuda::GpuMat& subimg2, cv::cuda::GpuMat& submask1, cv::cuda::GpuMat& submask2, cv::cuda::GpuMat& output);

void _not(const cv::cuda::GpuMat& src, cv::cuda::GpuMat& dst);

void localizeSeam(const cv::cuda::GpuMat& mask, std::vector<int>& seam);

void diffImages(
    const cv::cuda::GpuMat& src1,
    const cv::cuda::GpuMat& src2,
    const cv::cuda::GpuMat& src3,
    const cv::cuda::GpuMat& src4,
    cv::cuda::GpuMat& dst);

void copySubimageWithBorder(
    const cv::cuda::GpuMat& src,
    cv::cuda::GpuMat& dst,
    cv::Rect roi,
    cv::Point tl
);


void updateMasks(
    cv::cuda::GpuMat& labels,
    cv::cuda::GpuMat& mask1,
    cv::cuda::GpuMat& mask2,
    cv::Rect roi,
    cv::Point tl1,
    cv::Point tl2,
    int gap
);

void updateMasks(
    cv::cuda::GpuMat& labels,
    cv::cuda::GpuMat& mask1,
    cv::cuda::GpuMat& mask2,
    cv::cuda::GpuMat& submask1,
    cv::cuda::GpuMat& submask2,
    cv::cuda::GpuMat& prevmask1,
    cv::cuda::GpuMat& prevmask2,
    cv::Rect roi,
    cv::Point tl1,
    cv::Point tl2,
    int gap
);


void updatePrevMask(
    const cv::cuda::GpuMat& submask,
    const cv::cuda::GpuMat& src,
    cv::cuda::GpuMat& dst,
    int border
);


void processPrevSeam(
    cv::cuda::GpuMat& submask1,
    cv::cuda::GpuMat& submask2,
    cv::cuda::GpuMat& seamMask,
    cv::cuda::GpuMat& prevsubmask1,
    cv::cuda::GpuMat& prevsubmask2);


class CudaGCGraph {

public:

    CudaGCGraph() { init(0, 0, 2, false); }

    CudaGCGraph(int col, int row, int numLabels = 2) { init(col, row, numLabels); }

    ~CudaGCGraph() { cudaCutsFreeMem(); }

    void init(int col, int row, int numLabels = 2, bool allocateMemory = true);

    // Function to update last residual graph with weights for next frame,
    // reusing result from last max-flow optimization. Only used for video frames
    void updateLastResidualGraph(
        const cv::cuda::GpuMat& img1,
        const cv::cuda::GpuMat& img2,
        const cv::cuda::GpuMat& originalMask1,
        const cv::cuda::GpuMat& originalMask2,
        const cv::cuda::GpuMat& mask1,
        const cv::cuda::GpuMat& mask2,
        const cv::cuda::GpuMat& fg1,
        const cv::cuda::GpuMat& fg2,
        int terminalCost,
        int badRegionPenalty
    );

    // Function to compute graph weights, only used for standalone images
    void setGraphWeightsColor(
        const cv::cuda::GpuMat& img1,
        const cv::cuda::GpuMat& img2,
        const cv::cuda::GpuMat& originalMask1,
        const cv::cuda::GpuMat& originalMask2,
        const cv::cuda::GpuMat& mask1,
        const cv::cuda::GpuMat& mask2,
        const cv::cuda::GpuMat& fg1,
        const cv::cuda::GpuMat& fg2,
        int terminalCost,
        int badRegionPenalty,
        bool setResiduals = true
    );

    // Function to solve the maxflow/mincut problem
    int maxflow(
        cv::cuda::GpuMat& labels,
        const cv::cuda::GpuMat& mask1,
        const cv::cuda::GpuMat& mask2,
        int iterationsPerCheck = 20, 
        int maxBfsCount = 100)
    {
        cudaCutsStochastic(iterationsPerCheck);
        int forceRestart = bfsLabeling(mask1, mask2, maxBfsCount);        
        if (!forceRestart)
            cudaCutsGetResult(labels);
        return forceRestart;
    }

    // Function to update seam localization for current frame 
    void updateSeam(const cv::cuda::GpuMat& mask, bool firstFrame = false);

    // This function updates original capacities, which will be needed when processing the next frame
    // Only used for video frames
    void updateEdgeCapacities();

    // This function updates previous mask with last seam found
    void updateSeamMask(
        const cv::cuda::GpuMat& submask,
        cv::cuda::GpuMat& dst,
        int border
    );

protected:

    // Functions to initialize memory for graph
    void h_mem_init();
    void d_mem_init();

    // Function to solve the maxflow problem
    void cudaCutsStochastic(int iterationsPerCheck);

    // This function finds which nodes are in source set or the sink set
    int bfsLabeling(const cv::cuda::GpuMat& mask1, const cv::cuda::GpuMat& mask2, int maxBfsCount);

    // This function assigns a label to each pixel and stores them in pixelLabel
    // array of size width * height
    int cudaCutsGetResult(cv::cuda::GpuMat& labels);

    // Frees all the memory allocated on the host and the device
    void cudaCutsFreeMem();

    /*************************************************
     * n-edges and t-edges                          **
     *************************************************/

    int* d_left_weight, * d_right_weight, * d_down_weight, * d_up_weight, * d_excess_flow;
    int* orig_left_weight, * orig_right_weight, * orig_down_weight, * orig_up_weight, * orig_excess_flow;
    int* new_left_weight, * new_right_weight, * new_down_weight, * new_up_weight, * new_excess_flow;

    /*************************************************
     * Height and mask functions are stored         **
     *************************************************/

     // 2 array for heights (double buffering to read and write)
    int* d_relabel_mask, * d_graph_heightr, * d_graph_heightw, * dPixelLabel;

    /*************************************************
     * Grid and Block parameters                    **
     *************************************************/

    int graph_size, size_int, width, height, graph_size1, width1, height1, depth, num_Labels;
    int blocks_x, blocks_y, threads_x, threads_y, num_of_blocks, num_of_threads_per_block;

    /***************************************************
     * Seam info                                      **
     ***************************************************/
    int* seam, *seam_old;


    /***************************************************
     * Label of each pixel is stored in this function **
     ***************************************************/

    int* pixelLabel;

    bool* d_pixel_mask, * d_finish, h_over, * d_over, * h_pixel_mask;
    int* d_counter, *d_relabel, * d_block_num, * h_graph_height;
    int* h_reset_mem;
    int deviceCheck, deviceCount;

    int* h_relabel_mask;
    int counter;

};

#endif // GPU_CUDA_GRAPH_CUT_HPP