#! /usr/bin/env python

import os 
import time
import threading
import json
import socket 
import select 
import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse

from jsonrpc import * 

import uuid 
from datetime import datetime

## Camera node object
class CameraNode(object): 
    RECV_BUFFER_SIZE = 1024 

    def __init__(self): 
        ## communication with camerad service 
        camerad_port = rospy.get_param("~camerad_port", "6666")
        rospy.loginfo("camerad service socket port: {}".format(camerad_port))
        self.camerad_addr = ('127.0.0.1', camerad_port)

        self.camerad_timeout = rospy.get_param("~camerad_timeout", "3.0")
        rospy.loginfo("camerad service timeout: {}".format(self.camerad_timeout))

        self.footage_location = "/home/reeplayer/camera_data"
        self.footage_meta_file = "footage.json" 

        ## dispatch service requests to handlers
        ## this is a list of methods that can be procesed in this object  
        ## all methods not in this list will be forwarded to the systemd service  
        self.service_handlers = { 
            # 'shutdown_system': self.shutdown_system, 
            # 'restart_system': self.restart_system,
            'system_status': self.system_status, 
            # 'scan_wifi': self.scan_wifi,
            # 'connect_wifi': self.connect_wifi,
            # 'disconnect_wifi': self.disconnect_wifi, 
            # 'network_status': self.network_status,
            # 'check_software': self.check_software, 
            # 'download_software': self.download_software, 
            # 'install_software': self.install_software, 
            # 'software_status': self.software_status, 
            'prepare_footage': self.prepare_footage, 
            'remove_footage': self.remove_footage, 
            'footage_status': self.footage_status,
        }
        rospy.loginfo("Service handlers:\n{}".format(self.service_handlers))

        ## A list of status checking methods 
        ## add or remove by status subscribe method 
        self.subscriptions = [
            'system_status',
            # 'network_status',
            'footage_status',
        ]
        rospy.loginfo("Status subscriptions:\n{}".format(self.subscriptions))

        ## camera service 
        rpc_service = "rpc"
        rospy.loginfo("Starting service: {}".format(rpc_service))
        rospy.Service(rpc_service, JsonService, self.rpc_service_handler)

        ## status topic 
        status_topic = "status" 
        rospy.loginfo("Advertise topic: {}".format(status_topic))
        self.status_pub = rospy.Publisher(status_topic, JsonString, queue_size=2)

        ## check and publish state in a thead 
        status_thread = threading.Thread(target=self.status_update_thread)
        status_thread.start()


    ## RPC service handler 
    ## JSON string carried by ROS service request and response  
    def rpc_service_handler(self, request): 
        rospy.loginfo("RPC servcie request: {}".format(request.data))
        json_response = {}
        try: 
            json_request = json.loads(request.data.decode())
            json_response = self.handle_json_request(json_request)
        except: 
            json_reponse = jsonrpc_wrap_error(None, JSON_PARSE_ERROR, get_error_message(JSON_PARSE_ERROR))
        response = json.dumps(json_response)
        rospy.loginfo("service response: {}".format(response))
        return JsonServiceResponse(response.encode())


    ## handle JSON-RPC 2.0 request 
    def handle_json_request(self, request): 
        rospy.loginfo("handle json request: {}".format(request))
        if isinstance(request, list): 
            return self.handle_batch_request(request)
        elif isinstance(request, dict): 
            return self.handle_single_request(request)
        else: 
            return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, get_error_message(RPC_INVALID_REQUEST)); 


    ## handle batch request 
    def handle_batch_request(self, request): 
        rospy.loginfo("handle batch request: {}".format(request))
        if len(request) == 0: 
            return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, get_error_message(RPC_INVALID_REQUEST))
        else: 
            response = [] 
            for requ in request: 
                resp = self.handle_single_request(requ); 
                response.append(resp)
            return response


    ## handle single request 
    def handle_single_request(self, request): 
        rospy.loginfo("handle single request: {}".format(request))
        if jsonrpc_validate_request(request): 
            return self.process_request(request)
        else: 
            return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, get_error_message(RPC_INVALID_REQUEST))


    ## process request 
    def process_request(self, request): 
        rospy.loginfo("process request: {}".format(request))
        method = request["method"]
        if method in self.service_handlers: 
            rospy.loginfo("local handle request: {}".format(request))
            try: 
                return self.service_handlers[method](request)
            except KeyError: 
                return jsonrpc_wrap_error(request, RPC_INVALID_PARAMS, get_error_message(RPC_INVALID_PARAMS))
        else: 
            rospy.loginfo("system handle request: {}".format(request))
            return self.handle_system_request(request)

    # ## shutdown system 
    # def shutdown_system(self, request): 
    #     rospy.loginfo("shutdown system...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)


    # ## restart system 
    # def restart_system(self, request): 
    #     rospy.loginfo("reboot system...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    # ## scan wifi 
    # def scan_wifi(self, request): 
    #     rospy.loginfo("scan wifi...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    # ## connect wifi 
    # def connect_wifi(self, request): 
    #     rospy.loginfo("connect wifi...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    # ## diconnect wifi
    # def disconnect_wifi(self, request): 
    #     rospy.loginfo("disconnect wifi...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)
    
    # ## check network status 
    # def network_status(self, request): 
    #     rospy.loginfo("network status...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    # ## check software update 
    # def check_software(self, request): 
    #     rospy.loginfo("check software update...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    # ## download software update 
    # def download_software(self, request): 
    #     rospy.loginfo("download software update...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    # ## install update 
    # def install_software(self, request): 
    #     rospy.loginfo("install software update...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    # ## software update status
    # def software_status(self, request): 
    #     rospy.loginfo("software update status...")
    #     # forward to systemd service 
    #     return self.handle_system_request(request)

    ## system status 
    def system_status(self, request): 
        systems = request["params"] if "params" in request else []
        rospy.logdebug("Check system status for: {}".format(systems))
        try: 
            statuses = {}
            statuses["battery"] = {"capacity": 100, "percent": 50, "state": 0}
            statuses["cpu"] = {"usage": [20, 10, 12, 21], "frequency": [1190, 1190, 1190, 1190]}
            statuses["memory"] = {"total": 16000000, "used": 2000000, "free": 14000000}
            fs = os.statvfs("/")
            total = fs.f_blocks * fs.f_frsize / 1000000
            free = fs.f_bavail * fs.f_frsize / 1000000
            used = total - free 
            percent = used / total * 100 
            statuses["storage"] = {"total": total, "used": used, "free": free, "percent": percent}
            rospy.logdebug("statuses: {}".format(statuses))
            return jsonrpc_wrap_result(request, statuses)  
        except: 
            jsonrpc_wrap_error(request, RPC_INTERNAL_ERROR, "Error check system status")

    def get_time_string(self): 
        now = datetime.now()
        time_str = now.strftime("%Y_%m_%d_%H_%M_%S")
        rospy.loginfo("time string: {}".format(time_str))
        return time_str

    def get_footage_id(self, location): 
        meta_file = os.path.join(self.footage_location, location, self.footage_meta_file)
        try: 
            with open(meta_file) as f:
                meta = json.load(f)
                return meta["id"] 
        except Exception as e: 
            rospy.logwarn("Error get footage id: {}".format(str(e))) 
            return location

    def get_footage_name(self, location): 
        meta_file = os.path.join(self.footage_location, location, self.footage_meta_file)
        try: 
            with open(meta_file) as f:
                meta = json.load(f)
                return meta["name"]
        except Exception as e:
            rospy.logwarn("Error get footage name: {}".format(str(e))) 
            return location

    def load_footage_ids(self): 
        ids = []
        for location in os.listdir(self.footage_location):
            if os.path.isdir(os.path.join(self.footage_location, location)): 
                ids.append(self.get_footage_id(location))
        rospy.loginfo("footage ids: {}".format(ids))
        return ids 

    def load_footage_files(self, location): 
        rospy.logdebug("load footage files...")
        files = [] 
        try: 
            for filename in os.listdir(os.path.join(self.footage_location, location)):
                filepath = os.path.join(self.footage_location, location, filename)
                if os.path.isfile(filepath):
                    ext = os.path.splitext(filename)[1]
                    if ext == ".mp4" or ext == ".mkv": 
                        files.append({"filename": filename, "content_type": "video", "filepath": filepath})
                    elif ext == ".json": 
                        files.append({"filename": filename, "content_type": "meta", "filepath": filepath})
                    else: 
                        rospy.logwarn("Unknown file type: {}".format(ext))
            rospy.logdebug(files)
        except Exception as e: 
            rospy.logwarn("Error in load footage files: {}".format(str(e)))
        return files

    def update_footage_id(self, location, id): 
        meta_file = os.path.join(self.footage_location, location, self.footage_meta_file)
        try: 
            with open(meta_file) as f:
                meta = json.load(f)
                meta["id"] = id 
        except Exception as e: 
            rospy.logwarn("Error read footage meta: {}".format(str(e)))
            meta = {"id": id}
        try: 
            with open(meta_file, "w+") as f:
                json.dump(meta, f)
        except Exception as e: 
            rospy.logwarn("Error update footage meta: {}".format(str(e)))

    def prepare_footage(self, request): 
        rospy.loginfo("Prepare footage...")
        footage_location = None 
        try: 
            while not footage_location: 
                footage_location = self.get_time_string()
                footage_path = os.path.join(self.footage_location, footage_location)
                if os.path.exists(footage_path): 
                    footage_path = None 
                else: 
                    os.mkdir(footage_path) 
        except Exception as e: 
            rospy.logerr("Error prepare footage location: {}".format(str(e)))
            return jsonrpc_wrap_error(request, RPC_INTERNAL_ERROR, str(e))
        rospy.loginfo("footage location: {}".format(footage_location))
        footage_id = None 
        try: 
            while not footage_id: 
                footage_id = str(uuid.uuid4()) 
                footage_ids = self.load_footage_ids() 
                if footage_id in footage_ids: 
                    footage_id = None 
        except Exception as e: 
            rospy.logerr("Error prepare footage id: {}".format(str(e)))
            return jsonrpc_wrap_exception(request, RPC_INTERNAL_ERROR, str(e))
        rospy.loginfo("footage id: {}".format(footage_id))
        self.update_footage_id(footage_location, footage_id)
        footage = {
            "footage_id": footage_id, 
            "footage_name": footage_location, 
            "footage_location": footage_location}
        return jsonrpc_wrap_result(request, footage)

    def remove_footage(self, request): 
        rospy.loginfo("update footage...")
        return jsonrpc_wrap_error(request, RPC_INTERNAL_ERROR, "Not implemented")

    def footage_status(self, request): 
        rospy.logdebug("footage status...")
        footages = {}
        try: 
            for location in os.listdir(self.footage_location):
                if os.path.isdir(os.path.join(self.footage_location, location)): 
                    footage_id = self.get_footage_id(location)
                    footage_name = self.get_footage_name(location)
                    files = self.load_footage_files(location)
                    footages[footage_id] = {
                        "footage_id": footage_id, 
                        "footage_name": footage_name, 
                        "footage_location": location, 
                        "files": files}
            rospy.logdebug("footages: {}".format(footages))
        except Exception as e: 
            rospy.logwarn("Error in footage status: {}".format(str(e)))
        return jsonrpc_wrap_result(request, footages)

    ## handle request by forwarding to camerad service 
    def handle_system_request(self, request):
        rospy.loginfo("Handle system request: {}".format(request))
        json_request = json.dumps(request)
        json_request += "\n"; # json string in line 
        response = {} 
        try: 
            rospy.loginfo("Connting to service: {}".format(self.camerad_addr))
            conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            conn.connect(self.camerad_addr)
            rospy.loginfo("Sending request: {}".format(json_request))
            conn.sendall(json_request.encode())
            rospy.loginfo("Waiting for response")
            conn.setblocking(0)
            rlist, _, _ = select.select([conn], [], [], self.camerad_timeout)
            if rlist: 
                assert rlist[0] == conn 
                json_response = conn.recv(self.RECV_BUFFER_SIZE).decode()
                rospy.loginfo("Received response: {}".format(json_response))
                response = json.loads(json_response)
            else: 
                rospy.loginfo("Response timeout!")
                response = jsonrpc_wrap_error(request, RPC_SERVER_ERROR, "Response timeout from camerad service")
        except socket.error, msg:
            rospy.loginfo("Socket exception: {}".format(msg))
            response = jsonrpc_wrap_error(request, RPC_SERVER_ERROR, "Socket exception to camerad service")
        except: 
            rospy.loginfo("Exception")
            response = jsonrpc_wrap_error(request, RPC_SERVER_ERROR, "Handle system request exception")
        finally: 
            conn.close() 
        return response 


    ## status update thread 
    def status_update_thread(self): 
        rospy.loginfo("Status update thread in")
        update_rate = rospy.get_param("~status_update_rate", 1.0)
        update_rate = update_rate if update_rate > 0 else 1.0
        rospy.loginfo("status update rate: {}".format(update_rate))
        ros_rate = rospy.Rate(update_rate)
        while not rospy.is_shutdown():
            if self.status_pub.get_num_connections() > 0: 
                status = []
                for method in self.subscriptions:
                    request = {"method": method} 
                    try: 
                        response = self.handle_json_request(request)
                        if "result" in response: 
                            notification = {"method": method, "params": response["result"]}
                            status.append(notification)
                    except: 
                        rospy.logwarn("Exception in status update: " + method)
                if status: 
                    status_msg = JsonString() 
                    status_msg.data = json.dumps(status).encode()
                    rospy.logdebug("Publish status topic: {}".format(status_msg))
                    self.status_pub.publish(status_msg)
            ros_rate.sleep() 
        rospy.loginfo("Status update thread out")


if __name__ == '__main__':
    try:
        rospy.init_node("camera", log_level=rospy.DEBUG)
        CameraNode() 
        rospy.spin()
    except rospy.ROSInterruptException:
        print("ROS interrupted")
