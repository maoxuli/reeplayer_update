#ifndef __JSON_SETTINGS_H
#define __JSON_SETTINGS_H

#include <string>

#include <nlohmann/json.hpp>
using json = nlohmann::json;

namespace jsoncfg {

class Settings
{
public: 
    Settings();
    Settings(const std::string& config_file, const std::string& backup_file = ""); 

    bool load(const std::string& config_file, const std::string& backup_file = "");
    bool reset(const std::string& node = "");
    bool save(const std::string& node = "");
    bool auto_save(const std::string& node = "");

    json& get(const std::string& node); 
    json& operator[] (const std::string& node); 

    const json& get(const std::string& node) const; 
    const json& operator[] (const std::string& node) const;
    
    bool set(const std::string& node, const json& value); 

private: 
    std::string _backup_file; 
    json _backup_settings; 

    std::string _config_file; 
    json _settings; 
};

} // nameapce jsoncfg 

#endif 
