#ifndef __NVGST_SOURCE_BIN_H__
#define __NVGST_SOURCE_BIN_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <nvgstpipeline/nvgst_common.h>
#include <nvgstpipeline/nvgst_video_bin.h>

typedef enum
{
  NVGST_SOURCE_CAMERA_CSI,
} NvGstSourceType;

typedef struct
{
  gboolean enable; 
  NvGstSourceType type;
  gint camera_csi_sensor_id;
  gint source_fps_n;
  gint source_fps_d;
  gint source_width;
  gint source_height;
  gchar *format;
  guint flip_method;
  guint width;
  guint height; 
} NvGstSourceConfig;

typedef struct
{
  GstElement *bin;
  GstElement *src_elem;
  GstElement *src_filter;
  GstElement *conv;
  GstElement *conv_filter;
} NvGstSourceBin;

typedef struct 
{
  GstElement *bin;
  NvGstSourceBin sub_bins[MAX_SOURCE_BINS];
  guint num_bins; 
} NvGstMultiSourceBin;

gboolean parse_source_config (NvGstSourceConfig * config, 
  GKeyFile * key_file, gchar * group);

gboolean create_multi_source_bin (guint num_bins, 
  NvGstSourceConfig * config_array, NvGstMultiSourceBin * bin); 

// dynamic settings for sensor 
float set_source_contrast (GstElement *src_ele, float value);
float set_source_saturation (GstElement *src_ele, float value);
int set_source_auto_exposure_mode (GstElement *src_ele, int value);
float set_source_exposure_time (GstElement *src_ele, float value);
int set_source_auto_exposure_lock(GstElement *src_ele, int value);
int set_source_whitebalance_mode(GstElement *src_ele, int value);
int set_source_scene_mode(GstElement *src_ele, int value);
int set_source_color_effect_mode(GstElement *src_ele, int value);
int set_source_ee_mode(GstElement *src_ele, int value);
float set_source_ee_strength (GstElement *src_ele, float value);
int set_source_flash_mode(GstElement *src_ele, int value);
int set_source_flicker_mode(GstElement *src_ele, int value);
int set_source_tnr_mode (GstElement *src_ele,  int value);
float set_source_tnr_strength (GstElement *src_ele, float value);

#ifdef __cplusplus
}
#endif

#endif
