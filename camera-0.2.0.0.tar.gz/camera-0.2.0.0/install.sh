#!/bin/bash

## The script is used to install the camera system software on 
## current system. After the installation, the camera system software 
## will be launched with the system startup. 

echo "$(date +"%Y-%m-%d %T"): install camera system..."

## the script is on the root of the install dir  
INSTALL_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "INSTALL_DIR: ${INSTALL_DIR}" 

## if install from version package, create symbal link       
VERSION="$( basename "${INSTALL_DIR}" )"
# echo "VERSION: ${VERSION}"
if [ "${VERSION}" != "camera" ] ; then 
  VERSION_DIR="${INSTALL_DIR}"
  INSTALL_DIR="$( readlink -m "${VERSION_DIR}/.." )/camera"
  echo "create symbal link: ${INSTALL_DIR} -> ${VERSION_DIR}"
  ln -snfr "${VERSION_DIR}" "${INSTALL_DIR}"
fi 

## install sytemd service 
# echo "install systemd service..."
sudo "${INSTALL_DIR}/scripts/camera_service.sh" install 

echo "$(date +"%Y-%m-%d %T"): install camera system done!"
