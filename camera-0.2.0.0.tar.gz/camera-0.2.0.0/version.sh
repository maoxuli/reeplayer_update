#!/bin/bash

VERSION=0.2.0.0