#!/bin/bash

## systemd unit 
CAMERA_SERVICE="camera.service"
SYSTEMD="/etc/systemd/system"

install () {
  echo "Install systemd service..."

  ## scripts path
  SCRIPTS="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
  # echo "SCRIPTS: ${SCRIPTS}" 

  ## systemd unit
  SERVICE="${SCRIPTS}/${CAMERA_SERVICE}"
  if [ ! -f "${SERVICE}" ]; then
    echo "${SERVICE} is not found!"
    return 1
  fi
  echo "SERVICE: ${SERVICE}"

  ## install systemd unit
  echo "Install ${SERVICE} to ${SYSTEMD}"
  cp ${SERVICE} ${SYSTEMD}
  systemctl enable ${CAMERA_SERVICE} 
}

uninstall () {
  echo "Uninstall systemd service..."
  if [ -f "${SYSTEMD}/${CAMERA_SERVICE}" ]; then
    echo "Remove ${SYSTEMD}/${CAMERA_SERVICE}"
    systemctl stop ${CAMERA_SERVICE}
    systemctl disable ${CAMERA_SERVICE}
    rm -f ${SYSTEMD}}/${CAMERA_SERVICE}
  fi 
}

case "$1" in
  install)
    install
    ;;
  uninstall)
    uninstall
    ;;
  *)
    echo "Usage: $0 {install|uninstall}"
    ;;
esac 
