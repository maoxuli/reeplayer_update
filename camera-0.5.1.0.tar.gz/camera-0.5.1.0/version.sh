#!/bin/bash

VERSION=0.5.1.0