#!/usr/bin/env python3

"""  Copyright (C) 2020 RidgeRun, LLC (http://www.ridgerun.com)
 All Rights Reserved.

 The contents of this software are proprietary and confidential to RidgeRun,
 LLC.  No part of this program may be photocopied, reproduced or translated
 into another programming language without prior written consent of
 RidgeRun, LLC.  The user is free to modify the source code after obtaining
 a software license from RidgeRun.  All source code changes must be provided
 back to RidgeRun without any encumbrance. """

""" Tool for estimating the homography matrix """


import argparse
import curses
import json
import sys
import time

import cv2
import numpy as np

HOMOGRAPHY_DIMENSION = 3
MIN_MATCHES = 4
CHANNELS = 3
M1TYPE = 5
DEFAULT_REPROJ_ERROR = 4.0
DEFAULT_RATIO = 0.75
DEFAULT_SIGMA = 0
DEFAULT_FOV = 70
DEFAULT_OVERLAP = 15
DEFAULT_CROP = 0
DEFAULT_UNDISTORT = True


def draw_matches(image_a, image_b, keypoints_a, keypoints_b, matches, status):
    '''
   Returns an image with the matches found.

           Parameters:
                   image_a (np.array): Image A
                   image_b (np.array): Image B
                   keypoints_a (np.array): Keypoints for image A
                   keypoints_b (np.array): Keypoints for image B
                   matches (np.array): List of found matches between image
                    A and image B
                   status (int): status of homography estimation

           Returns:
                   Image (np.array)
   '''

    # initialize the output visualization image
    (height_a, width_a) = image_a.shape[:2]
    (height_b, width_b) = image_b.shape[:2]
    vis = np.zeros(
        (max(
            height_a,
            height_b),
            width_a +
            width_b,
            CHANNELS),
        dtype="uint8")
    vis[0:height_a, 0:width_a] = image_a
    vis[0:height_b, width_a:] = image_b

    for ((trainIdx, queryIdx), s) in zip(matches, status):
        # only process the match if the keypoint was successfully
        # matched
        if s == 1:
            # draw the match
            pt_a = (int(keypoints_a[queryIdx][0]),
                    int(keypoints_a[queryIdx][1]))
            pt_b = (int(keypoints_b[trainIdx][0]) +
                    width_a, int(keypoints_b[trainIdx][1]))
            cv2.line(vis, pt_a, pt_b, (0, 255, 0), 1)

    return vis


def detect_and_describe(gray, mask):
    '''
    Returns the keypoints and the corresponding descriptors for the
    gray image.

            Parameters:
                    gray (np.array): Input image in grayscale.
                    mask (np.array): Mask to apply before the feature
                        extraction.

            Returns:
                    Tuple with the keypoins and their descriptors.
    '''

    (major, minor, _) = cv2.__version__.split(".")
    major = int(major)
    minor = int(minor)
    detector = None

    # verify if the opencv version is older than 4.4.
    # in the 4.4 version the SIFT algorithm was moved to
    # the main opencv repository.
    if (major == 4 and minor < 4) or major < 4:
        detector = cv2.xfeatures2d.SIFT_create()
    else:
        detector = cv2.SIFT_create()

    (kps, features) = detector.detectAndCompute(gray, mask)
    kps = np.float32([kp.pt for kp in kps])

    return (kps, features)


def match_keypoints(keypoints_a, keypoints_b, features_a, features_b,
                    ratio, reprojection_thresh):
    '''
    Function that searches the correspondences for the
    given descriptors (features_a and features_b) and with those
    correspondences, the homography matrix is calculated.

            Parameters:
                    keypoints_a (np.array): Keypoints of image A.
                    keypoints_b (np.array): Keypoints of image B.
                    features_a (np.array): Descriptors of image A
                    features_b (np.array): Descriptors of image B
                    ratio (float): Max distance between a possible correspondence.
                    reprojection_thresh (float): Reprojection inlier threshold for
                        the homography estimation

            Returns:
                    Tuple with the resulting matches, the homography H
                    and the estimation status.

            Raises:
                    RuntimeError: if the number of matching features is
                    less than the minimum required (4)
    '''

    # compute the raw matches and initialize the list of actual matches
    matcher = cv2.DescriptorMatcher_create("BruteForce")
    raw_matches = matcher.knnMatch(features_a, features_b, 2)
    matches = []

    # loop over the raw matches
    for m in raw_matches:
        # ensure the distance is within a certain ratio of each
        # other (i.e. Lowe's ratio test)
        if len(m) == 2 and m[0].distance < m[1].distance * ratio:
            matches.append((m[0].trainIdx, m[0].queryIdx))

    if len(matches) >= MIN_MATCHES:
        # construct the two sets of points
        ptsA = np.float32([keypoints_a[i] for (_, i) in matches])
        ptsB = np.float32([keypoints_b[i] for (i, _) in matches])

        # compute the homography between the two sets of points
        (H, status) = cv2.findHomography(ptsA, ptsB, cv2.RANSAC,
                                         reprojection_thresh)

        # return the matches along with the homograpy matrix
        # and status of each matched point
        return (matches, H, status)

    # otherwise, no homograpy could be computed
    raise RuntimeError("Not enough matching features")


def match_patterns(left, right, reprojection_thresh, rows, columns):
    '''
    Function that searches chessboard matches between input images.

            Parameters:
                    left (np.array): image A.
                    right (np.array): image B.
                    reprojection_thresh (float): Reprojection inlier
                        threshold for the homography estimation
                    rows (int): number of rows in chessboard pattern
                    columns (int): number of columns in chessboard pattern

            Returns:
                    Tuple with the resulting matches, the homography H,
                    the estimation status and the matching points.
            Raises:
                    RuntimeError: if no patterns are found in either image
    '''

    left_pattern_found, left_corners = cv2.findChessboardCorners(
        left, (columns, rows), cv2.CALIB_CB_FAST_CHECK)
    right_pattern_found, right_corners = cv2.findChessboardCorners(
        right, (columns, rows), cv2.CALIB_CB_FAST_CHECK)

    if (left_pattern_found and right_pattern_found and
            (len(left_corners) == len(right_corners))):

        left_corners = left_corners.reshape(-1, 2)
        right_corners = right_corners.reshape(-1, 2)
        (H, status) = cv2.findHomography(right_corners,
                                         left_corners, cv2.RANSAC, reprojection_thresh)
        matches = [(i, i) for i in range(len(left_corners))]

        return (matches, H, status, left_corners, right_corners)

    raise RuntimeError("Pattern not found")


def image_enhancement(img, sigma):
    '''
    Returns an image with some enhancement applied. Remove the
    noise of the input image img using a Gaussian filter and
    then convert it to grayscale.

            Parameters:
                    img (np.array): Input image img
                    sigma (float): Sigma value of the Gaussian filter.

            Returns:
                    Image
    '''

    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.fastNlMeansDenoising(gray, None, sigma)

    return gray


def remove_distortion(img, config, source):
    '''
    Returns an image with the distortion provoked by the camera lens removed.

            Parameters:
                    img (np.array): Image img.
                    config (string): Path to the JSON configuration file.
                    source (string): image to remove distortion, target or reference
            Returns:
                    Undistorted image.
    '''
    if source == 'target':
        (camera_matrix, distortion_parameters, _, _, _,
         _, _, _, _, _, undistort, _) = parse_JSON(config)
    else:
        (_, _, camera_matrix, distortion_parameters, _,
         _, _, _, _, _, _, undistort) = parse_JSON(config)

    if not undistort:
        return img

    # Read an example image and acquire its size
    h, w = img.shape[:2]

    # Generate new camera matrix from parameters
    new_camera_matrix, roi = cv2.getOptimalNewCameraMatrix(
        camera_matrix, distortion_parameters, (w, h), 0)

    # Generate look-up tables for remapping the camera image
    map_x, map_y = cv2.initUndistortRectifyMap(
        camera_matrix, distortion_parameters, None, new_camera_matrix, (w, h), M1TYPE)

    # Remap the original image to a new image
    newImg = cv2.remap(img, map_x, map_y, cv2.INTER_LINEAR)

    return newImg


def parse_JSON(filename):
    '''
    Returns the algorithm variables read from a JSON configuration file.

            Parameters:
                    filename (string): Path to the JSON configuration file.

            Returns:
                    Tuple with the read variables: (target_camera_matrix, target_distortion_parameters,
                                                    reference_camera_matrix, reference_distortion_parameters,
                                                    reprojection_error, match_ratio, sigma, overlap,
                                                    crop, fov, target_undistort, reference_undistort)
    '''

    with open(filename) as json_file:
        data = json.load(json_file)

        # load config variables
        if data['reprojError'] is not None:
            reprojection_error = float(data['reprojError'])
        else:
            reprojection_error = DEFAULT_REPROJ_ERROR
            print("Key reprojError not found in JSON configuration file. "
                  "Setting {} value".format(DEFAULT_REPROJ_ERROR))

        if data['matchRatio'] is not None:
            match_ratio = float(data['matchRatio'])
        else:
            match_ratio = DEFAULT_RATIO
            print("Key matchRatio not found in JSON configuration file. "
                  "Setting {} value".format(DEFAULT_RATIO))

        if data['sigma'] is not None:
            sigma = float(data['sigma'])
        else:
            sigma = DEFAULT_SIGMA
            print("Key sigma not found in JSON configuration file. "
                  "Setting {} value".format(DEFAULT_SIGMA))

        if data['fov'] is not None:
            fov = float(data['fov'])
        else:
            fov = DEFAULT_FOV
            print("Key fov not found in JSON configuration file. "
                  "Setting {} value".format(DEFAULT_FOV))

        if data['overlap'] is not None:
            overlap = float(data['overlap'])
        else:
            overlap = DEFAULT_OVERLAP
            print("Key overlap not found in JSON configuration file. "
                  "Setting {} value".format(DEFAULT_OVERLAP))

        if data['crop'] is not None:
            crop = float(data['crop'])
        else:
            crop = DEFAULT_CROP
            print("Key crop not found in JSON configuration file. "
                  "Setting {} value".format(DEFAULT_CROP))

        if data['targetUndistort'] is not None:
            target_undistort = bool(data['targetUndistort'])
        else:
            target_undistort = DEFAULT_UNDISTORT
            print("Key targetUndistort not found in JSON configuration file. "
                  "Setting {} value".format(DEFAULT_UNDISTORT))

        if data['referenceUndistort'] is not None:
            reference_undistort = bool(data['referenceUndistort'])
        else:
            reference_undistort = DEFAULT_UNDISTORT
            print(
                "Key referenceUndistort not found in JSON configuration file. "
                "Setting {} value".format(DEFAULT_UNDISTORT))

        # load target camera matrix and distortion coeficients
        (target_camera_matrix,
         target_distortion_parameters,
         target_undistort) = get_undistort_parameters(target_undistort,
                                                      data,
                                                      'targetCameraMatrix',
                                                      'targetDistortionParameters')

        # load reference camera matrix and distortion coeficients
        (reference_camera_matrix,
         reference_distortion_parameters,
         reference_undistort) = get_undistort_parameters(reference_undistort,
                                                         data,
                                                         'referenceCameraMatrix',
                                                         'referenceDistortionParameters')

        return (target_camera_matrix, target_distortion_parameters,
                reference_camera_matrix, reference_distortion_parameters,
                reprojection_error, match_ratio, sigma, overlap,
                crop, fov, target_undistort, reference_undistort)


def get_undistort_parameters(undistort, data, camera_matrix_key,
                             distortion_parameters_key):
    '''
    Returns the undistort related variables read from a JSON configuration file.

            Parameters:
                    undistort (bool): undistort flag.
                    data (json): JSON object from loading configuration file.
                    camera_matrix_key (string): JSON key for the camera matrix.
                    distortion_parameters_key (string): JSON key for the distortion parameters.

            Returns:
                    Tuple with the read variables: (camera_matrix, distortion_parameters, undistort)
    '''
    camera_matrix = None
    distortion_parameters = None
    if undistort:
        if data[camera_matrix_key] is None:
            return (camera_matrix, distortion_parameters, False)

        camera_matrix = np.zeros(HOMOGRAPHY_DIMENSION * HOMOGRAPHY_DIMENSION)
        for i, k in enumerate(data[camera_matrix_key]):
            camera_matrix[i] = k
        camera_matrix = camera_matrix.reshape(
            HOMOGRAPHY_DIMENSION, HOMOGRAPHY_DIMENSION)

        if data[distortion_parameters_key] is None:
            return (camera_matrix, distortion_parameters, False)

        distortion_parameters = np.zeros(
            [1, len(data[distortion_parameters_key])])
        for i, d in enumerate(data[distortion_parameters_key]):
            distortion_parameters[0, i] = d

    return (camera_matrix, distortion_parameters, undistort)


def get_homography(left, right, config, pattern, chessboard_dimensions):
    '''
    Returns the homography matrix along with the processed left and right
    images.

            Parameters:
                    left (np.array): Left input image.
                    right (np.array): Right input image.
                    config (string): Path to the JSON configuration file.
                    pattern (bool): Flag to indicate to look for pattern in the images.
                    chessboard_dimensions (tuple): Dimensions of the chessboard pattern.

            Returns:
                    Tuple with: (left, right, homography H)
    '''

    (_, _, _, _, reprojection_thresh, ratio, sigma,
     overlap, crop, fov, _, _) = parse_JSON(config)
    height, width = left.shape[:2]

    # crop
    crop_img = int((crop * left.shape[1]) / fov)
    if crop_img > 0:
        left = left[:, :-1 * crop_img]
        left = cv2.resize(left, (width, height),
                          interpolation=cv2.INTER_CUBIC)
        right = right[:, crop_img:]
        right = cv2.resize(right, (width, height),
                           interpolation=cv2.INTER_CUBIC)

    # Enhance images
    enhanced_left = image_enhancement(left, sigma)
    enhanced_right = image_enhancement(right, sigma)

    matches = H = status = keypoints_b = keypoints_a = []

    # Look for calibration pattern if option specified
    if pattern:
        try:
            (matches, H, status, keypoints_b, keypoints_a) = match_patterns(
                enhanced_left, enhanced_right, reprojection_thresh,
                chessboard_dimensions[0], chessboard_dimensions[1])
        except RuntimeError as err:
            exit(err)

    # Look for matching features
    else:
        # Mask
        overlap_img = int((overlap * left.shape[1]) / fov)
        left_mask = np.zeros(enhanced_left.shape, dtype=np.uint8)
        left_mask[0:, (-1 * overlap_img):] = 1
        right_mask = np.zeros(enhanced_right.shape, dtype=np.uint8)
        right_mask[0:, 0:overlap_img] = 1

        # Extract keypoints
        (keypoints_a, features_a) = detect_and_describe(
            enhanced_right, right_mask)
        (keypoints_b, features_b) = detect_and_describe(enhanced_left, left_mask)

        # Match features
        try:
            (matches, H, status) = match_keypoints(keypoints_a, keypoints_b,
                                                   features_a, features_b, ratio, reprojection_thresh)
        except RuntimeError as err:
            exit(err)

    # Draw matches
    vis = draw_matches(right, left, keypoints_a, keypoints_b, matches, status)
    cv2.imwrite('vis.jpg', vis)

    return (left, right, H)


def preprocess_image(img, scale_width, scale_height, config, source):
    '''
    Performs a preprocessing to the images.

            Parameters:
                    img (np.array): Input image.
                    scale_width (int): Scale width.
                    scale_height (int): Scale height.
                    config (string): path to config file.
                    source (string): image to preprocess, target or reference

            Returns:
                    (np.array) Processed image.
    '''

    img = remove_distortion(img, config, source)
    width = scale_width if scale_width > 0 else img.shape[1]
    height = scale_height if scale_height > 0 else img.shape[0]
    img = cv2.resize(img, (width, height), interpolation=cv2.INTER_CUBIC)
    return img


def left_fixed(config, reference_image, target_image, scale_width,
               scale_height, pattern, chessboard_dimensions, interactive):
    '''
    Performs the homography estimation between two images, leaving the left one
    fixed and transforming the right one to align them.

            Parameters:
                    config (string): Path to the JSON configuration file.
                    reference_image (string): Path to the reference image.
                    target_image (string): Path to the target image.
                    scale_width (int): Scale width dimension of the input images.
                    scale_height (int): Scale height dimension of the input images.
                    pattern (bool): Flag to indicate to look for pattern in the images.
                    chessboard_dimensions (tuple): Dimensions of the chessboard pattern.
                    interactive (bool): Flag to indicate to use interactive mode.

            Returns:
                    No return value
    '''

    # Load images
    reference = cv2.imread(reference_image)
    target = cv2.imread(target_image)

    # Preprocess images
    reference = preprocess_image(
        reference,
        scale_width,
        scale_height,
        config,
        'reference')
    target = preprocess_image(
        target,
        scale_width,
        scale_height,
        config,
        'target')

    (reference, target, homography) = get_homography(
        reference, target, config, pattern, chessboard_dimensions)

    result = apply_homography(reference, target, homography, "left", 1)

    if interactive:
        try:
            (result, homography) = curses.wrapper(
                interactive_homography_editing, homography, reference, target, "left")
        except Exception:
            print("Terminal too small to display interactive mode")

    cv2.imwrite('result.jpg', result)
    print("Created result.jpg image")

    print(
        """"matrix":{{"h00":{}, "h01":{}, "h02":{}, "h10":{}"""
        """, "h11":{}, "h12":{}, "h20":{}, "h21":{}, "h22":{}}}""".format(
            homography[0][0],
            homography[0][1],
            homography[0][2],
            homography[1][0],
            homography[1][1],
            homography[1][2],
            homography[2][0],
            homography[2][1],
            homography[2][2]))


def right_fixed(config, reference_image, target_image, scale_width,
                scale_height, pattern, chessboard_dimensions, interactive):
    '''
    Performs the homography estimation between two images, leaving the right one
    fixed and transforming the left one to align them.

            Parameters:
                    config (string): Path to the JSON configuration file.
                    reference_image (string): Path to the reference iamge.
                    target_image (string): Path to the target image.
                    scale_width (int): Scale width dimension of the input images.
                    scale_height (int): Scale height dimension of the input images.
                    pattern (bool): Flag to indicate to look for pattern in the images.
                    chessboard_dimensions (tuple): Dimensions of the chessboard pattern.
                    interactive (bool): Flag to indicate to use interactive mode.

            Returns:
                    No return value
    '''

    # Load images
    reference = cv2.imread(reference_image)
    target = cv2.imread(target_image)

    reference = preprocess_image(reference, scale_width, scale_height,
                                 config, 'reference')
    target = preprocess_image(target, scale_width, scale_height,
                              config, 'target')

    (target, reference, homography) = get_homography(
        target, reference, config, pattern, chessboard_dimensions)

    result = apply_homography(reference, target, homography, "right", 1)

    if interactive:
        try:
            (result, homography) = curses.wrapper(interactive_homography_editing,
                                           homography, reference, target, "right")
        except Exception:
            print("Terminal too small to display interactive mode")

    cv2.imwrite('result.jpg', result)
    print("Created result.jpg image")

    print(
        """"matrix":{{"h00":{}, "h01":{}, "h02":{}, "h10":{}"""
        """, "h11":{}, "h12":{}, "h20":{}, "h21":{}, "h22":{}}}""".format(
            homography[0][0],
            homography[0][1],
            homography[0][2],
            homography[1][0],
            homography[1][1],
            homography[1][2],
            homography[2][0],
            homography[2][1],
            homography[2][2]))


def interactive_homography_editing(stdscr, homography, reference,
                                   target, mode):
    '''
    Function that lunches the interactive command line interface for editing homographies.

            Parameters:
                    stdscr (Object): screen object from curses library for displaying.
                    homography (np.array): numpy array containing the homography to edit.
                    reference (np.array): reference image.
                    target (np.array): target image.
                    mode(string): mode of operation {"left", "right"}.

            Returns:
                    (np.array) modified homography
    '''

    # Setup
    stdscr.clear()
    curses.curs_set(0)
    cursor = [0, 0]
    temporary_homography = np.copy(homography)
    base = 10
    increment_scaling_exponent = 0  # used as base^(0) = 1
    key = ''
    editing = False
    min_digit = -6
    max_digit = 6
    image_scale = 0.4

    # Display title and instructions
    title = '''
 ################################################################
 #         Welcome to the interactive homography editor         #
 ################################################################
 Use the <h, j, k, l> keys to move around
    h=left, j=down, k=up, l= right

 Keys for using the editor:
    <i>: enter edit mode for a homography element.
    <w>: save  changes  when editing  an  element.
    <q>: discard changes when editing an  element.
    <q>: exit  the  program,  when  not  editing.

 IMPORTANT!
    Key events are captured from  the  image window, this  window
    is just for  displaying the matrix as a  guide,  so make sure
    the image window is in focus when moving, editing or exiting.

 ################################################################
'''
    stdscr.addstr(0, 0, title)

    # Apply base homography
    result = apply_homography(reference, target,
                              temporary_homography, mode, image_scale)

    # User interaction
    while True:
        display_matrix(stdscr, temporary_homography, 20, 14,
                       cursor, editing, increment_scaling_exponent)
        stdscr.refresh()
        cv2.imshow("Homography Result", result)
        key = cv2.waitKey(0)

        # CLI movement when editing
        if editing:
            if key == ord("k"):
                temporary_homography[cursor[0]][cursor[1]
                                                ] += base**(increment_scaling_exponent)
            elif key == ord("j"):
                temporary_homography[cursor[0]][cursor[1]
                                                ] -= base**(increment_scaling_exponent)
            if key == ord("l"):
                increment_scaling_exponent = max(
                    increment_scaling_exponent - 1, min_digit)
            elif key == ord("h"):
                increment_scaling_exponent = min(
                    increment_scaling_exponent + 1, max_digit)
            elif key == ord('q'):
                temporary_homography = np.copy(homography)
                editing = False
                increment_scaling_exponent = 0
            elif key == ord('w'):
                editing = False
                increment_scaling_exponent = 0
                homography = np.copy(temporary_homography)
            result = apply_homography(
                reference, target, temporary_homography, mode, image_scale)

        # CLI movement
        else:
            if key == ord("k"):
                cursor[0] = max(cursor[0] - 1, 0)
            elif key == ord("j"):
                cursor[0] = min(cursor[0] + 1, homography.shape[0] - 1)
            if key == ord("h"):
                cursor[1] = max(cursor[1] - 1, 0)
            elif key == ord("l"):
                cursor[1] = min(cursor[1] + 1, homography.shape[1] - 1)
            elif key == ord('i'):
                editing = True
            elif key == ord('q'):
                break

    return (result, temporary_homography)


def display_matrix(stdscr, matrix, pos_x, pos_y, focused_element,
                   editing, focused_digit, digits=10, spacing=4):
    '''
    Function that displays a matrix on a screen.
            Parameters:
                    stdscr (Object): screen object from curses library for displaying.
                    matrix (np.array): numpy array describing the matrix to display.
                    pos_x (int): horizontal position for displaying the matrix.
                    pos_y (int): vertical position for displaying the matrix.
                    focused_element (tuple): indices of the matrix element to highlight.
                    editing (bool): flag to indicate if editing mode is enabled.
                    focused_digit (int): index of the digit being edited.
                    digits (int): number of digits of the matrix to display.
                    spacing (int): horizontal spacing between matrix elements.

            Returns:
                    No return value
    '''
    rows, columns = matrix.shape

    # Write each matrix element on screen
    for row in range(rows):
        for column in range(columns):
            mode = 0

            # Highlight element if focused
            if (row == focused_element[0]) and (column == focused_element[1]):
                mode = curses.A_STANDOUT

            text = "%+.*f" % (digits, matrix[row, column])

            # Calculate element positions
            element_pos_x = row + pos_x
            element_pos_y = column * (spacing + digits) + pos_y

            # Highlight digit if editing
            if editing and mode != 0:
                if focused_digit >= 0:
                    focused_digit += 1

                point_index = text.index(".")
                highlight_point = point_index - focused_digit

                # Editing digits not showing, pad with zeros
                if highlight_point <= 0:
                    text = text[0] + \
                        ("0" * (abs(highlight_point) + 1)) + text[1:]
                    highlight_point = 1

                stdscr.addstr(element_pos_x, element_pos_y, text[:digits], 0)
                stdscr.addstr(element_pos_x, element_pos_y +
                              highlight_point, text[highlight_point], mode)

            # Print normal elements
            else:
                stdscr.addstr(element_pos_x, element_pos_y,
                              text[:digits], mode)


def apply_homography(reference, target, homography, mode, scale):
    '''
    Function that applies a homography to a couple of images.
            Parameters:
                    reference (np.array): numpy array containing the reference image.
                    target (np.array): numpy array containing the target image.
                    homography (np.array): numpy array containing the homography to apply.
                    mode (string): mode of operation {"left", "right"}.
                    scale (float): scaling factor for the result image.

            Returns:
                    No return value
    '''
    result = target
    output_shape = (reference.shape[1] + target.shape[1], target.shape[0])
    if mode == "left":
        # Normalize homography
        mapFinal = cv2.reg_MapProjec(homography)
        mapFinal.normalize()
        homography = mapFinal.getProjTr()

        # Apply homography
        result = cv2.warpPerspective(target, homography, output_shape)
        result[0:reference.shape[0], 0:reference.shape[1]] = reference
    elif mode == "right":
        # The computed homography is the homography of the right image based on the
        # left image, so we need to invert the matrix to get the homography of the
        # left image based on the right image
        homography = np.linalg.inv(homography)

        # Normalize homography
        mapFinal = cv2.reg_MapProjec(homography)
        mapFinal.normalize()
        homography = mapFinal.getProjTr()

        # The transformation of the right image is translation to the right
        reference_transformation = np.eye(3)
        reference_transformation[0][2] = reference.shape[1]

        # Now we compute the transformation of the left image based on the position
        # of the right image and the computed homography
        target_transformation = reference_transformation.dot(homography)

        # Stitch the images using the transformation matrices
        output_shape = (reference.shape[1] + target.shape[1], target.shape[0])
        result = cv2.warpPerspective(
            target, target_transformation, output_shape)
        cv2.warpPerspective(reference, reference_transformation,
                            output_shape, result,
                            borderMode=cv2.BORDER_TRANSPARENT)
    else:
        exit("Unknown operation mode")
    result = cv2.resize(result, (int(result.shape[1] * scale),
                                 int(reference.shape[0] * scale)))
    return result


def cmdline(argv):
    '''
    Function that parses the command line options before executing the algorithm

            Parameters:
                    config (list): List of command line arguments.

            Returns:
                    No return value
    '''

    prog = argv[0]
    parser = argparse.ArgumentParser(
        prog=prog,
        description='Tool for estimating the homography between two images.')

    subparsers = parser.add_subparsers(dest='command')
    subparsers.required = True

    def add_command(cmd, desc, example=None):
        epilog = 'Example: %s %s' % (
            prog, example) if example is not None else None
        return subparsers.add_parser(
            cmd, description=desc, help=desc, epilog=epilog)

    add_command(
        'left_fixed',
        'estimates the homography between two images, with the left one as reference.')
    add_command(
        'right_fixed',
        'estimates the homography between two images, with the right one as reference.')

    parser.add_argument(
        '--config',
        help='path of the configuration file',
        default='')
    parser.add_argument(
        '--reference_image',
        help='path of the reference image',
        default='',
        required=True)
    parser.add_argument(
        '--target_image',
        help='path of the target image',
        default='',
        required=True)
    parser.add_argument(
        '--scale_width',
        help='scale width dimension of the input images',
        type=int,
        default=0)
    parser.add_argument(
        '--scale_height',
        help='scale height dimension of the input images',
        type=int,
        default=0)
    parser.add_argument(
        '--chessboard_dimensions',
        help='dimensions of the calibration pattern to look for',
        metavar=("ROWS", "COLUMNS"),
        nargs=2,
        type=int,
        default=[6, 9])
    parser.add_argument(
        '--pattern',
        help='flag to indicate to look for a calibration pattern',
        action="store_true")
    parser.add_argument(
        '--interactive',
        help='flag to indicate to use interactive mode',
        action="store_true")

    args = parser.parse_args(argv[2:] + [argv[1]] if len(argv) > 1 else ['-h'])
    func = globals()[args.command]
    del args.command
    func(**vars(args))


if __name__ == "__main__":
    try:
        cmdline(sys.argv)
    except KeyboardInterrupt: 
        pass 
        