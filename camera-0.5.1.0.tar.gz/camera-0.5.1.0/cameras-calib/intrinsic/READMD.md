# Intrinsic calibration of camera 

The method is based on OpenCV's implementation for fisheye and pinhole camera. The lens used for this system should use pinhole model. 

The parameters are filled in "settings.json". The image is downsized is the camera's resolution is too high. 

The calibration results are saved into "output.json". 

The operations with calibrationTool.py include multiple steps: 

1. Capture images with chessboard 

    python calibrationTool.py -g -r 

2. Calibrate with saved images 

    python calibrationTool.py -c 

3. Preview the calibration result with the save images 

    python calibrationTool.py -b 

4. Preview the calibration result with real-time camera 

    python calibrationTool.py -t 

