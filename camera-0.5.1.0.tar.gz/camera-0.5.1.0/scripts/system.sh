#!/bin/bash

## The script is used to start and stop the camera system.
## before starting, check the downloaded updated version package 
## and auto install. 
## after starting, start a process to check updated version and/or 
## auto downlaod. 

## scripts dir 
SCRIPTS_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "SCRIPTS_DIR: ${SCRIPTS_DIR}" 

start () {
  echo "$(date +"%Y-%m-%d %T"): start system..."

  ## loading setup
  echo "" 
  echo "Loading setup from ${SCRIPTS_DIR}/setup.sh"
  . ${SCRIPTS_DIR}/setup.sh 
  echo ""

  if [ -z "${CAMERA_LOG}" ]; then 
    echo "CAMERA_LOG is not set!"
    CAMERA_LOG="${HOME}/camera_log"
  fi 
  echo "CAMERA_LOG: ${CAMERA_LOG}"
  mkdir -p ${CAMERA_LOG}

  UPDATE_LOG="${CAMERA_LOG}/update.log"
  echo "UPDATE_LOG: ${UPDATE_LOG}"

  ## auto update: install the updated version
  echo "AUTO_UPDATE: ${AUTO_UPDATE}"
  if [ -z "${AUTO_UPDATE}" ] || [ "${AUTO_UPDATE}" -ge 2 ] ; then 
    echo "Installing update"
    echo ". ${SCRIPTS_DIR}/update.sh install >> ${UPDATE_LOG} 2>&1"
    . ${SCRIPTS_DIR}/update.sh install >> ${UPDATE_LOG} 2>&1
  fi

  ## re-load setup from current version 
  echo ""
  echo "Re-loading setup from ${SCRIPTS_DIR}/setup.sh"
  . ${SCRIPTS_DIR}/setup.sh 
  echo ""

  if [ -z "${CAMERA_LOG}" ]; then 
    echo "CAMERA_LOG is not set!"
    CAMERA_LOG="${HOME}/camera_log"
  fi 
  echo "CAMERA_LOG: ${CAMERA_LOG}"
  mkdir -p ${CAMERA_LOG}

  if [ -z "${CAMERA_CONFIG}" ]; then 
    echo "CAMERA_CONFIG is not set!"
    CAMERA_CONFIG="$( cd "${SCRIPTS_DIR}/../config" && pwd )"
  fi 
  echo "CAMERA_CONFIG: ${CAMERA_CONFIG}"

  DOCKER_COMPOSE_ARGS="-f ${CAMERA_CONFIG}/docker-compose.yml"
  echo "RTSP_STREAMING: ${RTSP_STREAMING}"
  if [ "${RTSP_STREAMING}" = true]; then 
    DOCKER_COMPOSE_ARGS= "${DOCKER_COMPOSE_ARGS} -f ${CAMERA_CONFIG}/docker-compose-rtsp.yml"
  fi 
  echo "DOCKER_COMPOSE_ARGS: ${DOCKER_COMPOSE_ARGS}"

  ## start docker containers 
  echo "Stopping docker containers"
  echo "docker-compose ${DOCKER_COMPOSE_ARGS} down"
  docker-compose ${DOCKER_COMPOSE_ARGS} down
  echo "Starting docker containers"
  echo "docker-compose ${DOCKER_COMPOSE_ARGS} up -d"
  docker-compose ${DOCKER_COMPOSE_ARGS} up -d

  echo ""
  UPDATE_LOG="${CAMERA_LOG}/update.log"
  echo "UPDATE_LOG: ${UPDATE_LOG}"

  ## auto update: check/download the latest version
  echo "AUTO_UPDATE: ${AUTO_UPDATE}"
  if [ -z "${AUTO_UPDATE}" ] || [ "${AUTO_UPDATE}" -ge 2 ] ; then 
    echo "Downloading update"
    echo ". ${SCRIPTS_DIR}/update.sh download >> ${UPDATE_LOG} 2>&1 &"
    . ${SCRIPTS_DIR}/update.sh download >> ${UPDATE_LOG} 2>&1 &
  elif [ "${AUTO_UPDATE}" -ge 1 ] ; then 
    echo "Checking update"
    echo ". ${SCRIPTS_DIR}/update.sh check >> ${UPDATE_LOG} 2>&1 &"
    . ${SCRIPTS_DIR}/update.sh check >> ${UPDATE_LOG} 2>&1 &
  fi 

  echo ""
  echo "$(date +"%Y-%m-%d %T"): start system done!"
}

stop () {
  echo "$(date +"%Y-%m-%d %T"): stop system..."

  ## loading setup 
  echo ""
  echo "Re-load setup from ${SCRIPTS_DIR}/setup.sh"
  . ${SCRIPTS_DIR}/setup.sh 
  echo ""

  if [ -z "${CAMERA_CONFIG}" ]; then 
    echo "CAMERA_CONFIG is not set!"
    CAMERA_CONFIG="$( cd "${SCRIPTS_DIR}/../config" && pwd )"
  fi 
  echo "CAMERA_CONFIG: ${CAMERA_CONFIG}"

  DOCKER_COMPOSE_ARGS="-f ${CAMERA_CONFIG}/docker-compose.yml"
  echo "RTSP_STREAMING: ${RTSP_STREAMING}"
  if [ "${RTSP_STREAMING}" = true]; then 
    DOCKER_COMPOSE_ARGS= "${DOCKER_COMPOSE_ARGS} -f ${CAMERA_CONFIG}/docker-compose-rtsp.yml"
  fi 
  echo "DOCKER_COMPOSE_ARGS: ${DOCKER_COMPOSE_ARGS}"

  ## stop docker containers
  echo "Stopping docker containers"
  echo "docker-compose ${DOCKER_COMPOSE_ARGS} down"
  docker-compose ${DOCKER_COMPOSE_ARGS} down

  echo ""
  echo "$(date +"%Y-%m-%d %T"): stop system done!"
}

case "$1" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  *)
    echo "Usage: $0 {start|stop}"
    ;;
esac 
