#!/bin/bash

## scripts dir 
SCRIPTS_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "SCRIPTS_DIR: ${SCRIPTS_DIR}" 

## loading setup
echo "" 
echo "Loading setup from ${SCRIPTS_DIR}/setup.sh"
. ${SCRIPTS_DIR}/setup.sh 
echo ""

echo "CAMERA_ROS: ${CAMERA_ROS}"
. ${CAMERA_ROS}/setup.sh 

echo "CAMERA_LOG: ${CAMERA_LOG}"
mkdir -p ${CAMERA_LOG}

CAMERA_LOG="${CAMERA_LOG}/camera.log"
echo "CAMERA_LOG: ${CAMERA_LOG}" 

JANUS_LOG="${CAMERA_LOG}/janus.log"
echo "JANUS_LOG: ${JANUS_LOG}"

CAMERA_ARGS="respawn:=true"
echo "CAMERA_ARGS: ${CAMERA_ARGS}"

## use exec to force roslaunch as the foreground process 
echo "exec roslaunch camera camera.launch ${CAMERA_ARGS} >> ${CAMERA_LOG} 2>&1"
exec roslaunch camera camera.launch ${CAMERA_ARGS} >> ${CAMERA_LOG} 2>&1
