#!/bin/bash

## scripts dir 
SCRIPTS_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "SCRIPTS_DIR: ${SCRIPTS_DIR}" 

CAMERA_CONFIG="$( cd "${SCRIPTS_DIR}/../config" && pwd )"
echo "CAMERA_CONFIG: ${CAMERA_CONFIG}"

## wait for singal to shutdown/restart system 
SIGNAL_FILE=/var/run/system_signal
echo "SIGNAL_FILE: ${SIGNAL_FILE}"
echo "waiting" > ${SIGNAL_FILE}
while inotifywait -e close_write ${SIGNAL_FILE}; do 
  if grep shutdown ${SIGNAL_FILE} &>/dev/null; then
    echo "$(date +"%Y-%m-%d %T"): stop..."
    docker-compose -f ${CAMERA_CONFIG}/docker-compose.yml down
    echo "done" > ${SIGNAL_FILE}
    echo "$(date +"%Y-%m-%d %T"): shutdown..."
    poweroff -p
  elif grep reboot ${SIGNAL_FILE} &>/dev/null; then 
    echo "$(date +"%Y-%m-%d %T"): stop..."
    docker-compose -f ${CAMERA_CONFIG}/docker-compose.yml down
    echo "done" > ${SIGNAL_FILE}
    echo "$(date +"%Y-%m-%d %T"): reboot..."
    poweroff --reboot
  fi 
done
