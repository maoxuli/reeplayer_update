/*
 * Copyright (C) 2020-2021 RidgeRun, LLC (http://www.ridgerun.com)
 * All Rights Reserved.
 *
 * The contents of this software are proprietary and confidential to RidgeRun,
 * LLC.  No part of this program may be photocopied, reproduced or translated
 * into another programming language without prior written consent of
 * RidgeRun, LLC.  The user is free to modify the source code after obtaining
 * a software license from RidgeRun.  All source code changes must be provided
 * back to RidgeRun without any encumbrance.
 */

#ifndef __RR_STITCHER_RUNTIME_ERROR_H__
#define __RR_STITCHER_RUNTIME_ERROR_H__

namespace rr {
namespace stitcher {

enum RuntimeError {
  /**
   * Everything went okay
   */
  EOK,

  /**
   * A mandatory parameter was passed in as null
   */
  NULL_PARAMETER,

  /**
   * A mandatory parameter was passed with wrong configuration
   */
  INVALID_PARAMETER,

  /**
   * An invalid matrix detected
   */
  INVALID_MATRIX,

  /**
   * Wrong API usage detected
   */
  WRONG_API_USAGE,

  /**
   * Error using CUDA memory
   */
  CUDA_MEMORY_ERROR,

  /**
   * Error using CUDA kernel
   */
  CUDA_KERNEL_ERROR,

  /**
   * Functionality has not been implemented
   */
  NOT_IMPLEMENTED,

  /**
   * An unknown error has ocurred
   */
  UNKNOWN_ERROR,

  /**
   * The evaluation version is over
   */
  EVALUATION_END,

  /**
   * Invalid graph from homography dependencies
   */
  INVALID_HOMOGRAPHY_GRAPH,

  /**
   * No overlap between images
   */
  NO_OVERLAP,

  /**
   * Can't invert matrix
   */
  SINGULAR_MATRIX,

  /**
   * Homography was not refined
   */
  HOMOGRAPHY_NOT_REFINED,

  /**
   * Error in GPU
   */
  GPU_INTERNAL_ERROR,
};

} // namespace stitcher
} // namespace rr

#endif //__RR_STITCHER_RUNTIME_ERROR_H__
