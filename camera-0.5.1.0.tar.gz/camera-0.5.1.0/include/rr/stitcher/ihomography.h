/*
 * Copyright (C) 2020-2021 RidgeRun, LLC (http://www.ridgerun.com)
 * All Rights Reserved.
 *
 * The contents of this software are proprietary and confidential to RidgeRun,
 * LLC.  No part of this program may be photocopied, reproduced or translated
 * into another programming language without prior written consent of
 * RidgeRun, LLC.  The user is free to modify the source code after obtaining
 * a software license from RidgeRun.  All source code changes must be provided
 * back to RidgeRun without any encumbrance.
 */

#ifndef __RR_STITCHER_IHOMOGRAPHY_H__
#define __RR_STITCHER_IHOMOGRAPHY_H__

#include <rr/stitcher/matrix.h>
#include <rr/stitcher/rgba.h>
#include <rr/stitcher/runtime_error.h>
#include <rr/stitcher/transformation_node.h>

namespace rr {
namespace stitcher {

/**
 * Interface to abstract an homography
 */
template <typename T>
class IHomography {
 public:
  /**
   * \brief Applies a geometric transformation to the inputImage using the homography matrix.
   * \param srcImage Input image matrix.
   * \param H 3x3 homography matrix.
   * \param dstImage Output result matrix.
   * \return Error code resulting from the transformation.
   */
  virtual RuntimeError transform(const Matrix<T> &srcImage,
                                 const Matrix<float> &H, Matrix<T> &dstImage) = 0;

  /**
   * \brief Refines a homography for the given target and reference images.
   * \param targetImage Target image matrix.
   * \param referenceImage Reference image matrix.
   * \param H 3x3 homography matrix to be refined.
   * \param matchRatio ratio to use in Lowe ratio test.
   * \param minMatches minimum of matches to allow a homography computation.
   * \param kernelSize The size of the kernel to use in GaussianBlur.
   * \param kernelSigmas The standard deviations to use in GaussianBlur.
   * \return Error code resulting from the homography computation.
   */
  virtual RuntimeError refineHomography(const Matrix<T> &targetImage,
                                        const Matrix<T> &referenceImage,
                                        Matrix<float> &H,
                                        const float matchRatio,
                                        const uint minMatches,
                                        const int kernelSize[],
                                        const double kernelSigmas[]) = 0;

  /**
   * \brief Refines the homographies of the incoming images, for the given
   * transformations.
   * \param images matrices of the images.
   * \param transformations transformation structure which contains homography
   * matrices and image dependency information.
   * \param matchRatio ratio to use in Lowe ratio test.
   * \param minMatches minimum of matches to allow a homography computation.
   * \param kernelSize The size of the kernel to be used in GaussianBlur.
   * \param kernelSigmas The standard deviations to use in GaussianBlur.
   * \return Error code resulting from the homography computation.
   */
  virtual RuntimeError refineHomographies(const std::vector<Matrix<T>> &images,
                                          std::vector<TransformationNode> &transformations,
                                          const float matchRatio,
                                          const uint minMatches,
                                          const int kernelSize[],
                                          const double kernelSigmas[]) = 0;

  /**
   * \brief Default destructor
   */
  virtual ~IHomography () {};
};

} // namespace stitcher
} // namespace rr

#endif // __RR_STITCHER_IHOMOGRAPHY_H__
