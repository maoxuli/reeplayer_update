/*
 * Copyright (C) 2020 RidgeRun, LLC (http://www.ridgerun.com)
 * All Rights Reserved.
 *
 * The contents of this software are proprietary and confidential to RidgeRun,
 * LLC.  No part of this program may be photocopied, reproduced or translated
 * into another programming language without prior written consent of
 * RidgeRun, LLC.  The user is free to modify the source code after obtaining
 * a software license from RidgeRun.  All source code changes must be provided
 * back to RidgeRun without any encumbrance.
 */

#ifndef __RR_STITCHER_ICOMBINER_H__
#define __RR_STITCHER_ICOMBINER_H__

#include <vector>

#include <rr/stitcher/iblender.h>
#include <rr/stitcher/matrix.h>
#include <rr/stitcher/rgba.h>
#include <rr/stitcher/runtime_error.h>

namespace rr {
namespace stitcher {
/**
 * Interface to abstract a combiner
 */
template <typename T>
class ICombiner {
 public:

  /**
   * \brief Overlap 2 or more images by rendering the left (and center images) on
   * top of the right. A border width will be left uncopied to allow for blending.
   * The image list parameter contains input images as well as the output image,
   * the images are ordered ascendingly from left to right and the latest image
   * (right) on the list will be used as output image and will be the biggest.
   * \param Image list Vector matrix.
   * \param Border width added to the images
   * \return Error code resulting from the overlaping process.
   */
  virtual RuntimeError overlap(std::vector<Matrix<T>> &imageList,
                               unsigned int borderWidth) = 0;

  /**
   * \brief Default destructor
   */
  virtual ~ICombiner() {};
};

} // namespace stitcher
} // namespace rr

#endif // __RR_STITCHER_ICOMBINER_H__
