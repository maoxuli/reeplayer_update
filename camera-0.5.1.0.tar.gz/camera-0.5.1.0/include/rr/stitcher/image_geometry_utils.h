/*
 * Copyright (C) 2020-2021 RidgeRun, LLC (http://www.ridgerun.com)
 * All Rights Reserved.
 *
 * The contents of this software are proprietary and confidential to RidgeRun,
 * LLC.  No part of this program may be photocopied, reproduced or translated
 * into another programming language without prior written consent of
 * RidgeRun, LLC.  The user is free to modify the source code after obtaining
 * a software license from RidgeRun.  All source code changes must be provided
 * back to RidgeRun without any encumbrance.
 */

#ifndef __RR_STITCHER_IMAGE_GEOMETRY_UTILS_H__
#define __RR_STITCHER_IMAGE_GEOMETRY_UTILS_H__

#include <opencv2/core.hpp>

#include "rr/stitcher/matrix.h"
#include "rr/stitcher/runtime_error.h"

namespace rr {
namespace stitcher {

/**
 * \brief Checks if a given point is inside a rectangle of size width, height.
 *
 * \param point The point to be tested.
 * \param width The width of the rectangle.
 * \param height The height of the rectangle.
 * \return true if the point is inside the rectangle
 */
bool
pointInsideRectangle(const cv::Point2d point, const int width,
                     const int height);

/**
 * \brief Checks if a point is inside the space enclosed by a segment in both X
 * and Y axes.
 *
 * \param segmentStart The starting point of the segment.
 * \param segmentEnd The ending point of the segment.
 * \param point The point to be tested.
 * \return true if the point is in the segment's space.
 */
bool
pointInSegmentSpace(const cv::Point2d segmentStart,
                    const cv::Point2d segmentEnd,
                    const cv::Point2d point);

/**
 * \brief Compute the segments intersection.
 *
 * This code was modified from
 * https://answers.opencv.org/question/9511/how-to-find-the-intersection-point-of-two-lines/
 *
 * \param segmentStartA Starting point of the first segment.
 * \param segmentEndA Ending point of the first segment.
 * \param segmentStartB Starting point of the second segment.
 * \param segmentEndB Ending point of the second segment.
 * \param intersection Intersection point between the segments.
 * \return true if the segments intersect, false if not.
 */
bool
computeSegmentsIntersection(const cv::Point2d segmentStartA,
                            const cv::Point2d segmentEndA,
                            const cv::Point2d segmentStartB,
                            const cv::Point2d segmentEndB,
                            cv::Point2d &intersection);

/**
 * \brief Searches for the intersections of the segments formed from the given
 * corners, and appends those intersections in a vector.
 *
 * \param cornersA The corners of the first image.
 * \param cornersB corners of the second image.
 * \param intersections The vector where the found intersections will be added.
 * \return true if an intersection was found, false if not.
 */
bool
addSegmentsIntersectionsFromCorners(const std::vector<cv::Point2d> cornersA,
                                    const std::vector<cv::Point2d> cornersB,
                                    std::vector<cv::Point2d> &intersections);

/**
 * \brief Computes the rectangle the encloses all the given points, taking into
 * account the image limits denoted by xLimit and yLimit.
 *
 * \param points The points from where the rectangle will be calculated.
 * \param xLimit The limit of the image in the X axis.
 * \param yLimit The limit of the image in the Y axis.
 * \param rect The computed rectangle.
 * \return Error code related to the computations.
 */
RuntimeError
getRectFromPoints(const std::vector<cv::Point2d> points, const int xLimit,
                  const int yLimit, cv::Rect2i &rect);

/**
 * \brief Computes the overlapping areas of images with size (width, height),
 * which are related by a homography transformation matrix H.
 *
 * \param H The homography used to transform the target image points to the
 * reference's space.
 * \param width The width of the images.
 * \param height The height of the images.
 * \param targetOverlapRect The rectangle of the target's overlap.
 * \param referenceOverlapRect The rectangle of the reference's overlap.
 * \return Error code related to the computation of the overlap.
 */
RuntimeError
getOverlapRects(const Matrix<float> &H, const int width, const int height,
                cv::Rect2i &targetOverlapRect,
                cv::Rect2i &referenceOverlapRect);

} // namespace stitcher
} // namespace rr

#endif // __RR_STITCHER_IMAGE_GEOMETRY_UTILS_H__