/*
 * Copyright (C) 2020-2021 RidgeRun, LLC (http://www.ridgerun.com)
 * All Rights Reserved.
 *
 * The contents of this software are proprietary and confidential to RidgeRun,
 * LLC.  No part of this program may be photocopied, reproduced or translated
 * into another programming language without prior written consent of
 * RidgeRun, LLC.  The user is free to modify the source code after obtaining
 * a software license from RidgeRun.  All source code changes must be provided
 * back to RidgeRun without any encumbrance.
*/

#ifndef __RR_STITCHER_TRANSFORMATION_NODE_H__
#define __RR_STITCHER_TRANSFORMATION_NODE_H__

#include <vector>

#include <opencv2/core.hpp>

#include "rr/stitcher/matrix.h"
#include "rr/stitcher/runtime_error.h"

static constexpr int HOMOGRAPHY_DIMENSION = 3;
static constexpr int HOMOGRAPHY_SIZE = 9;
static constexpr int DEFAULT_QUEUE_SIZE = 1;

namespace rr {
namespace stitcher {

/**
 * \brief TransformationNode class that holds the information about its index,
 * parent's index, homography matrix, aboslute matrix and finally the
 * preprocessed matrix. Also, points its and children, in order to form a graph
 * of TransformationNode structures.
 */
class TransformationNode {
 public:
  /**
   * \brief Construct a new TransformationNode object
   * \param target_index index of the target image.
   * \param reference_index index of the reference image.
   * \param _homography_matrix homography matrix to transform the target image
   * based on the reference image.
   * \param width Image width of the homography
   * \param height Image height of the homography
   * \param queue_size The size of the queue in which the homographies are
   * accumulated to compute the mean homography.
   */
  TransformationNode(const int target_index, const int reference_index,
                     const Matrix<float> &_homography_matrix,
                     const int image_width = 0, const int image_height = 0,
                     const uint queue_size = DEFAULT_QUEUE_SIZE);

  /**
   * \brief Construct a new TransformationNode object
   * \param target_index Index of the target image.
   * \param reference_index Index of the reference image.
   * \param _homography_matrix Homography OpenCV matrix to transform the target
   * image based on the reference image.
   * \param queue_size The size of the queue in which the homographies are
   * accumulated to compute the mean homography.
   */
  TransformationNode(const int _target_index, const int _reference_index,
                     const cv::Mat &_homography_matrix,
                     const int image_width = 0, const int image_height = 0,
                     const uint queue_size = DEFAULT_QUEUE_SIZE);

  /**
   * \brief Get the target index of this node.
   * \return int The index of the target.
   */
  int getTargetIndex();

  /**
   * \brief Get the reference index of this node.
   *
   * \return int The index of the reference.
   */
  int getReferenceIndex();

  /**
   * \brief Scale the homography to target resolution 
   * \param width The image width of the resolution 
   * \param height The image height of the resolution 
   * \return RuntimeError The resulting error code.
   */
  RuntimeError scaleHomography(int width, int height);

  /**
   * \brief Get the homography matrix as an OpenCV Matrix.
   * \return cv::Mat_<float> The homography matrix.
   */
  cv::Mat_<float> getHomographyCVMatrix();

  /**
   * \brief Get the homography matrix.
   * \return Matrix<float> The homography matrix.
   */
  Matrix<float> getHomographyMatrix();

  /**
   * \brief Get the Absolute Homography Matrix object
   * \return cv::Mat_<float> The homography matrix.
   */
  cv::Mat_<float> getAbsoluteHomographyMatrix();

  /**
   * \brief Get the preprocessed matrix, which is a transformation matrix
   * that transforms the image based on the minimum (x, y) coordinate of the
   * complete image. This matrix is usefull to warp the image associated to this
   * node into the stitched image.
   * \return Matrix<float> the preprocessed matrix.
   */
  Matrix<float> getPreprocessedMatrix();

  /**
   * \brief Get the pointers to the children of this node.
   * \return std::vector<std::weak_ptr<TransformationNode>> The vector
   * containing the pointers to the children nodes.
   */
  std::vector<std::weak_ptr<TransformationNode>> getChildrenPtrs();

  /**
   * \brief Appends a homography into the queue, and pops a homography if it's
   * needed to maintain the queue_size.
   * \param matrix The homography matrix to push.
   * \return RuntimeError The resulting error code from pushing the matrix.
   */
  RuntimeError pushHomographyMatrix(const Matrix<float> &matrix);

  /**
   * \brief Appends a homography into the queue, and pops a homography if it's
   * needed to maintain the queue_size.
   * \param matrix The homography matrix to push.
   * \return RuntimeError The resulting error code from pushing the matrix.
   */
  RuntimeError pushHomographyMatrix(const cv::Mat_<float> &matrix);

  /**
   * \brief Set the absolute homography matrix of this node.
   * \param matrix The absolute homography matrix, which is a transformation
   * matrix that transforms the node image to its position based on the root
   * image of the tree.
   * \return RuntimeError The resulting error code.
   */
  RuntimeError setAbsoluteHomographyMatrix(const cv::Mat_<float> &matrix);

  /**
   * \brief Set the preprocessed homography matrix of this node.
   * \param matrix The preprocessed homography matrix to set.
   * \return RuntimeError The resulting error code.
   */
  RuntimeError setPreprocessedMatrix(const cv::Mat_<float> &matrix);

  /**
   * \brief Set the parent's pointer of this node.
   * \param parent_ptr The pointer to the parent.
   * \return RuntimeError The resulting error code.
   */
  RuntimeError setParentPtr(std::shared_ptr<TransformationNode> parent_ptr);

  /**
   * \brief Adds a child pointer.
   * \param child_ptr the child pointer.
   * \return RuntimeError The resulting error code.
   */
  RuntimeError addChildPtr(std::shared_ptr<TransformationNode> child_ptr);

  /**
   * \brief Set the children pointers.
   * \param children_ptrs The children pointers.
   * \return RuntimeError The resulting error code.
   */
  RuntimeError setChildrenPtrs(
    std::vector<std::weak_ptr<TransformationNode>> children_ptrs);

 private:
  /**
   * \brief The target index of this node.
   */
  int target_index;

  /**
   * \brief The reference index of this node.
   */
  int reference_index;

  /**
   * \brief The image width of the homography 
   */
  int image_width;

  /**
   * \brief The image height of the homography 
   */
  int image_height;

  /**
   * \brief The size of the homographies queue.
   */
  uint queue_size;

  /**
   * \brief The queue of homographies.
   */
  std::vector<cv::Mat_<float>> homographies_queue;

  /**
   * \brief The absolute homography matrix, which is a transformation that can
   * warp the image associated to this node based on the root image of the tree.
   */
  cv::Mat_<float> absolute_homography_matrix;

  /**
   * \brief The preprocessed transformation matrix, which is a transformation
   * that can warp the image associated to this node based on the minimum
   * coordinate (0, 0) of the stitched image.
   */
  Matrix<float> preprocessed_transformation_matrix;

  /**
   * \brief The pointer to the parent of this node.
   */
  std::shared_ptr<TransformationNode> parent_ptr;

  /**
   * \brief The pointers to the children of this node.
   */
  std::vector<std::weak_ptr<TransformationNode>> children_ptrs;

  /**
   * \brief Get the filtered homography from the queue of homographies.
   * \return cv::Mat_<float> The filtered homography.
   */
  cv::Mat_<float> getFilteredHomography();
};

} // namespace stitcher
} // namespace rr

#endif