/*
 * Copyright (C) 2020 RidgeRun, LLC (http://www.ridgerun.com)
 * All Rights Reserved.
 *
 * The contents of this software are proprietary and confidential to RidgeRun,
 * LLC.  No part of this program may be photocopied, reproduced or translated
 * into another programming language without prior written consent of
 * RidgeRun, LLC.  The user is free to modify the source code after obtaining
 * a software license from RidgeRun.  All source code changes must be provided
 * back to RidgeRun without any encumbrance.
*/

#ifndef __RR_STITCHER_HOMOGRAPHY_PREPROCESSING_H__
#define __RR_STITCHER_HOMOGRAPHY_PREPROCESSING_H__

#include <vector>

#include <opencv2/core.hpp>

#include "rr/stitcher/matrix.h"
#include "rr/stitcher/runtime_error.h"
#include "rr/stitcher/transformation_node.h"

namespace rr {
namespace stitcher {

/**
 * \brief HomographyPreprocessor class that preprocess the homographies
 *
 * The first goal of this class is to compute the so called absolute
 * homographies, which are homographies for each image as if they were
 * transformed from the root image. And the final goal is to compute
 * preprocessed transformations which are the transformations for each image as
 * if they were transformed from the (min_x, min_y) coordinate in the mosaic.
 *
 * The diagram below presents an example. The are four images where the root
 * image is (1). Then, there were three computed homographies: H01, H21 and H32.
 * Each image can be transformed using multiple references:
 *
 * - Parent image: The case of H01, H21 and H32, which are the homographies
 *                 needed to transform the images 0, 2 and 3 using as
 *                 reference next to it. This matrix is called simply homography
 *                 matrix in the code.
 *
 * - Root image:   Where the homographies represent the transformation of
*                  the image (0, 2 or 3) using as reference the root image.
 *                 This homographies are called in the code as absolute
 *                 homography_matrix. The diagram shows the reference point
 *                 as *A. As the images (0) and (2) are next to the root, the
 *                 absolute homography is the same as the simple homography,
 *                 but for the case of (3), its absolute homography is computed
 *                 as H21*H32.
 *
 * - Min coord:    Each image (including the root image) is transformed
 *                 using the min coordinate of the mosaic (*P in the diagram).
 *                 This matrix is the preprocessed transformation in the code.
 *
 * *P ____________*A______________________________________________
 * |              |                |              |               |
 * |      0       |    1 (root)    |      2       |       3       |
 * |______________|________________|______________|_______________|
 *
 */
class HomographyPreprocessor {
 public:

  /**
   * \brief HomographyPreprocessor constructor
   * \param img_width Images width
   * \param img_height Images height
   */
  HomographyPreprocessor( int img_width, int img_height);

  // TODO: update input parameter
  /**
   * \brief Applies preprocessing to the input homographies
   * \param homographies Vector of matrices representing the homographies
   * \param homography_dependencies Vector of arrays storing the related
   * elements for each homography
   * \param new_homographies Vector of output matrices
   * \return Error code resulting from the preprocessing
   */
  RuntimeError preprocessHomographies(
    std::vector<std::shared_ptr<TransformationNode>> homographies);

  /**
   * \brief Computes the size needed for the output image according to the input
   * size and the absolute homographies
   */
  void computeImageOutSize(int &totalWidth, int &totalHeight);

  /**
   * @brief Get the preprocessed transformation matrix for the given index
   *
   * The index refers to the index of the image to which the transformation
   * belongs
   *
   * @param index Index of the image/transformation in a sorted list
   */
  Matrix<float> getTransformation(int index);

  /**
   * \brief sorted_transformations store the incoming homographies, plus the root
   * node, sorted by index
   */
  std::vector<std::shared_ptr<TransformationNode>> sorted_transformations;

 private:
  /**
   * \brief Creates the nodes and the graph to preprocess the homographies
   * The images in a mosaic can be seen as a tree, where there's a root image
   * and N children whose position depdend on its parent's position. Also, each
   * child may have M children with the same dependencies. This dependencies
   * translate, mathematically, into homographies multiplication between
   * the child and its parent, which can make a chain with the parent's parent
   * homography. This is why we first create a tree, setting pointers from the
   * root node to spread the homography computations to the leaves of the tree
   * \param homographies Input matrices representing the homographies
   * \param homography_dependencies Vector of arrays storing the related
   * elements for each homography
   * \return Error code resulting from the initialization
   */
  RuntimeError buildHomographyDependencyTree(
    std::vector<std::shared_ptr<TransformationNode>> &homographies);

  /**
   * \brief Computes the absolute_homograpy_matrix for the input node and its
   * children
   * \param node Node to which the homography is going to be computed
   * \param parent_absolute_homography The node's parent absolute homography
   */
  RuntimeError computeAbsoluteHomographies(TransformationNode &node,
      cv::Mat_<float> parent_absolute_homography);

  /**
   * \brief Computes the minimum coordinate relative to the root element when
   * applying all the homographies
   */
  void computeMinCoordinate();

  /**
   * \brief Translates all the absolute homographies in the graph so that the
   * images are transformed from the min_x, min_y coordinate, instead of the
   * (0,0) coordinate of the root image. This is implemented to simplify the
   * image transformations, so then, when using a preprocessed transformation
   * the transformation is applied directly to the final image. This function
   * also assigns the translated homographies to the
   * preprocessed_transformation_matrix for every node, which is a Matrix
   * instance that can be used directly in transform operations
   */
  void translateAbsoluteHomographies();

  bool tree_initialized = false;
  int img_width = 0;
  int img_height = 0;
  float min_x = 0;
  float min_y = 0;
  std::shared_ptr<TransformationNode> root_ptr = nullptr;
};

} // namespace stitcher
} // namespace rr

#endif //__RR_STITCHER_HOMOGRAPHY_PREPROCESSOR_H__
