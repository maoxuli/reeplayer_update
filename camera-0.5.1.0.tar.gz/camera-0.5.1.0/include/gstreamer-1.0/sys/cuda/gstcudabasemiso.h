/*
 * Copyright (C) 2017 RidgeRun, LLC (http://www.ridgerun.com)
 * All Rights Reserved.
 *
 * The contents of this software are proprietary and confidential to RidgeRun,
 * LLC.  No part of this program may be photocopied, reproduced or translated
 * into another programming language without prior written consent of
 * RidgeRun, LLC.  The user is free to modify the source code after obtaining
 * a software license from RidgeRun.  All source code changes must be provided
 * back to RidgeRun without any encumbrance.
 */

#ifndef __GST_CUDA_BASE_MISO_H__
#define __GST_CUDA_BASE_MISO_H__

#include <gst/gst.h>
#include <gst/base/gstaggregator.h>
#include "sys/cuda/gstcuda.h"

G_BEGIN_DECLS

typedef struct _GstCudaBaseMiso GstCudaBaseMiso;
typedef struct _GstCudaBaseMisoClass GstCudaBaseMisoClass;

#define GST_CUDA_BASE_TYPE_MISO            (gst_cuda_base_miso_get_type())
#define GST_CUDA_BASE_MISO(obj)            (G_TYPE_CHECK_INSTANCE_CAST((obj),GST_CUDA_BASE_TYPE_MISO,GstCudaBaseMiso))
#define GST_CUDA_BASE_MISO_CAST(obj)       ((GstCudaBaseMiso *)(obj))
#define GST_CUDA_BASE_MISO_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST((klass),GST_CUDA_BASE_TYPE_MISO,GstCudaBaseMisoClass))
#define GST_CUDA_BASE_MISO_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),GST_CUDA_BASE_TYPE_MISO,GstCudaBaseMisoClass))
#define GST_CUDA_BASE_IS_MISO(obj)         (G_TYPE_CHECK_INSTANCE_TYPE((obj),GST_CUDA_BASE_TYPE_MISO))
#define GST_CUDA_BASE_IS_MISO_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE((klass),GST_CUDA_BASE_TYPE_MISO))


/**
 * GstCudaBaseMiso:
 *
 * The opaque #GstCudaBaseMiso data structure.
 */
struct _GstCudaBaseMiso
{
  /*< private > */
  GstAggregator parent;

};

/**
 * GstCudaBaseMisoClass:
 * @parent_class:   Element parent class
 * @start:          Optional.
 *                  Called when the element starts processing.
 *                  Allows opening external resources.
 * @stop:           Optional.
 *                  Called when the element stops processing.
 *                  Allows closing external resources.
 * @process:        Required if the element does not operate in-place.
 *                  Called when buffers are queued on all sinkpads. This
 *                  method is in charge to process the incoming
 *                  buffers and generate the outgoing buffer.
 *                  Transforms incoming buffers to one outgoing buffer.
 *                  The output buffer is a completely new buffer generated
 *                  from the incoming buffers, so these are not modified.
 *                  The method is allowed to change size/timestamp/duration
 *                  of the outgoing buffer.
 * @process_ip:     Required if the element operates in-place.
 *                  Called when buffers are queued on all sinkpads. This
 *                  method is in charge to process the incoming
 *                  buffers and generate the outgoing buffer.
 *                  Transforms in-place, the first incoming buffer of the
 *                  sinkpads input buffers list, by overwiting its data,
 *                  with the incoming buffers processing result.
 * @set_out_caps:   Required.
 *                  Allows the subclass to set the output caps, based
 *                  on a list of the input caps.
 *                  
 * Subclasses can override any of the available virtual methods or not, as
 * needed. At minimum @set_out_caps and either @process or @process_ip needs
 * to be implemented.
 * If the element can overwrite the input data with the results (data is of the
 * same type and quantity) it should provide @process_ip.
 */
struct _GstCudaBaseMisoClass
{
  GstAggregatorClass parent_class;

  /*< public > */
  /* virtual methods for subclasses */
    gboolean (*start) (GstCudaBaseMiso * cudabasemiso);

    gboolean (*stop) (GstCudaBaseMiso * cudabasemiso);

    GstFlowReturn (*process) (GstCudaBaseMiso * cudabasemiso,
      GSList * cuda_data_in_list, GstCudaData * out_data);

    GstFlowReturn (*process_frame) (GstCudaBaseMiso * cudabasemiso,
      GSList * cuda_frame_in_list, GstCudaFrame * out_data);

    GstFlowReturn (*process_ip) (GstCudaBaseMiso * cudabasemiso,
      GSList * cuda_data_in_list, GstCudaData * out_data);

    gboolean (*set_out_caps) (GstCudaBaseMiso * cudabasemiso,
      GList * in_caps_list, GstCaps ** outcaps);
};

/**
 * gst_cuda_base_miso_set_in_place:
 * 
 * A method that exposes a way to set the is_in_place property of GstCudaBaseMiso class.
 * This property controls the way GstCudaBaseMiso class handles and process the buffers.
 * If is_in_place=true, the GstCudaBaseMiso class will execute the process_ip() subclass
 * virtual method, otherwise will execute the process() subclass virtual method. If
 * this method isn't called by the subclass, the GstCudaBaseMiso will automatically set
 * is_in_place=true if process_ip() subclass virtual method is implemented, even if
 * process() subclass virtual method is also implemented together with process_ip().
 * If only process() subclass virtual method is implemented, the GstCudaBaseMiso class
 * will automatically set is_in_place=false.
 * 
 * @cudabasemiso: (in) (transfer none): A #GstCudaBaseMiso object.
 * @is_in_place: (in): The boolean value of is_in_place GstCudaBaseMiso class member.
 * 
 */
void gst_cuda_base_miso_set_in_place (GstCudaBaseMiso * cudabasemiso,
    gboolean is_in_place);

/**
 * gst_cuda_base_miso_get_is_in_place:
 * 
 * A method that exposes a way to get the is_in_place property value of GstCudaBaseMiso class.
 * This property controls the way GstCudaBaseMiso class handles and process the buffers.
 * If is_in_place=true, the GstCudaBaseMiso class will execute the process_ip() subclass
 * virtual method, otherwise will execute the process() subclass virtual method.
 * 
 * @cudabasemiso: (in) (transfer none): A #GstCudaBaseMiso object.
 * 
 * Returns: The boolean value of is_in_place GstCudaBaseMiso class member.
 * 
 */
gboolean gst_cuda_base_miso_get_is_in_place (GstCudaBaseMiso * cudabasemiso);

/**
 * gst_cuda_base_miso_set_sync:
 * 
 * A method that exposes a way to set sync property value of GstCudaBaseMiso
 * class. This property controls if the class has to sync the incoming buffers
 * by dropping the delayed ones based on the newest buffer, until all the
 * buffers are in sync.
 * 
 * @cudabasemiso: (in) (transfer none): A #GstCudaBaseMiso object.
 * @sync: (in): Wether or not to perform synchronization using the incoming
 * buffer timestamps.
 *
 */
void gst_cuda_base_miso_set_sync (GstCudaBaseMiso * cudabasemiso,
    gboolean sync);

/**
 * gst_cuda_base_miso_get_sync:
 * 
 * A method that exposes a way to get sync property value of GstCudaBaseMiso
 * class. This property controls if the class has to sync the incoming buffers
 * by dropping the delayed ones based on the newest buffer, until all the
 * buffers are in sync.
 * 
 * @cudabasemiso: (in) (transfer none): A #GstCudaBaseMiso object.
 * 
 * Returns: The boolean value of sync GstCudaBaseMiso class member.
 *
 */
gboolean gst_cuda_base_miso_get_sync (GstCudaBaseMiso * cudabasemiso);

GType gst_cuda_base_miso_get_type (void);

G_END_DECLS

#endif // __GST_CUDA_BASE_MISO_H__
