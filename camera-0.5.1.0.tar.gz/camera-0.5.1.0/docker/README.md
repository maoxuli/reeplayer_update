# Docker images for camera system 

1. System with ROS and OpenCV 

    reeplayer/camera:ros-opencv-ridgerun-l4t-base-r32.4.4 [default]
    reeplayer/camera:ros-opencv-4.4.0-l4t-base-r32.4.4

2. System with ROS 

    reeplayer/camera:ros-l4t-base-r32.4.4
    reeplayer/camera:ros-arm64v8-ubuntu-18.04 
    reeplayer/camera:ros-ubuntu-18.04

3. System with OpenCV 

    reeplayer/camera:opencv-ridgerun-l4t-base-r32.4.4
    reeplayer/camera:opencv-4.4.0-l4t-base-r32.4.4
    reeplayer/camera:opencv-4.4.0-ubuntu-18.04


# Run docker container

    docker_start.sh -i [image] -n [name]

    docker_into.sh -n [name]
    docker_stop.sh -n [name]
