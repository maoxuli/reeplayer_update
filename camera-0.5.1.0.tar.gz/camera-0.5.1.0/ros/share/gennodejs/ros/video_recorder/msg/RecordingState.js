// Auto-generated. Do not edit!

// (in-package video_recorder.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class RecordingState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.recording = null;
      this.filename = null;
      this.byte_size = null;
      this.time_size = null;
    }
    else {
      if (initObj.hasOwnProperty('recording')) {
        this.recording = initObj.recording
      }
      else {
        this.recording = false;
      }
      if (initObj.hasOwnProperty('filename')) {
        this.filename = initObj.filename
      }
      else {
        this.filename = '';
      }
      if (initObj.hasOwnProperty('byte_size')) {
        this.byte_size = initObj.byte_size
      }
      else {
        this.byte_size = 0;
      }
      if (initObj.hasOwnProperty('time_size')) {
        this.time_size = initObj.time_size
      }
      else {
        this.time_size = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RecordingState
    // Serialize message field [recording]
    bufferOffset = _serializer.bool(obj.recording, buffer, bufferOffset);
    // Serialize message field [filename]
    bufferOffset = _serializer.string(obj.filename, buffer, bufferOffset);
    // Serialize message field [byte_size]
    bufferOffset = _serializer.uint64(obj.byte_size, buffer, bufferOffset);
    // Serialize message field [time_size]
    bufferOffset = _serializer.uint64(obj.time_size, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RecordingState
    let len;
    let data = new RecordingState(null);
    // Deserialize message field [recording]
    data.recording = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [filename]
    data.filename = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [byte_size]
    data.byte_size = _deserializer.uint64(buffer, bufferOffset);
    // Deserialize message field [time_size]
    data.time_size = _deserializer.uint64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.filename.length;
    return length + 21;
  }

  static datatype() {
    // Returns string type for a message object
    return 'video_recorder/RecordingState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '81e85033b7a575b1554fa770c6f44127';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool recording 
    string filename
    uint64 byte_size
    uint64 time_size  
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RecordingState(null);
    if (msg.recording !== undefined) {
      resolved.recording = msg.recording;
    }
    else {
      resolved.recording = false
    }

    if (msg.filename !== undefined) {
      resolved.filename = msg.filename;
    }
    else {
      resolved.filename = ''
    }

    if (msg.byte_size !== undefined) {
      resolved.byte_size = msg.byte_size;
    }
    else {
      resolved.byte_size = 0
    }

    if (msg.time_size !== undefined) {
      resolved.time_size = msg.time_size;
    }
    else {
      resolved.time_size = 0
    }

    return resolved;
    }
};

module.exports = RecordingState;
