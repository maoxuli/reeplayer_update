#!/usr/bin/env python 

import json 
import threading
import queue  

import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse
from camera_ros import Footage  

from concurrent import futures
import grpc

# Footage service 
from camera_api import footage_service_pb2, footage_service_pb2_grpc


class FootageServiceServicer(footage_service_pb2_grpc.FootageServiceServicer): 
    """Footage management service 
    """
    def __init__(self): 
        super(FootageServiceServicer, self).__init__()
        ## connect to ROS service of footage manager node 
        self.footage = Footage() 


    def prepare(self, request, context):
        """Initiate a new footage  
        """
        rospy.loginfo("Footage prepare: {}".format(request.footage_id))
        try: 
            footage = self.footage.prepare_footage(request.footage_id)
            return footage_service_pb2.FootagePrepareResponse(footage_id=footage["footage_id"])
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def erase(self, request, context):
        """Erase a footage from filesystem 
        """
        rospy.loginfo("Footage erase: {}".format(request.footage_id))
        try: 
            self.footage.erase_footage(request.footage_id)
            return footage_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def set_meta(self, request, context):
        """Set meta data to footage
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')


    def remove_meta(self, request, context):
        """Remove meta data from footage 
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')


    def check_meta(self, request, context):
        """Check footage meta data 
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')


    def check_status(self, request, context):
        """Check status of footage, for a list of footage id or all footage 
        """
        rospy.loginfo("Footage check status for: {}".format(request.footages))
        try: 
            result = self.footage.footage_status(request.footages) 
            result = result if result is not None else {}
            statuses = {}
            for footage in result: 
                statuses[footage] = json.dumps(result[footage])
            rospy.loginfo("Footage check status result: {}".format(statuses))
            return footage_service_pb2.FootageStatusResponse(statuses=statuses)
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def watch_status(self, request, context):
        """Watch status of footage in stream, for a list of footage id or all footage 
        """
        rospy.loginfo("Footage watch status")
        ## hook on the rpc exit 
        stop_event = threading.Event()
        def on_rpc_done():
            rospy.loginfo("Footage watch status cancelling...")
            stop_event.set()   
        context.add_callback(on_rpc_done)

        ## queue for status from footage 
        status_queue = queue.Queue() 
        def on_status(statuses): 
            try: 
                footage_status = statuses["footage_status"]
                status_queue.put(footage_status)
                rospy.logdebug("queue: {}".format(footage_status))
            except Exception as e: 
                rospy.logwarn("Footage watch status error: " + str(e))

        rospy.loginfo("Subscribe status message") 
        self.footage.subscribe_status(on_status) 

        ## waiting until client cancel or exception
        rospy.loginfo("Footage watch status waiting on status")
        while not stop_event.is_set():
            try: 
                footage_status = status_queue.get(timeout = 2)
                statuses = {}
                for footage_id in footage_status: 
                    statuses[footage_id] = json.dumps(footage_status[footage_id])
                yield footage_service_pb2.FootageStatusResponse(statuses = statuses) 
                rospy.logdebug("yield: {}".format(statuses))
            except queue.Empty:
                rospy.logwarn("Footage watch status queue is empty, could be avoid by larger timeout.") 
                pass 
            except: 
                rospy.logwarn("What exception raised by yield when rpc is done?")
                pass 
        rospy.loginfo("Unsubscribe status message")
        self.footage.unsubscribe_status() 
        rospy.loginfo("Recording watch status done")


class FootageServiceServer(object):
    def __init__(self): 
        ## gRPC server  
        num_threads = 4 
        ropy.loginfo("Service thread pool size: {}".format(num_threads))
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=num_threads))

        rospy.loginfo("Serve footage service")
        footage_service_pb2_grpc.add_FootageServiceServicer_to_server(
            FootageServiceServicer(),
            server
        )
        
        service_port = 50051
        rospy.loginfo("Listen on port: {}".format(service_port))
        self.server.add_insecure_port("[::]:{}".format(service_port))
        self.server.start()


    def wait_for_shutdown(self): 
        self.server.stop( )
        self.server.wait_for_termination()


if __name__ == "__main__":
    rospy.init_node("footage_service_server", log_level=rospy.DEBUG)
    server = FootageServiceServer() 
    try:
        rospy.spin()
    except rospy.ROSInterruptException:
        print("ROS interrupted")
    server.wait_for_shutdown() 
    print("Service shutdown")
