#!/usr/bin/env python 

import json 
import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse
from camera_ros import Calibrator, Video  

from concurrent import futures
import grpc

# Stitchig service
from camera_api import stitching_service_pb2, stitching_service_pb2_grpc


class StitchingServiceServicer(stitching_service_pb2_grpc.StitchingServiceServicer):
    """Service to control and monitor the video stitching 
    """
    def __init__(self): 
        super(StitchingServiceServicer, self).__init__()
        ## connect to ROS service of video node 
        self.calibrator = Calibrator() 
        self.video = Video() 

    def update_calib(self, request, context):
        """Update the calibration
        """
        rospy.loginfo("Stitching update calib: {}".format(request.calib_file))
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def online_calib(self, request, context):
        """Online calibration 
        """
        rospy.loginfo("Stitching online calib")
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def snapshot(self, request, context):
        """Snapshot of the stitching output 
        """
        rospy.loginfo("Stitching snapshot: {}".format(request.image_scale))
        try: 
            result = self.video.stitching_snapshot() 
            image_data = result["image_data"] 
            return stitching_service_pb2.camera__api_dot_snapshot__pb2.SnapshotResponse(image_data=image_data)
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


class StitchingServiceServer(object):
    def __init__(self): 
        ## gRPC server  
        num_threads = 4 
        ropy.loginfo("Service thread pool size: {}".format(num_threads))
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=num_threads))

        rospy.loginfo("Serve stitching service")
        stitching_service_pb2_grpc.add_StitchingServiceServicer_to_server(
            StitchingServiceServicer(),
            server
        )
        
        service_port = 50051
        rospy.loginfo("Listen on port: {}".format(service_port))
        self.server.add_insecure_port("[::]:{}".format(service_port))
        self.server.start()


    def wait_for_shutdown(self): 
        self.server.stop( )
        self.server.wait_for_termination()


if __name__ == "__main__":
    rospy.init_node("stitching_service_server", log_level=rospy.DEBUG)
    server = StitchingServiceServer() 
    try:
        rospy.spin()
    except rospy.ROSInterruptException:
        print("ROS interrupted")
    server.wait_for_shutdown() 
    print("Service shutdown")
