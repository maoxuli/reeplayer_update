#!/usr/bin/env python 

import json 
import threading
import queue  

import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse
from camera_ros import Footage, Video  

from concurrent import futures
import grpc

# Recording service 
from camera_api import recording_service_pb2, recording_service_pb2_grpc


class RecordingServiceServicer(recording_service_pb2_grpc.RecordingServiceServicer):
    """Service to control and monitor footage recording 
    """
    def __init__(self): 
        super(RecordingServiceServicer, self).__init__()
        ## connect to ROS service of camera and recorder node 
        self.footage = Footage() 
        self.video = Video() 


    def start(self, request, context):
        """Start recording 
        """
        rospy.logdebug("Recording start: {}".format(request.footage_id)) 
        try: 
            footage = self.footage.prepare_footage(request.footage_id) 
            self.video.start_recording(footage)
            return recording_service_pb2.RecordingStartResponse(footage_id = footage["footage_id"])
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def pause(self, request, context):
        """Pause recording 
        """
        rospy.loginfo("Recording pause") 
        try: 
            self.video.pause_recording()
            return recording_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def resume(self, request, context):
        """Resume the paused recording 
        """
        rospy.loginfo("Recording resume") 
        try: 
            self.video.resume_recording()
            return recording_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def stop(self, request, context):
        """Stop recording 
        """
        rospy.loginfo("Recording stop") 
        try: 
            self.video.stop_recording()
            return recording_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def check_status(self, request, context):
        """Check the status of recording 
        """
        rospy.loginfo("Recording check status")
        try: 
            status = self.video.recording_status() 
            return recording_service_pb2.RecordingStatusResponse(status = json.dumps(status))
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def watch_status(self, request, context):
        """Watch the status of recording, in stream 
        """
        rospy.loginfo("Recording watch status")
        ## hook on the rpc exit 
        stop_event = threading.Event()
        def on_rpc_done():
            rospy.loginfo("Recording watch status cancelling...")
            stop_event.set()   
        context.add_callback(on_rpc_done)

        ## queue for status from video 
        status_queue = queue.Queue() 
        def on_status(statuses): 
            try: 
                recording_status = statuses["recording_status"]
                status_queue.put(recording_status)
                rospy.logdebug("queue: {}".format(recording_status))
            except Exception as e: 
                rospy.logwarn("Recording watch status error: " + str(e))

        rospy.loginfo("Subscribe status message") 
        self.video.subscribe_status(on_status) 

        ## waiting until client cancel or exception
        rospy.loginfo("Recording watch status waiting on status")
        while not stop_event.is_set():
            try: 
                status = status_queue.get(timeout = 2) 
                yield recording_service_pb2.RecordingStatusResponse(status=json.dumps(status)) 
                rospy.logdebug("yield: {}".format(status))
            except queue.Empty:
                rospy.logwarn("Recording watch status queue is empty, could be avoid by larger timeout.") 
                pass 
            except: 
                rospy.logwarn("What exception raised by yield when rpc is done?")
                pass 
        rospy.loginfo("Unsubscribe status message")
        self.video.unsubscribe_status() 
        rospy.loginfo("Recording watch status done")


    def snapshot(self, request, context):
        """Snapshot of the video for recording
        """
        rospy.loginfo("Recording snapshot: {}".format(request.image_scale))
        try: 
            images = self.video.recording_snapshot(request.image_scale) 
            return recording_service_pb2.camera__api_dot_snapshot__pb2.SnapshotResponse(images=images)
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


class RecordingServiceServer(object):
    def __init__(self): 
        ## gRPC server  
        num_threads = 4 
        ropy.loginfo("Service thread pool size: {}".format(num_threads))
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=num_threads))

        rospy.loginfo("Serve recording service")
        recording_service_pb2_grpc.add_RecordingServiceServicer_to_server(
            RecordingServiceServicer(),
            server
        )
        
        service_port = 50051
        rospy.loginfo("Listen on port: {}".format(service_port))
        self.server.add_insecure_port("[::]:{}".format(service_port))
        self.server.start()


    def wait_for_shutdown(self): 
        self.server.stop( )
        self.server.wait_for_termination()


if __name__ == "__main__":
    rospy.init_node("recording_service_server", log_level=rospy.DEBUG)
    server = RecordingServiceServer() 
    try:
        rospy.spin()
    except rospy.ROSInterruptException:
        print("ROS interrupted")
    server.wait_for_shutdown() 
    print("Service shutdown")
