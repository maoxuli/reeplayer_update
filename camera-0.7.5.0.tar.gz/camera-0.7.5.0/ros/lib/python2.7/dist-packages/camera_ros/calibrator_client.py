import json 
import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService 
from ros_client import _call_ros_service


class Calibrator(object):
    def __init__(self):
        self.status_topic = "calibrator_status" 
        self.status_sub = None 

        calibrator_rpc_service = "calibrator_rpc"
        rospy.loginfo("Connecting to ROS service: {}".format(calibrator_rpc_service))
        self.rpc_service = rospy.ServiceProxy(calibrator_rpc_service, JsonService)
        # rospy.loginfo("Waiting for ROS service: {}".format(calibrator_rpc_service))
        # rospy.wait_for_service(calibrator_rpc_service)
        # rospy.loginfo("Connected to ROS service: {}".format(calibrator_rpc_service))
 

    def subscribe_status(self, status_callback): 
        def msg_callback(msg): 
            try: 
                rospy.logdebug(msg)
                notifications = json.loads(msg.data)
                statuses = {}
                for notification in notifications:
                    statuses[notification["method"]] = notification["params"] 
                status_callback(statuses)
            except Exception as e: 
                rospy.logwarn("Calibrator status topic callback error: " + str(e))
                
        rospy.loginfo("Subscribe ROS topic: {}".format(self.status_topic))
        self.status_sub = rospy.Subscriber(self.status_topic, JsonString, msg_callback) 


    def unsubscribe_status(self): 
        if self.status_sub: 
            rospy.loginfo("Unsubscribe ROS topic: {}".format(self.status_topic))
            self.status_sub.unregister()


    def online_calib(self): 
        pass 
