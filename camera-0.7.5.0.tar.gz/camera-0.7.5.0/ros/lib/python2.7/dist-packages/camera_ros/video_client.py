import json 
import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService 
from ros_client import _call_ros_service


class Video(object):
    def __init__(self):
        self.status_topic = "video_status" 
        self.status_sub = None 

        video_rpc_service = "video_rpc"
        rospy.loginfo("Connecting to ROS service: {}".format(video_rpc_service))
        self.rpc_service = rospy.ServiceProxy(video_rpc_service, JsonService)
        # rospy.loginfo("Waiting for ROS service: {}".format(video_rpc_service))
        # rospy.wait_for_service(video_rpc_service)
        # rospy.loginfo("Connected to ROS service: {}".format(video_rpc_service))


    def subscribe_status(self, status_callback): 
        def msg_callback(msg): 
            try: 
                rospy.logdebug(msg)
                notifications = json.loads(msg.data)
                statuses = {}
                for notification in notifications:
                    statuses[notification["method"]] = notification["params"] 
                status_callback(statuses)
            except Exception as e: 
                rospy.logwarn("Video status topic callback error: " + str(e))
                
        rospy.loginfo("Subscribe ROS topic: {}".format(self.status_topic))
        self.status_sub = rospy.Subscriber(self.status_topic, JsonString, msg_callback) 


    def unsubscribe_status(self): 
        if self.status_sub: 
            rospy.loginfo("Unsubscribe ROS topic: {}".format(self.status_topic))
            self.status_sub.unregister()


    def enable_video(self, mode): 
        return _call_ros_service(self.rpc_service, "enable_video", mode)


    def disable_recording(self): 
        return _call_ros_service(self.rpc_service, "diable_recording")


    def video_status(self):
        return _call_ros_service(self.rpc_service, "video_status")   


    def start_recording(self, footage = None):
        return _call_ros_service(self.rpc_service, "start_recording", footage)


    def stop_recording(self):
        return _call_ros_service(self.rpc_service, "stop_recording") 


    def pause_recording(self):
        return _call_ros_service(self.rpc_service, "pause_recording")  


    def resume_recording(self):
        return _call_ros_service(self.rpc_service, "resume_recording")  


    def recording_status(self):
        return _call_ros_service(self.rpc_service, "recording_status")   


    def start_streaming(self):
        pass 


    def stop_streaming(self):
        pass 


    def pause_streaming(self):
        pass 


    def resume_streaming(self):
        pass 


    def streaming_status(self): 
        pass 


    def capture_snapshot(self): 
        pass 


    def stitching_snapshot(self): 
        pass 


    def recording_snapshot(self, image_scale = 0): 
        return _call_ros_service(self.rpc_service, "recording_snapshot", {"image_scale": image_scale})    


    def streaming_snapshot(self): 
        pass 
