import json 
import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService 
from ros_client import _call_ros_service


class Camera(object):
    def __init__(self):
        self.status_topic = "camera_status"
        self.status_sub = None 

        camera_rpc_service = "camera_rpc"
        rospy.loginfo("Connecting to ROS service: {}".format(camera_rpc_service))
        self.rpc_service = rospy.ServiceProxy(camera_rpc_service, JsonService)
        # rospy.loginfo("Waiting for ROS service: {}".format(camera_rpc_service))
        # rospy.wait_for_service(camera_rpc_service)
        # rospy.loginfo("Connected to ROS service: {}".format(camera_rpc_service))


    def subscribe_status(self, status_callback): 
        def msg_callback(msg): 
            try: 
                rospy.logdebug(msg)
                notifications = json.loads(msg.data)
                statuses = {}
                for notification in notifications:
                    statuses[notification["method"]] = notification["params"] 
                status_callback(statuses)
            except Exception as e: 
                rospy.logwarn("Camera status topic callback error: " + str(e))
                
        rospy.loginfo("Subscribe ROS topic: {}".format(self.status_topic))
        self.status_sub = rospy.Subscriber(self.status_topic, JsonString, msg_callback) 


    def unsubscribe_status(self): 
        if self.status_sub: 
            rospy.loginfo("Unsubscribe ROS topic: {}".format(self.status_topic))
            self.status_sub.unregister()


    def shutdown_system(self): 
        return _call_ros_service(self.rpc_service, "shutdown_system")


    def restart_system(self): 
        return _call_ros_service(self.rpc_service, "restart_system")


    def system_status(self, systems): 
        return _call_ros_service(self.rpc_service, "system_status", systems)
