import json 
import rospy
from jsonrpc import jsonrpc_wrap_request, jsonrpc_validate_request


def _call_ros_service(service, method, params = None):
    request = jsonrpc_wrap_request(method, params)
    if not jsonrpc_validate_request(request): 
        raise Exception("Invalid JSON-RPC request: {}".format(request))
    try: 
        rospy.logdebug("JSON-RPC request: {}".format(request))
        response = json.loads(service(json.dumps(request)).data)
        # rospy.logdebug("JSON-RPC response: {}".format(response))
        return response["result"] if "result" in response else None 
    except rospy.ServiceException as e:
        raise Exception("Call ROS service failed: {}".format(e))
    except ValueError as e: 
        raise Exception("Invalid JSON value: {}".format(e))
