#ifndef __LIVE_CALIBRATOR_H__
#define __LIVE_CALIBRATOR_H__

#include <string>
#include <map>
#include <vector>
#include <deque>
#include <memory>
#include <atomic>
#include <thread>
#include <mutex>
#include <condition_variable>

#include <opencv2/core.hpp>
#include <opencv2/core/cuda.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/cudafeatures2d.hpp>
#include <opencv2/xfeatures2d.hpp>
#include <opencv2/xfeatures2d/cuda.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/stitching/detail/camera.hpp>

#include <videostitching/fast_matchers.h>
#include <videostitching/fast_estimators.h>
#include <videostitching/fast_warpers.h>

namespace videostitching {

class Undistorter 
{
public: 
    Undistorter(int interpolation = cv::INTER_LINEAR, 
                int border_mode = cv::BORDER_CONSTANT, 
                cv::Scalar border_value = cv::Scalar()); 

    cv::Rect prepare(const cv::Size& src_size, cv::InputArray K, cv::InputArray D, double alpha = 1.0);
    void warp(cv::InputArray src, cv::OutputArray dst); 

private: 
    int _interpolation; 
    int _border_mode; 
    cv::Scalar _border_value; 

    cv::Mat _map1, _map2;
    cv::Rect _dst_roi;
};

class LiveCalibrator
{
public: 
    struct Settings 
    {
        std::string camera_info;
        std::string camera_params; 
        float detect_scale = -1; // down scale for input images (0,1) 
        std::string features_type = "surf"; // orb | surf | sift
        int min_matches = 5; // min matches good for estimation 
        float hessian_threshold = 200; // for SURF
        float match_conf = 0.5f; // for SURF 
        float ransac_threshold = 3; // ransac reproj threshold [1,10]
        std::string ba_cost_func = "reproj";  // reproj | ray | no 
        float ba_conf_thresh = 1.0f;
        std::string ba_refine_mask = "xxxxx";
        bool do_wave_correct = true;
        std::string warp_type = "spherical"; // shperical | cylindrical | plane

        explicit Settings(const std::string& config = ""); 
        std::string to_string() const; 
    }; 

    LiveCalibrator(const Settings& settings = Settings());
    ~LiveCalibrator(); 

    // must be called before other operations 
    bool prepare(const cv::Size& input_size); 
    
    // By default the calibrator load and save (update) the calibration 
    // from and to the calib file given in the settings.
    // But it also support to load and save the calibration from and to 
    // different files passed as parameters, by this way, the applicaiton 
    // can load and evaluate the saved calibrations 
    bool load(const std::string& cameras_calib = ""); 
    bool save(const std::string& cameras_calib = "");

    // reset internal state and the calibration (generated or loaded)
    void reset(); 

    // do a stitching with current calibration 
    // if no calibration (generated or loaded), output the raw image pairs
    // this is useful to preview the images 
    bool evaluate(const std::vector<cv::Mat>& images, cv::Mat& output); 

    // The detect method always add the detection result to the features list 
    // remove must be called explicitly to discard the current detection 
    bool add_frame(const std::vector<cv::Mat>& images, const std::string& id);
    bool remove_frame(const std::string& id); 

    std::vector<std::string> frames(); 
    bool visual_matches(const std::string& id, cv::Mat& output);
    cv::Mat visual_coverage(const std::string& id = "");

    // estimate the transform with the all features matching 
    // visualize the really used matching 
    bool estimate(cv::Mat& visual_matches);

private: 
    const int _num_cameras;
    Settings _settings; 
    
    cv::Size _input_size; 
    cv::Size _detect_size; // scaled down from input size 
    std::vector<cv::cuda::GpuMat> _detect_masks; 
    std::vector<cv::cuda::GpuMat> _detect_images; 
    std::vector<cv::Mat> _resized_images; 
    std::vector<cv::Mat> _gray_images; 

    // undistortion before matchig 
    void prepare_undistortion(); 
    cv::Ptr<Undistorter> _undistorter; 
    cv::Rect _undistorted_roi; 
    std::vector<cv::Mat> _undistorted_images; 

    // projection warping 
    void prepare_warping();
    std::vector<cv::Ptr<ProjectWarper> > _warpers;
    std::vector<cv::Rect> _warped_rects;
    std::vector<cv::Point> _warped_corners; 
    std::vector<cv::Size> _warped_sizes; 
    std::vector<cv::Rect> _crop_rects; 
    std::vector<cv::Rect> _output_rects;
    std::vector<cv::cuda::GpuMat> _input_images;
    std::vector<cv::cuda::GpuMat> _warped_masks;
    std::vector<cv::cuda::GpuMat> _warped_images;
    cv::Size _output_size;
    cv::cuda::GpuMat _output_image; 

    // calibration, loaded or generated 
    std::vector<cv::detail::CameraParams> _cameras; 
    cv::Size _calib_size;    

    // features finding and matching 
    cv::Ptr<cv::cuda::SURF_CUDA> _finder; 
    cv::Ptr<FastMatcher> _matcher; 

    // transform estimator 
    std::shared_ptr<Estimator> _estimator;
    std::shared_ptr<BundleAdjusterBase> _adjuster; 

    bool matches_detection(const std::vector<cv::cuda::GpuMat>& images, 
                           const std::vector<cv::cuda::GpuMat>& masks, 
                           std::vector<ImageFeatures>& features, 
                           MatchesInfo& matches_info); 

    void matches_fusion(const std::vector<ImageFeatures>& features, 
                        const MatchesInfo& matches_info, 
                        std::vector<ImageFeatures>& all_features, 
                        MatchesInfo& all_matches_info, 
                        std::set<std::pair<int,int> >& all_matches_set);

    bool estimate_transform(std::vector<ImageFeatures>& features, 
                            MatchesInfo& matches_info, 
                            std::vector<cv::detail::CameraParams>& cameras); 

    struct Frame {
        std::vector<ImageFeatures> features; 
        MatchesInfo matches_info;
        cv::Mat visual_matches; 

        Frame() {}
        Frame(const std::vector<ImageFeatures>& _features, 
              const MatchesInfo& _matches_info, 
              const cv::Mat& _visual_matches) 
        : features(_features)
        , matches_info(_matches_info)
        {
            _visual_matches.copyTo(visual_matches); 
        } 
    }; 

    std::map<std::string, Frame> _frames; 
}; 

} // namespace videostitching 

#endif 
