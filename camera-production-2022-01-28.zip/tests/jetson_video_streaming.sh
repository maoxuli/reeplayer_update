#!/bin/bash

VIDEO_FILE=example.mp4
TARGET_HOST=192.168.1.169
FLIP_METHOD=0

function print_help { 
  echo "Usage: $0 [-i ${VIDEO_FILE}] [-o ${TARGET_HOST}] [-r ${FLIP_METHOD}] [-h]"
  echo "-i: input video file"
  echo "-o: streaming target IP" 
  echo "-r: rotation of input image:" 
  echo -e "\t 0: no rotation (default)" 
  echo -e "\t 1: counterclockwise - 90 degrees"
  echo -e "\t 2: rotate - 180 degrees"
  echo -e "\t 3: clockwise - 90 degrees"
  echo -e "\t 4: horizontal flip"
  echo -e "\t 5: upper right diagonal flip"
  echo -e "\t 6: vertical flip"
  echo -e "\t 7: upper-left diagonal"
  echo "-h: help"
} 

while getopts ":i:o:r:h" opt; do
  case $opt in
    i) VIDEO_FILE="$OPTARG";;
    o) TARGET_HOST="$OPTARG";;
    r) FLIP_METHOD="$OPTARG";;
    \? | h | *) print_help; exit 0;;
  esac
done

echo "VIDEO_FILE: ${VIDEO_FILE}"
echo "TARGET_HOST: ${TARGET_HOST}" 
echo "FLIP_METHOD: ${FLIP_METHOD}"

while true; do  
  gst-launch-1.0 filesrc location=${VIDEO_FILE} ! qtdemux ! queue ! h264parse ! nvv4l2decoder ! nvvidconv flip-method=${FLIP_METHOD} ! queue ! nvv4l2h264enc bitrate=8000000 insert-sps-pps=true ! rtph264pay mtu=1400 ! udpsink host=${TARGET_HOST} port=5000 sync=false async=false -e
done 
