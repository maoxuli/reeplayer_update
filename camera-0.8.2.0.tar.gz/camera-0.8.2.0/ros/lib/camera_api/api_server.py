#!/usr/bin/env python

import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse

from concurrent import futures
import grpc

# Health service
from grpc_health.v1.health import HealthServicer
from grpc_health.v1 import health_pb2, health_pb2_grpc

# System service 
from system_server import SystemServicer
from camera_api import system_service_pb2, system_service_pb2_grpc

# Configure service 
from configure_server import ConfigureServicer
from camera_api import configure_service_pb2, configure_service_pb2_grpc

# Network service 
from network_server import NetworkServicer
from camera_api import network_service_pb2, network_service_pb2_grpc

# Footage servcie 
from footage_server import FootageServicer
from camera_api import footage_service_pb2, footage_service_pb2_grpc

# UPloading servcie 
from uploading_server import UploadingServicer
from camera_api import uploading_service_pb2, uploading_service_pb2_grpc

# Stitching servcie 
from stitching_server import StitchingServicer
from camera_api import stitching_service_pb2, stitching_service_pb2_grpc

# Recording servcie 
from recording_server import RecordingServicer
from camera_api import recording_service_pb2, recording_service_pb2_grpc


class ApiServer(object):
    def __init__(self): 
        ## gRPC server  
        num_threads = 4 
        rospy.loginfo("Service thread pool size: {}".format(num_threads))
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=num_threads))

        rospy.loginfo("Serve health service")
        ## Use the non-blocking implementation to avoid thread starvation.
        health_servicer = HealthServicer(
            experimental_non_blocking=True,
            experimental_thread_pool=futures.ThreadPoolExecutor(max_workers=num_threads))
        health_pb2_grpc.add_HealthServicer_to_server(
            health_servicer, 
            self.server
        )

        rospy.loginfo("Serve system service")
        system_service_pb2_grpc.add_SystemServiceServicer_to_server(
            SystemServicer(),
            self.server
        )

        rospy.loginfo("Serve configure service")
        configure_service_pb2_grpc.add_ConfigureServiceServicer_to_server(
            ConfigureServicer(),
            self.server
        )

        rospy.loginfo("Serve network service")
        network_service_pb2_grpc.add_NetworkServiceServicer_to_server(
            NetworkServicer(),
            self.server
        )

        rospy.loginfo("Serve footage service")
        footage_service_pb2_grpc.add_FootageServiceServicer_to_server(
            FootageServicer(),
            self.server
        )

        rospy.loginfo("Serve uploading service")
        uploading_service_pb2_grpc.add_UploadingServiceServicer_to_server(
            UploadingServicer(),
            self.server
        )
    
        rospy.loginfo("Serve stitching service")
        stitching_service_pb2_grpc.add_StitchingServiceServicer_to_server(
            StitchingServicer(),
            self.server
        )

        rospy.loginfo("Serve recording service")
        recording_service_pb2_grpc.add_RecordingServiceServicer_to_server(
            RecordingServicer(),
            self.server
        )

        ## one state for all services now 
        health_servicer.set("", health_pb2.HealthCheckResponse.SERVING)
        
        service_port = 50051
        rospy.loginfo("Listen on port: {}".format(service_port))
        self.server.add_insecure_port("[::]:{}".format(service_port))
        self.server.start()


    def wait_for_shutdown(self): 
        rospy.loginfo("Service shuting down")
        self.server.stop(3)
        self.server.wait_for_termination()

    
if __name__ == "__main__":
    rospy.init_node("api_server", log_level=rospy.DEBUG)
    try: 
        server = ApiServer() 
    except rospy.ROSInterruptException:
        print("ROS interrupted")
        exit()
    try:
        rospy.spin()
    except rospy.ROSInterruptException:
        print("ROS interrupted")
    server.wait_for_shutdown() 
    print("Service shutdown")
