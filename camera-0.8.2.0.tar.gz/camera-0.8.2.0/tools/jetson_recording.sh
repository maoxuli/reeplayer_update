#!/bin/bash

CAMERA_ID=0
CAMERA_MODE=1080p
FLIP_METHOD=2
BITRATE=32000000

function print_help { 
  echo "Usage: $0 [-i ${CAMERA_ID}] [-m ${CAMERA_MODE}] [-r ${FLIP_METHOD}] [-q ${BITRATE}] [-h]"
  echo "-i: camera sensor ID, 0 or 1"
  echo "-m: camera sesnor mode:"
  echo -e "\t 1080p: 1920x1080@30 (default)" 
  echo -e "\t 1440p: 2560x1440@30"
  echo -e "\t 1944p: 2592x1944@30"
  echo -e "\t 3040p: 4032x3040@30"
  echo -e "\t 1848p: 3264x1848@28"
  echo -e "\t 2464p: 3264x2464@21"
  echo "-r: roation of input image:" 
  echo -e "\t 0: no rotation (default)" 
  echo -e "\t 1: counterclockwise - 90 degrees"
  echo -e "\t 2: rotate - 180 degrees"
  echo -e "\t 3: clockwise - 90 degrees"
  echo -e "\t 4: horizontal flip"
  echo -e "\t 5: upper right diagonal flip"
  echo -e "\t 6: vertical flip"
  echo -e "\t 7: upper-left diagonal"
  echo "-q: quality (bitrate in bps)" 
  echo "-h: help"
} 

while getopts ":i:m:r:q:h" opt; do
  case $opt in
    i) CAMERA_ID="$OPTARG";;
    m) CAMERA_MODE="$OPTARG";;
    r) FLIP_METHOD="$OPTARG";;
    q) BITRATE="$OPTARG";;
    \? | h | *) print_help; exit 0;;
  esac
done

# input 
WIDTH=1920
HEIGHT=1080
FPS=30
# output
OUT_WIDTH=1920
OUT_HEIGHT=1080

case $CAMERA_MODE in
  "1080p") WIDTH=1920; HEIGHT=1080; FPS=30; OUT_WIDTH=1920; OUT_HEIGHT=1080;;
  "1440p") WIDTH=2560; HEIGHT=1440; FPS=30; OUT_WIDTH=2560; OUT_HEIGHT=1440;;
  "1944p") WIDTH=2592; HEIGHT=1944; FPS=30; OUT_WIDTH=2592; OUT_HEIGHT=1944;;
  "3040p") WIDTH=4032; HEIGHT=3040; FPS=30; OUT_WIDTH=4032; OUT_HEIGHT=3040;;
  "1848p") WIDTH=3264; HEIGHT=1848; FPS=28; OUT_WIDTH=3264; OUT_HEIGHT=1848;;
  "2464p") WIDTH=3264; HEIGHT=2464; FPS=21; OUT_WIDTH=3264; OUT_HEIGHT=2464;;
  *) echo "Unknown camera mode: ${CAMERA_MODE}";;
esac

echo "CAMERA_ID: ${CAMERA_ID}"
echo "INPUT: ${WIDTH}x${HEIGHT}@${FPS}"
echo "OUTPUT: ${OUT_WIDTH}x${OUT_HEIGHT}@${FPS}"
echo "FLIP_METHOD: ${FLIP_METHOD}" 
echo "FILE_NAME: ${FILE_NAME}" 
echo "BITRATE: ${BITRATE}" 

# cropping 
LEFT=$(((WIDTH - OUT_WIDTH) / 2))
TOP=$(((HEIGHT - OUT_HEIGHT) / 2))
RIGHT=$((LEFT + OUT_WIDTH))
BOTTOM=$((TOP + OUT_HEIGHT))

echo "LEFT: ${LEFT}"
echo "TOP: ${TOP}"
echo "RIGHT: ${RIGHT}"
echo "BOTTOM: ${BOTTOM}"

# file name 
DATE_TIME="$(date +"%Y%m%d_%H_%M_%S_%N")"
FILE_NAME="cam_${CAMERA_ID}_${CAMERA_MODE}_${DATE_TIME}.mp4"

set -x

gst-launch-1.0 nvarguscamerasrc sensor-id=${CAMERA_ID} ! "video/x-raw(memory:NVMM),format=(string)NV12,width=(int)${WIDTH},height=(int)${HEIGHT},framerate=(fraction)${FPS}/1" ! nvvidconv flip-method=${FLIP_METHOD} left=${LEFT} top=${TOP} bottom=${BOTTOM} right=${RIGHT} ! "video/x-raw(memory:NVMM),format=(string)NV12,width=(int)${OUT_WIDTH},height=(int)${OUT_HEIGHT},pixel-aspect-ratio=1/1" ! queue ! nvv4l2h264enc bitrate=${BITRATE} ! h264parse ! qtmux ! filesink location="${FILE_NAME}" sync=0 async=0 -e

set +x 