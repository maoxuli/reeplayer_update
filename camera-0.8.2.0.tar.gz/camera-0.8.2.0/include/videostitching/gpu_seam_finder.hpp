#ifndef GPU_SEAM_FINDERS_HPP
#define GPU_SEAM_FINDERS_HPP

#include "cudaGraphCut.hpp"

#include <opencv2/core.hpp>
#include <opencv2/opencv_modules.hpp>
#include <opencv2/stitching/detail/seam_finders.hpp>
#include <opencv2/core/cuda.hpp>


namespace cv {
namespace detail {

class CV_EXPORTS CudaGraphCutSeamFinder : public GraphCutSeamFinderBase, public SeamFinder {

public:

    CudaGraphCutSeamFinder(
        int cost_type = COST_COLOR,
        int iterationsPerCheck = 10,
        int terminal_cost = (int)1e7,
        bool use_previous_seam = true,
        int seam_window_min = 9,
        int seam_window_max = 23,
        int bad_region_penalty = (int)1e7,
        float max_bfs_count_per_pixel = 0.0014,
        int gap_width = 5
    ) :
        cost_type_(cost_type),
        iterationsPerCheck_(iterationsPerCheck),
        terminal_cost_(terminal_cost),
        use_previous_seam_(use_previous_seam),
        seam_window_min_(seam_window_min),
        seam_window_max_(seam_window_max),
        bad_region_penalty_(bad_region_penalty),
        max_bfs_count_per_pixel_(max_bfs_count_per_pixel),
        gap(gap_width),
        frameNumber_(0),
        forceRestart_(1)
    {}

    void find(
        const std::vector<cv::UMat> &src,
        const std::vector<cv::Point> &corners,
        std::vector<cv::UMat> &masks) CV_OVERRIDE;

    void setMasks(
        const std::vector<cv::Point>& corners,
        std::vector<cv::cuda::GpuMat>& masks);

    void setMasks(
        const std::vector<cv::Point>& corners,
        std::vector<cv::cuda::GpuMat>& masks,
        std::vector<cv::cuda::GpuMat>& prevmasks);

    void findNextFrame(
        const std::vector<cv::cuda::GpuMat>& images, const std::vector<cv::cuda::GpuMat>& foreground, std::vector<cv::cuda::GpuMat>& masks_result);

protected:

    std::vector<cuda::GpuMat> images_;
    std::vector<cuda::GpuMat> foreground_;
    std::vector<Size> sizes_;
    std::vector<Point> corners_;
    std::vector<cuda::GpuMat> masks_;
    std::vector<std::pair<cuda::GpuMat, cuda::GpuMat>> submasks_;
    std::vector<Locations> locs_;
    std::vector<std::pair<cuda::GpuMat, cuda::GpuMat>> prevmasks_;
    std::vector<CudaGCGraph> graphs_;

    void findInPairNextFrame(size_t first, size_t second, Rect roi, std::vector<cv::cuda::GpuMat>& masks_result);

    void initSubImgs(
        Locations loc,
        cuda::GpuMat& img1,
        cuda::GpuMat& img2,
        cuda::GpuMat& subimg1,
        cuda::GpuMat& subimg2,
        int matType = CV_32F
    );

    int windowWidth(double ratio, int overlapWidth);

    int idx(size_t i, size_t j) { return (int)(i * (sizes_.size() - 1) + j - 1); }

private:

    const int gap;
    int iterationsPerCheck_;
    int cost_type_;
    int terminal_cost_;
    bool use_previous_seam_;
    int seam_window_min_;
    int seam_window_max_;
    int bad_region_penalty_;
    float max_bfs_count_per_pixel_;
    int frameNumber_;
    int forceRestart_;

};

} // namespace detail
} // namespace cv

#endif // GPU_SEAM_FINDERS_HPP
