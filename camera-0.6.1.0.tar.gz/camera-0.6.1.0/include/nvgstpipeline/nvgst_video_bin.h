#ifndef __NVGST_VIDEO_BIN_H__
#define __NVGST_VIDEO_BIN_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <nvgstpipeline/nvgst_common.h>

typedef struct 
{
  gchar *format;
  guint flip_method;
  guint left; 
  guint top;
  guint right; 
  guint bottom;
  guint width;
  guint height; 
  guint fps_n;
  guint fps_d; 
  guint aspect_n;
  guint aspect_d;
} NvGstVideoConfig;

typedef struct
{
  GstElement *bin;
  GstElement *queue;
  GstElement *conv;
  GstElement *caps_filter;
} NvGstVideoConvBin;

gboolean create_video_conv_bin (NvGstVideoConfig * config, NvGstVideoConvBin * bin); 

#ifdef __cplusplus
}
#endif

#endif
