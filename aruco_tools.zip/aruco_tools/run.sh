#!/bin/bash

./charuco_calib -w=8 -h=6 --ml=0.023 --sl=0.030 --ci=1 -v=/home/maoxu/data/calib/2021_05_04_14_07_22.mp4 /home/maoxu/data/calib/camera_info_1.yaml
