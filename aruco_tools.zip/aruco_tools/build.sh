#!/bin/bash

g++ calibrate_camera_charuco.cpp `pkg-config --cflags --libs opencv4` -o charuco_calib
