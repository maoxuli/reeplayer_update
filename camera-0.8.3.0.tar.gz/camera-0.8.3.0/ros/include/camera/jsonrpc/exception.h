#ifndef JSONRPC_EXCEPTION_H_
#define JSONRPC_EXCEPTION_H_

#include "errors.h"
#include <string>
#include <exception>
#include <nlohmann/json.hpp>
using json = nlohmann::json;

namespace jsonrpc {

class Exception : public std::exception 
{
public:
    Exception(int code);
    Exception(int code, const std::string &message);
    Exception(int code, const std::string &message, const json &data);
    Exception(const std::string &message);

    virtual ~Exception() throw();

    int get_code() const;
    const std::string& get_message() const;
    const json& get_data() const;

    virtual const char* what() const throw();

private:
    int _code;
    std::string _message;
    std::string _what_string;
    json _data;
    void _set_what_message();
};

} // namespace jsonrpc 

#endif
