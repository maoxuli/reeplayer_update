#!/usr/bin/env python 

import json 
import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse
from camera_ros import Calibrator, Recorder  

from concurrent import futures
import grpc

# Stitchig service
from camera_api import stitching_service_pb2, stitching_service_pb2_grpc


class StitchingServicer(stitching_service_pb2_grpc.StitchingServiceServicer):
    """Service to control and monitor the video stitching 
    """
    def __init__(self): 
        super(StitchingServicer, self).__init__()
        ## connect to ROS service of calibrator and recorder node 
        self.calibrator = Calibrator() 
        self.recorder = Recorder() 


    def online_calib(self, request, context):
        """Online calibration 
        """
        rospy.loginfo("Stitching online calib")
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')


    def snapshot(self, request, context):
        """Snapshot of the stitching output 
        """
        rospy.loginfo("Stitching snapshot: {}".format(request.image_scale))
        try: 
            images = self.recorder.recording_snapshot(request.image_scale) 
            return stitching_service_pb2.camera__api_dot_snapshot__pb2.SnapshotResponse(images=images)
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


class StitchingServer(object):
    def __init__(self): 
        ## gRPC server  
        num_threads = 4 
        ropy.loginfo("Service thread pool size: {}".format(num_threads))
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=num_threads))

        rospy.loginfo("Serve stitching service")
        stitching_service_pb2_grpc.add_StitchingServiceServicer_to_server(
            StitchingServicer(),
            server
        )
        
        service_port = 50051
        rospy.loginfo("Listen on port: {}".format(service_port))
        self.server.add_insecure_port("[::]:{}".format(service_port))
        self.server.start()


    def wait_for_shutdown(self): 
        self.server.stop( )
        self.server.wait_for_termination()


if __name__ == "__main__":
    rospy.init_node("stitching_server", log_level=rospy.DEBUG)
    server = StitchingServer() 
    try:
        rospy.spin()
    except rospy.ROSInterruptException:
        print("ROS interrupted")
    server.wait_for_shutdown() 
    print("Service shutdown")
