#!/usr/bin/env python

import logging 
import requests

class UploadingAPI(object):
    def __init__(self, service_url, token, serial_no): 
        self.service_url = service_url  
        self.token = token 
        self.serial_no = serial_no 

    def post_request(self, endpoint, data):

        url = "{}/{}".format(self.service_url, endpoint) 
        headers = {"Authorization": "Bearer {}".format(self.token)}
        data["serial_no"] = str(self.serial_no)
        logging.info("request: {}: {}".format(url, data))
        resp = requests.post(url, json=data, headers=headers)
        logging.info("response: {resp.status_code}")
        return resp

    def footage_meta_upload(self, footage_id):
        logging.info("footage meta upload")
        resp = self.post_request(
            "footages/footage-meta-upload", 
            {
                "footage_id": footage_id
            }
        )
        return resp.json()["corners_file_address"]

    def footage_upload(self, footage_id):
        logging.info("footage upload")
        resp = self.post_request(
            "footages/footage-upload", 
            {
                "footage_id": footage_id,
            }
        )
        return resp.status_code == 201

    def footage_part_upload(self, footage_id, part_id):
        logging.info("footage part upload")
        resp = self.post_request(
            "footages/footage-part-upload",
            {
                "footage_id": footage_id, 
                "part_id": part_id,
            }
        )
        return resp.json()["file_address"]

    def footage_upload_progress(self, footage_id, finished, progess):
        resp = self.post_request(
            "footages/footage-upload-progress",
            {
                "footage_id": footage_id, 
                "finished": finished, 
                "progress": progress, 
            }
        )
        return resp.status_code == 201

    def footage_part_upload_progress(self, footage_id, part_id, finished, progress):
        resp = self.post_request(
            "footages/footage-upload-progress",
            {
                "footage_id": footage_id,
                "part_id": part_id,
                "finished": finished,
                "progress": progress,
            }
        )
        return resp.status_code == 201
