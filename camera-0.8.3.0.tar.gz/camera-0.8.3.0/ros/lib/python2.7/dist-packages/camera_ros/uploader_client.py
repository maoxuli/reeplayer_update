import json 
import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService 
from jsonrpc import * 


def _call_ros_service(service, method, params = None):
    request = jsonrpc_wrap_request(method, params)
    if not jsonrpc_validate_request(request): 
        raise Exception("Invalid JSON-RPC request: {}".format(request))
    try: 
        rospy.logdebug("JSON-RPC request: {}".format(request))
        response = json.loads(service(json.dumps(request)).data)
        # rospy.logdebug("JSON-RPC response: {}".format(response))
        return response["result"] if "result" in response else None 
    except rospy.ServiceException as e:
        raise Exception("Call ROS service failed: {}".format(e))
    except ValueError as e: 
        raise Exception("Invalid JSON value: {}".format(e))


class Uploader(object):
    def __init__(self):
        self.status_topic = "uploader_status"
        self.status_sub = None 

        uploader_rpc_service = "uploader_rpc"
        rospy.loginfo("Connecting to ROS service: {}".format(uploader_rpc_service))
        self.rpc_service = rospy.ServiceProxy(uploader_rpc_service, JsonService)
        # rospy.loginfo("Waiting for ROS service: {}".format(uploader_rpc_service))
        # rospy.wait_for_service(uploader_rpc_service)
        # rospy.loginfo("Connected to ROS service: {}".format(uploader_rpc_service))


    def subscribe_status(self, status_callback): 
        def msg_callback(msg): 
            try: 
                rospy.logdebug(msg)
                notifications = json.loads(msg.data)
                statuses = {}
                for notification in notifications:
                    statuses[notification["method"]] = notification["params"] 
                status_callback(statuses)
            except Exception as e: 
                rospy.logwarn("Uploader status topic callback error: " + str(e))
                
        rospy.loginfo("Subscribe ROS topic: {}".format(self.status_topic))
        self.status_sub = rospy.Subscriber(self.status_topic, JsonString, msg_callback) 


    def unsubscribe_status(self): 
        if self.status_sub: 
            rospy.loginfo("Unsubscribe ROS topic: {}".format(self.status_topic))
            self.status_sub.unregister()


    def start_uploading(self, footage):
        return _call_ros_service(self.rpc_service, "start_uploading", {"footage_id": footage})  


    def stop_uploading(self, footage):
        return _call_ros_service(self.rpc_service, "stop_uploading", {"footage_id": footage})  


    def pause_uploading(self, footage):
        return _call_ros_service(self.rpc_service, "pause_uploading", {"footage_id": footage})  


    def resume_uploading(self, footage):
        return _call_ros_service(self.rpc_service, "resume_uploading", {"footage_id": footage})  


    def uploading_status(self, footage):
        return _call_ros_service(self.rpc_service, "uploading_status", footage) 
