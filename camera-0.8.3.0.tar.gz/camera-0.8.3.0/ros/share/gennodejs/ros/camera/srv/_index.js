
"use strict";

let JsonService = require('./JsonService.js')

module.exports = {
  JsonService: JsonService,
};
