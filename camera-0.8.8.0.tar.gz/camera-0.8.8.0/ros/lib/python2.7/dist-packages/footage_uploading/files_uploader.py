#!/usr/bin/env python

import os
import threading 
import requests
from concurrent.futures import *

try:
    from urllib.parse import urlparse
except ImportError:
     from urlparse import urlparse

## The files will be pushed into the uploading threads, and transit 
## among below status. We use a file id to indentify the file.  
## there is no limit of the concurrent files number. 

class FilesUploader(object):
    STOPPED = 0 
    FAILED = 1 
    WAITING = 2
    UPLOADING = 3
    UPLOADED = 4 

    def __init__(self, status_callback, max_workers = 5): 
        self.status_callback = status_callback 
        self.executer = ThreadPoolExecutor(max_workers)
        self.futures = {}
        self.lock = threading.Lock()

    ## enqueue a file for uploading, the file will be set to waiting 
    ## state if it is successfully submitted. 
    def add(self, file_id, file_path, url):
        print("files uploader add: {}".format(file_id))
        with self.lock: 
            if file_id in self.futures: 
                print("{} already in the queue".format(file_id))
                return True 
            print("submit task {} to the queue".format(file_id))
            future = self.executer.submit(self.uploading, file_id, file_path, url)
            self.futures[file_id] = future 
            future.add_done_callback(self.uploading_done)
            return True 
    
    ## remove a file form uploading queue. The process may be delayed to complete, 
    ## so the caller should set the status to Stopped if return True 
    def remove(self, file_id): 
        with self.lock: 
            if file_id not in self.futures: 
                return True 
            if not self.futures[file_id].cancel():  
                return False 
            del self.futures[file_id]
            return True 
            
    def uploading(self, file_id, file_path, url):
        print("uploading: {}".format(file_id)) 
        self.status_callback(file_id, self.UPLOADING)
        files = {"file": (urlparse(url).path[1:], open(file_path, "rb"))}
        print("files: {}".format(files))
        resp = requests.put(url, files=files)
        return file_id, resp.status_code

    def uploading_done(self, future): 
        try: 
            file_id, status_code = future.result() 
            print("uploading done: {}".format(file_id))
            with self.lock: 
                print("remove task {} from queue".format(file_id))
                del self.futures[file_id]
            status = self.UPLOADED if (status_code == 200 or status_code == 201) else self.FAILED 
            self.status_callback(file_id, status) 
        except CancelledError as e: 
            print("uploading canceled before done")
