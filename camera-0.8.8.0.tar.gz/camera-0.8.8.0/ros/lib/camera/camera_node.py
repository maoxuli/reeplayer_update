#! /usr/bin/env python

import os 
import time
import threading
import socket 
import select 

import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse

import json
from jsonrpc import * 


class CameraNode(object): 
    RECV_BUFFER_SIZE = 1024 

    def __init__(self): 
        ## loading config 
        self.config_file = rospy.get_param("~config_file", "camera.json")
        self.backup_config_file = rospy.get_param("~backup_config_file", "")
        rospy.loginfo("Loading config from: {}".format(self.config_file))
        try: 
            self.settings = self._load_config(self.config_file)
            rospy.logdebug(self.settings)
        except Exception as e: 
            rospy.logerr("Failed loading config from {}".format(self.config_file)) 
            raise e 

        ## communication with camerad service 
        camerad_port = self.settings["camerad_port"] if "camerad_port" in self.settings else 6666 
        rospy.loginfo("camerad service port: {}".format(camerad_port))
        self.camerad_addr = ('127.0.0.1', camerad_port)

        self.camerad_timeout = self.settings["camerad_timeout"] if "camerad_timeout" in self.settings else 3.0 
        rospy.loginfo("camerad service timeout: {}".format(self.camerad_timeout))

        ## dispatch service requests to handlers
        ## this is a list of methods that can be procesed in this object  
        ## all methods not in this list will be forwarded to the systemd service  
        self.service_handlers = { 
            'check_config': self.check_config, 
            'update_config': self.update_config, 
            'reset_config': self.reset_config, 
            'save_config': self.save_config, 
            # 'shutdown_system': self.shutdown_system, 
            # 'restart_system': self.restart_system,
            'system_status': self.system_status, 
            # 'scan_wifi': self.scan_wifi,
            # 'connect_wifi': self.connect_wifi,
            # 'disconnect_wifi': self.disconnect_wifi, 
            # 'network_status': self.network_status,
            # 'check_software': self.check_software, 
            # 'download_software': self.download_software, 
            # 'install_software': self.install_software, 
            # 'software_status': self.software_status, 
        }
        rospy.loginfo("Service handlers:{}".format(self.service_handlers.keys()))

        ## A list of status checking methods 
        ## add or remove by status subscribe method 
        self.notifications = [
            'system_status',
            # 'network_status',
            # 'software_status',
        ]
        rospy.loginfo("Status notifications:{}".format(self.notifications))

        ## camera service 
        rpc_service = "rpc"
        rospy.loginfo("Starting service: {}".format(rpc_service))
        rospy.Service(rpc_service, JsonService, self.rpc_service_handler)

        ## status topic 
        status_topic = "status" 
        rospy.loginfo("Advertise topic: {}".format(status_topic))
        self.status_pub = rospy.Publisher(status_topic, JsonString, queue_size=2)

        ## status notification in update thread 
        update_thread = threading.Thread(target=self.status_update_thread)
        update_thread.start()


    ## RPC service handler 
    ## JSON string carried by ROS service request and response  
    def rpc_service_handler(self, request): 
        rospy.logdebug("RPC request: {}".format(request.data))
        try: 
            json_request = json.loads(request.data)
            json_response = self.handle_json_request(json_request)
        except Exception as e: 
            json_reponse = jsonrpc_wrap_error(None, JSON_PARSE_ERROR, str(e))
        rospy.logdebug("RPC response: {}".format(json_response))
        return JsonServiceResponse(json.dumps(json_response))


    ## handle JSON-RPC 2.0 request 
    def handle_json_request(self, request): 
        rospy.logdebug("JSON RPC request: {}".format(request))
        if isinstance(request, list): 
            return self.handle_batch_request(request)
        elif isinstance(request, dict): 
            return self.handle_single_request(request)
        else: 
            return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, "The request is neither a list nor an object."); 


    ## handle batch request 
    def handle_batch_request(self, request): 
        rospy.logdebug("Handle batch request: {}".format(request))
        if request: 
            response = [] 
            for req in request: 
                res = self.handle_single_request(req); 
                response.append(res)
            return response
        else: 
            return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, "Empty request list.")            


    ## handle single request 
    def handle_single_request(self, request): 
        rospy.logdebug("Handle single request: {}".format(request))
        if jsonrpc_validate_request(request): 
            return self.process_request(request)
        else: 
            return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, "Failed in validation.")


    ## process request 
    def process_request(self, request): 
        rospy.logdebug("Process request: {}".format(request))
        try: 
            method = request["method"]
            if method in self.service_handlers: 
                rospy.logdebug("local handle request: {}".format(method))
                params = request["params"] if "params" in request else None 
                result = self.service_handlers[method](params)
                rospy.logdebug("result: {}".format(result))
                return jsonrpc_wrap_result(request, result) 
            else: 
                rospy.logdebug("system handle request: {}".format(method))
                return self.handle_system_request(request)
        except JsonRpcError as e: 
            rospy.logerr("exception: {}".format(str(e)))
            return jsonrpc_wrap_exception(request, e)
        except Exception as e: 
            rospy.logerr("exception: {}".format(str(e)))
            return jsonrpc_wrap_error(None, RPC_INTERNAL_ERROR, str(e))


    def _load_camera_serial(self): 
        rospy.logdebug("load camera serial...")
        serial_file = self.settings["serial_file"] if "serial_file" in self.settings else "xxx" ## "/opt/reeplayer/.serial"
        try: 
            rospy.logdebug("Loading serial from file {}".format(serial_file))
            with open(serial_file) as f: 
                serial = json.load(f) 
            rospy.logdebug(serial)
            return serial
        except Exception as e: 
            rospy.logerr("Failed loading serial from file: {}".format(serial_file))
            raise Exception("Failed loading serial from file: {}".format(serial_file))


    def _save_camera_serial(self, serial): 
        rospy.logdebug("save camera serial: {}".format(serial))
        serial_file = self.settings["serial_file"] if "serial_file" in self.settings else "/opt/reeplayer/.serial"
        try: 
            rospy.logdebug("Save serial to file {}".format(serial_file))
            with open(serial_file, "w+") as f: 
                json.dump(serial, f)
        except: 
            rospy.logerr("Failed saving serial to file: {}".format(serial_file))
            raise Exception("Failed saving serial to file: {}".format(serial_file))


    def _load_camera_token(self):
        rospy.logdebug("load camera token...")
        token_file = self.settings["token_file"] if "token_file" in self.settings else "yyy" ### "/opt/reeplayer/.token"
        try: 
            rospy.logdebug("Loading token form file: {}".format(token_file))
            with open(token_file) as f: 
                token = json.load(f) 
            rospy.logdebug(token)
            return token 
        except: 
            rospy.logerr("Failed loading token from file: {}".format(token_file))
            raise Exception("Failed loading token from file: {}".format(token_file))


    def _save_camera_token(self, token): 
        rospy.logdebug("save camera token: {}".format(token))
        token_file = self.settings["token_file"] if "token_file" in self.settings else "/opt/reeplayer/.token"
        try: 
            rospy.logdebug("Saving token to file: {}".format(token_file))
            with open(token_file, "w+") as f: 
                json.dump(token, f, indent=4) 
        except: 
            rospy.logerr("Failed saving token to file: {}".format(token_file))
            raise Exception("Failed saving token to file: {}".format(token_file))


    def _load_config(self, config_file): 
        try: 
            rospy.loginfo("Loading config file: {}".format(config_file))
            with open(config_file) as f: 
                settings = json.load(f)
            rospy.logdebug(settings)
            return settings 
        except Exception as e: 
            rospy.logerr("Failed loading config file {}: {}".format(config_file, str(e))) 
            raise JsonRpcError(RPC_INTERNAL_ERROR, "Failed loading config file {}: {}".format(config_file, str(e))) 


    def _save_config(self, config_file): 
        try: 
            rospy.loginfo("Saving config file: {}".format(config_file))
            with open(config_file, "w+") as f: 
                json.dump(self.settings, f, indent=4)
        except Exception as e: 
            rospy.logerr("Failed save config file {}: {}".format(config_file, str(e))) 
            raise JsonRpcError(RPC_INTERNAL_ERROR, "Failed save config file {}: {}".format(config_file, str(e))) 


    def _auto_save_config(self, config_file): 
        if "auto_save" in self.settings and self.settings["auto_save"]: 
            self._save_config(config_file)


    ## check config  
    def check_config(self, params): 
        rospy.loginfo("check config...")
        if params is None or len(params) == 0: 
            try: 
                config = self.settings 
                config["serial"] = self._load_camera_serial()
                config["token"] = self._load_camera_token() 
                return self.settings 
            except Exception as e: 
                raise JsonRpcError(RPC_INTERNAL_ERROR, "Error prepare config: " + str(e))
        elif isinstance(params, list): 
            nodes = params 
        else: 
            nodes = [params]
        config = {}
        for node in nodes: 
            try:
                if node == "serial": 
                    config["serial"] = self._load_camera_serial() 
                elif node == "token": 
                    config["token"] = self._load_camera_token()  
                elif node in self.settings:
                    config[node] = self.settings[node]
                else: 
                    raise JsonRpcError(RPC_INVALID_PARAMS, "Invalid config node: {}".format(node))
            except Exception as e: 
                raise JsonRpcError(RPC_INTERNAL_ERROR, "Error prepare config: " + str(e))
        return config 


    ## update config  
    def update_config(self, params): 
        rospy.loginfo("update config...")
        if params is None or not isinstance(params, dict) or len(params) == 0: 
            raise JsonRpcError(RPC_INVALID_PARAMS, "Invalid params: {}".format(params))
        for node in params: 
            if node == "serial": 
                self._save_camera_serial(params["serial"])
            elif node == "token": 
                self._save_camera_token(params["token"])
            elif node in self.settings: 
                self.settings[node] = params[node]
                self._auto_save_config(self.config_file)                 
            else: 
                raise JsonRpcError(RPC_INVALID_PARAMS, "Invalid config node: {}".format(node))


    ## reset config  
    def reset_config(self, params): 
        rospy.loginfo("reset config...")
        raise JsonRpcError(RPC_INTERNAL_ERROR, "Not implemented.")


    ## save config  
    def save_config(self, params): 
        rospy.loginfo("save config...")
        self._save_config(self.config_file)


    # ## shutdown system 
    # def shutdown_system(self, params): 
    #     rospy.loginfo("shutdown system...")


    # ## restart system 
    # def restart_system(self, params): 
    #     rospy.loginfo("reboot system...")


    ## system status 
    def system_status(self, params):
        rospy.logdebug("system status...")
        systems = request["params"] if params and "params" in params else []
        rospy.logdebug("Check system status for: {}".format(systems))
        statuses = {}
        try: 
            statuses["battery"] = {"capacity": 100, "percent": 100, "state": 0}
            statuses["cpu"] = {"usage": [20, 10, 12, 21], "frequency": [1190, 1190, 1190, 1190]}
            statuses["memory"] = {"total": 16000000, "used": 2000000, "free": 14000000}
            fs = os.statvfs("/")
            total = fs.f_blocks * fs.f_frsize / 1000000
            free = fs.f_bavail * fs.f_frsize / 1000000
            used = total - free 
            percent = used / total * 100 
            statuses["storage"] = {"total": total, "used": used, "free": free, "percent": percent}
            rospy.logdebug("statuses: {}".format(statuses))
        except Exception as e: 
            rospy.logwarn("system status error: " + str(e))
        return statuses  

    # ## scan wifi 
    # def scan_wifi(self, params): 
    #     rospy.logdebug("scan wifi...")


    # ## connect wifi 
    # def connect_wifi(self, params): 
    #     rospy.logdebug("connect wifi...")


    # ## diconnect wifi
    # def disconnect_wifi(self, params): 
    #     rospy.logdebug("disconnect wifi...")
    

    # ## check network status 
    # def network_status(self, params): 
    #     rospy.logdebug("network status...")


    # ## check software update 
    # def check_software(self, params): 
    #     rospy.logdebug("check software update...")


    # ## download software update 
    # def download_software(self, params): 
    #     rospy.logdebug("download software update...")

    # ## install update 
    # def install_software(self, params): 
    #     rospy.logdebug("install software update...")


    # ## software update status
    # def software_status(self, params): 
    #     rospy.logdebug("software update status...")


    ## handle request by forwarding to camerad service 
    def handle_system_request(self, request):
        rospy.logdebug("Handle system request: {}".format(request))
        try: 
            json_request = json.dumps(request)
            json_request += "\n"; # json string in line 
            rospy.logdebug("Connting to service: {}".format(self.camerad_addr))
            conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            conn.connect(self.camerad_addr)
            rospy.logdebug("Sending request: {}".format(json_request))
            conn.sendall(json_request)
            rospy.logdebug("Waiting for response")
            conn.setblocking(0)
            rlist, _, _ = select.select([conn], [], [], self.camerad_timeout)
            if rlist: 
                assert rlist[0] == conn 
                json_response = conn.recv(self.RECV_BUFFER_SIZE)
                rospy.logdebug("Received response: {}".format(json_response))
                response = json.loads(json_response)
                return response 
            else: 
                rospy.logdebug("Response timeout!")
                raise JsonRpcError(RPC_INTERNAL_ERROR, "Response timeout from camerad service")
        except socket.error, msg:
            rospy.logerr("Socket exception: {}".format(msg))
            raise JsonRpcError(RPC_INTERNAL_ERROR, "Socket exception: " + str(msg))
        except Exception as e: 
            rospy.logerror("Exception: " + str(e))
            raise JsonRpcError(RPC_INTERNAL_ERROR, "Exception: " + str(e))
        finally: 
            rospy.logdebug("Close connection")
            conn.close() 


    ## status update thread 
    def status_update_thread(self): 
        rospy.loginfo("Status update thread in")
        update_rate = self.settings["status_update_rate"] if "status_update_rate" in self.settings else 1.0
        update_rate = update_rate if update_rate > 0 else 1.0
        rospy.loginfo("status update rate: {}".format(update_rate))
        ros_rate = rospy.Rate(update_rate)
        while not rospy.is_shutdown():
            if self.status_pub.get_num_connections() > 0: 
                status = []
                for method in self.notifications:
                    request = {"method": method} 
                    try: 
                        response = self.handle_json_request(request)
                        if "result" in response: 
                            notification = {"method": method, "params": response["result"]}
                            status.append(notification)
                    except Exception as e: 
                        rospy.logwarn("Status update excepton for {}: {} ".format(method, str(e)))
                if status: 
                    try: 
                        status_msg = JsonString(json.dumps(status)) 
                        self.status_pub.publish(status_msg)
                        rospy.logdebug("Publish status message: {}".format(status))
                    except Exception as e: 
                        rospy.logwarn("status publish exception for {}: {} ".format(method, str(e)))
            ros_rate.sleep() 
        rospy.loginfo("Status update thread out")


if __name__ == '__main__':
    try:
        rospy.init_node("camera", log_level=rospy.DEBUG)
        CameraNode() 
        rospy.spin()
    except rospy.ROSInterruptException:
        print("ROS interrupted")
