#!/usr/bin/env bash 
set -e 

cd ~/Downloads
wget https://github.com/ArduCAM/MIPI_Camera/releases/download/v0.0.3/install_full.sh

chmod +x install_full.sh
./install_full.sh -m imx477
