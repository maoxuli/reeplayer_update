
"use strict";

let JsonTaskActionResult = require('./JsonTaskActionResult.js');
let JsonTaskGoal = require('./JsonTaskGoal.js');
let JsonTaskFeedback = require('./JsonTaskFeedback.js');
let JsonTaskResult = require('./JsonTaskResult.js');
let JsonTaskActionGoal = require('./JsonTaskActionGoal.js');
let JsonTaskAction = require('./JsonTaskAction.js');
let JsonTaskActionFeedback = require('./JsonTaskActionFeedback.js');

module.exports = {
  JsonTaskActionResult: JsonTaskActionResult,
  JsonTaskGoal: JsonTaskGoal,
  JsonTaskFeedback: JsonTaskFeedback,
  JsonTaskResult: JsonTaskResult,
  JsonTaskActionGoal: JsonTaskActionGoal,
  JsonTaskAction: JsonTaskAction,
  JsonTaskActionFeedback: JsonTaskActionFeedback,
};
