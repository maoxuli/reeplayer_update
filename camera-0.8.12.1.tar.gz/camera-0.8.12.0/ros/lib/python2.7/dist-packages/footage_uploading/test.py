#!/usr/bin/env python

from uploading_api import UploadingAPI 
from files_uploader import FilesUploader 

try:
    from urllib.parse import urlparse
except ImportError:
     from urlparse import urlparse

print("test uploading")

service_url = "https://api.prod.reeplayer.com" 
token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIwZTdhNjEwMy1iNTEyLTQ1N2MtOGUxZC0zZTdiYjhjMzQ0OTIiLCJjaWQiOiIxZGExZjg4NS1jNGMwLTRjZGYtOTc3OS1jNThhZmViMWU1ZjkiLCJhdWQiOiJjYyIsImlhdCI6MTY1NTIyOTk5Mzk0MywiZXhwIjoxOTcwNTg5OTkzOTQzfQ.sOK3_wRi9EH7XqKGxDaEWy45DSpgswe10_W3OzmS4Zs"
serial = "123456"
api = UploadingAPI(service_url, token, serial)

def _uploading_status_callback(file_id, status): 
    print("uploading status: {} - {}".format(file_id, status))

uploader = FilesUploader(_uploading_status_callback)

footage_id = "cae851cb-d5e9-47db-91b3-5b3850551b60"

meta_id = "corners"
meta_path = "/home/reeplayer/camera_data/2022_06_11_23_03_06/corners.json"

file_id = "vid_2022_04_24_17_42_32_part_3_part_0"
file_path = "/home/reeplayer/camera_data/2022_06_11_23_03_06/vid_2022_04_24_17_42_32_part_3_part_0.mp4"

# file_id_1 = "cae851cb-d5e9-47db-91b3-5b3850551b48-vid_2022_06_11_21_05_39"
# file_path_1 = "/home/reeplayer/camera_data/2022_06_11_21_03_04/vid_2022_06_11_21_05_39.mp4"

## footage_upload 
response = api.footage_upload(footage_id)
print("footage_upload response: {}".format(response))

## footage_meta_upload
file_url = api.footage_meta_upload(footage_id)
print("footage_meta_upload response: {}".format(file_url))

ret = uploader.add(meta_id, meta_path, file_url)
print("add meta to uploader: {}".format(ret))

## footage_part_upload
file_url = api.footage_part_upload(footage_id, file_id)
print("footage_part_upload response: {}".format(file_url))

ret = uploader.add(file_id, file_path, file_url)
print("add file to uplaoder: {}".format(ret))

# file_url = api.footage_part_upload(footage_id, file_id_1)
# print("footage_part_upload response: {}".format(file_url))

# ret = uploader.add(file_id_1, file_path_1, file_url)
# print("add file 1 to uplaoder: {}".format(ret))
