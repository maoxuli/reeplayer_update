#!/usr/bin/env python

import os 
import threading 
import json
import time 

from footage import Footage, FootageManager
from files_uploader import FilesUploader
from uploading_api import UploadingAPI 

## extend the footage to support the operations of uploading 
## and maintain the uploading status. 
## Status driven uploading control 
## The footage and files will be set to a expected status, and 
## then the update thread will handle the real operations.  
class FootageUploading(Footage): 
    STOPPED = 0
    STOPPING = 1 
    UPLOADING = 2
    PAUSING = 3
    PAUSED = 4
    UPLOADED = 5  

    def __init__(self, path, settings, uploader, api): 
        super(FootageUploading, self).__init__(path, settings)
        self.uploader = uploader 
        self.api = api 
        self.last_error = None 
        
        ## we only maintain the uploading status here 
        self.lock = threading.Lock() 
        if "uploading" not in self.statuses: 
            self.statuses["uploading"] = {"state": FootageUploading.STOPPED}
            self._save_uploading_status()
        self.uploading = self.statuses["uploading"]

    ## return the detailed uploading status of the footage 
    def uploading_status(self):
        with self.lock: 
            footage_state = self.uploading["state"] if "state" in self.uploading else self.STOPPED
            footage_progress = 0 
            footage_error = None 
            if footage_state == self.UPLOADED: 
                footage_progress = 100 
            else: 
                total_kb = 0
                uploaded_kb = 0
                for file_name in self._meta_files(): 
                    file_path = os.path.join(self.path, file_name) 
                    file_size = int(os.path.getsize(file_path) / 1000) 
                    total_kb += file_size
                    file_state = self.uploading["meta_files"][file_name]["state"]
                    if file_state == FilesUploader.UPLOADED: 
                        uploaded_kb += file_size 
                for file_name in self._video_files(): 
                    file_path = os.path.join(self.path, file_name) 
                    file_size = int(os.path.getsize(file_path) / 1000) 
                    total_kb += file_size
                    file_state = self.uploading["video_files"][file_name]["state"]
                    if file_state == FilesUploader.UPLOADED: 
                        uploaded_kb += file_size 
                footage_progress = int(100.0 * uploaded_kb / total_kb) if total_kb > 0 else 0 
            return {"state": footage_state, "progress": footage_progress, "last_error": self.last_error}

    ## save the uploading status to file 
    def _save_uploading_status(self): 
        try: 
            self.save_status("uploading")
        except Exception as e: 
            print("save uploading status error: " + str(e))
            self.last_error = {"code": 0, "message": str(e)}

    ## Set to uploading state, the worker thread will handle the 
    ## files uploading, untile uploaded state 
    def start_uploading(self): 
        with self.lock: 
            if self.uploading["state"] < self.UPLOADING: 
                self.api.footage_upload(self.id)
                self.uploading["state"] = self.UPLOADING
                self._save_uploading_status()

    ## Set to stopping state, because the uploading can not be cancelled 
    ## sometime, so the final result may be stopped or uploaded 
    def stop_uploading(self): 
        with self.lock: 
            if self.self.uploading["state"] > self.STOPPING:
                self.uploading["state"] = self.STOPPING
                self._save_uploading_status()

    ## Set to pausing state, because the uploading can not be cancelled 
    ## sometime, so the final state may be paused or uplaoded 
    def pause_uploading(self): 
        with self.lock: 
            if self.uploading["state"] == self.UPLOADING:
                self.uploading["state"] = self.PAUSING
                self._save_uploading_status()

    ## Set the state to uploading, the work thread will handle the files 
    ## uploading until uploaded state 
    def resume_uploading(self): 
        with self.lock: 
            if self.uploading["state"] == self.PAUSING or self.uploading["state"] == self.PAUSED:  
                self.uploading["state"] = self.UPLOADING 
                self._save_uploading_status()

    ## load new files and remove missing files
    def _sync_files(self): 
        try: 
            with self.lock: 
                if "meta_files" not in self.uploading: 
                    self.uploading["meta_files"] = {}
                if "video_files" not in self.uploading: 
                    self.uploading["video_files"] = {}
                ## remove missing files 
                del_files = []
                for file_name in self.uploading["meta_files"]: 
                    file_path = os.path.join(self.path, file_name)
                    if not os.path.exists(file_path): 
                        del_files.append(file_name)
                if del_files: 
                    for file_name in del_files: 
                        print("footage remove file: {}".format(file_name))
                        del self.uploading["meta_files"][file_name]
                    self._save_uploading_status()
                del_files = []
                for file_name in self.uploading["video_files"]: 
                    file_path = os.path.join(self.path, file_name)
                    if not os.path.exists(file_path): 
                        del_files.append(file_name)
                if del_files: 
                    for file_name in del_files: 
                        print("footage remove file: {}".format(file_name))
                        del self.uploading["video_files"][file_name]
                    self._save_uploading_status()
                ## add new files 
                for filename in os.listdir(self.path):
                    file_path = os.path.join(self.path, filename)
                    if os.path.isfile(file_path):
                        ext = os.path.splitext(filename)[1]
                        if ext == ".json": 
                            if filename not in self.uploading["meta_files"]: 
                                print("footage add file: {}".format(filename))
                                self.uploading["meta_files"][filename] = {"state": FilesUploader.STOPPED}
                                self._save_uploading_status()
                        elif ext == ".mp4" or ext == ".mkv": 
                            if filename not in self.uploading["video_files"]: 
                                print("footage add file: {}".format(filename))
                                self.uploading["video_files"][filename] = {"state": FilesUploader.STOPPED}
                                self._save_uploading_status()
                # print(self.uploading["meta_files"])
                # print(self.uploading["video_files"])
        except Exception as e: 
            print("sync files error: " + str(e))
            self.last_error = {"error": 0, "meesage": str(e)}

    ## return the file names in order 
    def _meta_files(self): 
        if "meta_files" in self.uploading: 
            meta_files = self.uploading["meta_files"].keys()
            meta_files.sort() 
            return meta_files
        else: 
            return [] 

    ## return the file names in order 
    def _video_files(self): 
        if "video_files" in self.uploading: 
            video_files = self.uploading["video_files"].keys()
            video_files.sort()
            return video_files
        else: 
            return [] 

    ## define the ID of the file, based on its name or index 
    def _meta_file_id(self, index, file_name): 
        # meta file name stem
        return ".".join(file_name.split('.')[:-1])

    ## define the ID of the file, based on its name or index 
    def _video_file_id(self, index, file_name): 
        # video file name stem 
        return ".".join(file_name.split('.')[:-1])

    def _object_id(self, file_id): 
        return "{}/{}".format(self.id, file_id)

    ## the file's uploading state is updated by the files uploader 
    def set_file_state(self, file_id, state, message = None):
        print("set file state: {} - {}".format(file_id, state))
        if state == FilesUploader.FAILED: 
            self.last_error = {"code": 0, "message": "{}/{} uploading failed: {}".format(self.id, file_id, message)}
        try: 
            with self.lock:  
                for i, file_name in enumerate(self._meta_files()): 
                    id = self._meta_file_id(i, file_name)
                    if id == file_id: 
                        self.uploading["meta_files"][file_name]["state"] = state 
                        self._save_uploading_status()
                        self._report_footage_progress()
                        return True 
                for i, file_name in enumerate(self._video_files()): 
                    id = self._video_file_id(i, file_name)
                    if id == file_id: 
                        self.uploading["video_files"][file_name]["state"] = state 
                        self._save_uploading_status()
                        if state == FilesUploader.UPLOADED: 
                            self._report_footage_part_finished(file_id) 
                        else: 
                            self._report_footage_part_progress(file_id)
                        self._report_footage_progress()
                        return True 
                print("Not found file to set state")
                return False 
        except Exception as e: 
            print("set file state error: " + str(e))
            self.last_error = {"code": 0, "message": str(e)}

    def _report_footage_part_finished(self, file_id):
        print("--- report footage part uploading progress: {}/{} - finished".format(self.id, file_id))
        try: 
            self.api.footage_part_upload_progress(self.id, file_id, True, 100)
        except Exception as e: 
            print("report footage part finish error: " + str(e))
            self.last_error = {"code": 0, "message": str(e)}

    def _report_footage_part_progress(self, file_id): 
        print("--- report footage part uploading progress: {}/{} - 0".format(self.id, file_id))
        try: 
            self.api.footage_part_upload_progress(self.id, file_id, False, 0)
        except Exception as e: 
            print("report footage part progress error: " + str(e))
            self.last_error = {"code": 0, "message": str(e)}

    def _report_footage_finished(self): 
        print("--- report footage uploading progress: {} - finished".format(self.id))
        try: 
            self.api.footage_upload_progress(self.id, True, 100)
        except Exception as e: 
            print("report footage finish error: " + str(e))
            self.last_error = {"code": 0, "message": str(e)}

    def _report_footage_progress(self):
        print("--- report footage uploading progress: {}".format(self.id))
        try: 
            footage_progress = 0 
            footage_state = self.uploading["state"] if "state" in self.uploading else self.STOPPED
            if footage_state == self.UPLOADED: 
                footage_progress = 100 
            else: 
                total_kb = 0
                uploaded_kb = 0
                for file_name in self._meta_files(): 
                    file_path = os.path.join(self.path, file_name) 
                    file_size = int(os.path.getsize(file_path) / 1000) 
                    total_kb += file_size
                    file_state = self.uploading["meta_files"][file_name]["state"]
                    if file_state == FilesUploader.UPLOADED: 
                        uploaded_kb += file_size 
                for file_name in self._video_files(): 
                    file_path = os.path.join(self.path, file_name) 
                    file_size = int(os.path.getsize(file_path) / 1000) 
                    total_kb += file_size
                    file_state = self.uploading["video_files"][file_name]["state"]
                    if file_state == FilesUploader.UPLOADED: 
                        uploaded_kb += file_size 
                footage_progress = int(100.0 * uploaded_kb / total_kb) if total_kb > 0 else 0 
            print("--- report footage uploading progress: {} - {}".format(self.id, footage_progress))
            self.api.footage_upload_progress(self.id, False, footage_progress)
        except Exception as e: 
            print("report footage progress error: " + str(e))
            self.last_error = {"code": 0, "message": str(e)}

    ## check if all files uploaded 
    def _check_uploaded_state(self): 
        print("check uploaded state")
        try: 
            meta_uploaded = True 
            video_uploaded = True 
            for file_name in self._meta_files(): 
                file = self.uploading["meta_files"][file_name]
                file_state = file["state"]
                if file_state != FilesUploader.UPLOADED: 
                    meta_uploaded = False 
            for file_name in self._video_files(): 
                file = self.uploading["video_files"][file_name]
                file_state = file["state"]
                if file_state != FilesUploader.UPLOADED: 
                    video_uploaded = False
            if meta_uploaded and video_uploaded: 
                if self.uploading["state"] != FootageUploading.UPLOADED:
                    print("set footage {} to uploaded state".format(self.id))
                    self.uploading["state"] = FootageUploading.UPLOADED 
                    self._save_uploading_status() 
                    self._report_footage_finished()
            else: 
                if self.uploading["state"] == FootageUploading.UPLOADED:
                    print("set footage {} to uploading state".format(self.id))
                    self.uploading["state"] = FootageUploading.UPLOADING
                    self._save_uploading_status() 
            print("check uploaded state done")
        except Exception as e: 
            print("check fuploaded state error: " + str(e))
            self.last_error = {"code": 0, "message": str(e)}

    ## we will set the footage into uploading state, with start or resume command 
    ## in this state, we will scheule the files to be uploaded by the uploader, and 
    ## set the footage to "uploaded" state once all files uploaded. 
    def _check_uploading_state(self):
        print("check uploading state")
        ## we will add files to the uploader 
        ## and wait the uploader to set it to "waiting", "uploading", or "uploaded" state
        ## here we handle the "meta" files and the "video" files respectively so to ensure 
        ## the meta files get priority. the operations on all file are actually same. 
        for i, file_name in enumerate(self._meta_files()):
            try: 
                file = self.uploading["meta_files"][file_name]
                print("{}: {}".format(file_name, file))
                file_state = file["state"]
                if file_state == FilesUploader.STOPPED or file_state == FilesUploader.FAILED: 
                    file_id = self._meta_file_id(i, file_name)
                    print("file id: {}".format(file_id))
                    file_path = os.path.join(self.path, file_name) 
                    print("file path: {}".format(file_path))
                    if "retry" not in file: 
                        file["retry"] = 0
                        self._save_uploading_status() 
                    file_retry = file["retry"]
                    print("file retry: {}".format(file_retry))
                    if file_retry > 5 or "url" not in file: 
                        print("api: footage_meta_upload")
                        url = self.api.footage_meta_upload(self.id)
                        print("Presigned URL: {}".format(url))
                        self.uploader.remove(self._object_id(file_id))
                        file["state"] = FilesUploader.STOPPED
                        file["url"] = url 
                        file["retry"] = 0
                        self._save_uploading_status() 
                    file_url = file["url"]
                    print("file url: {}".format(file_url))
                    self.uploader.add(self._object_id(file_id), file_path, file_url)
                    file["state"] = FilesUploader.WAITING
                    file["retry"] += 1
                    self._save_uploading_status() 
            except Exception as e: 
                print("check meta uploading state error: " + str(e))
                self.last_error = {"code": 0, "message": str(e)}
        for i, file_name in enumerate(self._video_files()):
            try: 
                file = self.uploading["video_files"][file_name]
                print("{}: {}".format(file_name, file))
                file_state = file["state"]
                if file_state == FilesUploader.STOPPED or file_state == FilesUploader.FAILED: 
                    file_id = self._video_file_id(i, file_name)
                    print("file id: {}".format(file_id))
                    file_path = os.path.join(self.path, file_name) 
                    print("file path: {}".format(file_path))
                    if "retry" not in file: 
                        file["retry"] = 0
                        self._save_uploading_status() 
                    file_retry = file["retry"]
                    print("file retry: {}".format(file_retry))
                    if file_retry > 5 or "url" not in file: 
                        print("api: footage_part_upload")
                        url = self.api.footage_part_upload(self.id, file_id)
                        print("Presigned URL: {}".format(url))
                        self.uploader.remove(self._object_id(file_id))
                        file["state"] = FilesUploader.STOPPED
                        file["url"] = url
                        file["retry"] = 0
                        self._save_uploading_status() 
                    file_url = file["url"]
                    print("file url: {}".format(file_url))
                    self.uploader.add(self._object_id(file_id), file_path, file_url)
                    file["state"] = FilesUploader.WAITING
                    file["retry"] += 1
                    self._save_uploading_status() 
            except Exception as e: 
                print("check video uploading state error: " + str(e))
                self.last_error = {"code": 0, "message": str(e)}
        print("check uploading state done")

    ## we will set the footage into stopping state, with stop command 
    ## in this state, we will wait for the state from uploader and set the footage state
    def _check_stopping_state(self): 
        print("check stopping state")
        meta_stopped = True 
        video_stopped = True 
        for i, file_name in enumerate(self._meta_files()): 
            try: 
                file = self.uploading["meta_files"][file_name]
                file_state = file["state"]
                if file_state == FilesUploader.WAITING or file_state == FilesUploader.UPLOADING: 
                    file_id = self._meta_file_id(i, file_name)
                    self.uploader.remove(self._object_id(file_id))
                    print("File stopped") 
                    file["state"] = FilesUploader.STOPPED
                    self._save_uploading_status()
            except Exception as e: 
                print("check pausing state error: " + str(e))
                meta_stopped = False 
                self.last_error = {"code": 0, "message": str(e)}
        for i, file_name in enumerate(self._video_files()): 
            try: 
                file = self.uploading["video_files"][file_name]
                file_state = file["state"]
                if file_state == FilesUploader.WAITING or file_state == FilesUploader.UPLOADING: 
                    file_id = self._video_file_id(i, file_name)
                    self.uploader.remove(self.object_id(file_id))
                    print("file stopped")
                    file["state"] = FilesUploader.STOPPED
                    self._save_uploading_status()
            except Exception as e: 
                print("check pausing state error: " + str(e))
                meta_stopped = False 
                self.last_error = {"code": 0, "message": str(e)}
        if meta_stopped and video_stopped: 
            try: 
                print("set footage {} to stopped state".format(self.id))
                self.uploading["state"] = self.STOPPED
                if "meta_files" in self.uploading: 
                    del self.uploading["meta_files"]
                if "video_files" in self.uploading: 
                    del self.uploading["video_files"]
                self._save_uploading_status() 
            except Exception as e: 
                print("set footage stopped state error: " + str(e))
                self.last_error = {"code": 0, "message": str(e)}
        print("check stopping state done")

    def _check_pausing_state(self): 
        ## the target of pausing state is paused state, or uploaded state in some cases. 
        ## We will try to cancel the uploading until all files are not in uploading state 
        print("check paused state")
        meta_paused = True 
        video_paused = True 
        for i, file_name in enumerate(self._meta_files()): 
            try: 
                file = self.uploading["meta_files"][file_name]
                file_state = file["state"]
                if file_state == FilesUploader.WAITING or file_state == FilesUploader.UPLOADING: 
                    file_id = self._meta_file_id(i, file_name)
                    self.uploader.remove(self._object_id(file_id))
                    print("file paused")
                    file["state"] = FilesUploader.STOPPED
                    self._save_uploading_status()   
            except Exception as e: 
                print("check pausing state error: " + str(e))
                meta_paused = False 
                self.last_error = {"code": 0, "message": str(e)}
        for i, file_name in enumerate(self._video_files()): 
            try: 
                file = self.uploading["video_files"][file_name]
                file_state = file["state"]
                if file_state == FilesUploader.WAITING or file_state == FilesUploader.UPLOADING: 
                    file_id = self._video_file_id(i, file_name)
                    self.uploader.remove(self._object_id(file_id))
                    print("file paused") 
                    file["state"] = FilesUploader.STOPPED
                    self._save_uploading_status()   
            except Exception as e: 
                print("check pausing state error: " + str(e))
                video_paused = False 
                self.last_error = {"code": 0, "message": str(e)}
        if meta_paused and video_paused: 
            try: 
                print("set footage {} to paused state".format(self.id))
                self.uploading["state"] = self.PAUSED
                self._save_uploading_status() 
            except Exception as e: 
                print("set footage paused state error: " + str(e))
                self.last_error = {"code": 0, "message": str(e)}
        print("check pausing state done")

    ## the footage uploading works in an async mode 
    ## the user will "set" the target state for the footage, and then 
    ## with this "update" function, we will check and ensure the target state 
    def update(self):
        ## load all files for the state checking 
        self._sync_files()
        ## check status 
        with self.lock: 
            ## reset error message 
            self.last_error = None 
            ## check if uploaded already 
            self._check_uploaded_state() 
            ## handle other states 
            state = self.uploading["state"]
            if state == self.UPLOADING:
                self._check_uploading_state() 
            elif state == self.PAUSING: 
                self._check_pausing_state()
            elif state == self.STOPPING: 
                self._check_stopping_state()

## Extend the footage manager to including uploading manager 
class UploadingManager(FootageManager): 
    def __init__(self, settings): 
        super(UploadingManager, self).__init__(settings)
        self.settings = settings 
        self.footage_instance_creator = self._create_footage
        self.lock = threading.Lock()

        ## Initialize the files uploader 
        uploading_threads = settings["uploading_threads"] if "uploading_threads" in settings else 5 
        print("Initialize files uploader with workers number: {}".format(uploading_threads))
        self.uploader = FilesUploader(self._uploading_status_callback, max_workers=uploading_threads)

        ## Initialize the uploading API
        service_url = settings["service_url"] if "service_url" in settings else ""
        print("Service URL: {}".format(service_url))
        token_file = settings["token_file"] if "token_file" in settings else "/opt/reeplayer/.token"
        print("Loading token form file: {}".format(token_file))
        try: 
            with open(token_file) as f: 
                token = json.load(f)["token"] 
            print(token)
        except Exception as e: 
            print("Failed loading token from file {}: {}".format(token_file, str(e)))
            raise e

        serial_file = settings["serial_file"] if "serial_file" in settings else "/opt/reeplayer/.serial"
        print("Loading serial no from file {}".format(serial_file))
        try:  
            with open(serial_file) as f: 
                serial_no = json.load(f)["serial_no"]
            print(serial_no)
        except Exception as e: 
            print("Failed loading serial no from file {}: {}".format(serial_file, str(e)))
            raise e

        print("Initialize uploading API")
        self.api = UploadingAPI(service_url, token, serial_no) 

        ## the thread to maintain the status of uploading 
        print("Starting uploading management thread")
        self.stop = threading.Event()
        self.uploading_thread = threading.Thread(target=self._uploading_update_thread)
        self.uploading_thread.start()

    def _create_footage(self, path): 
        return FootageUploading(path, self.settings, self.uploader, self.api)

    def shutdown(self): 
        print("Shutting down the uploading manager")
        self.stop.set() 

    def start_footage_uploading(self, footage_id): 
        try:
            with self.lock: 
                self._sync_footage() 
                self.footages[footage_id].start_uploading()
        except Exception as e: 
            print("start_footage_uploading error: " + str(e))
            raise e 

    def stop_footage_uploading(self, footage_id): 
        try:
            with self.lock:  
                self._sync_footage() 
                self.footages[footage_id].stop_uploading() 
        except Excpetion as e: 
            print("stop_footage_uploading error: " + str(e))
            raise e 

    def pause_footage_uploading(self, footage_id): 
        try: 
            with self.lock: 
                self._sync_footage() 
                self.footages[footage_id].pause_uploading()
        except Excpetion as e: 
            print("pause_footage_uploading error: " + str(e))
            raise e 

    def resume_footage_uploading(self, footage_id): 
        try: 
            with self.lock: 
                self._sync_footage() 
                self.footages[footage_id].resume_uploading()
        except Excpetion as e: 
            print("resume_footage_uploading error: " + str(e))
            raise e 

    def all_footage(self):
        try: 
            with self.lock: 
                self._sync_footage() 
                return self.footages.keys() 
        except Exception as e: 
            print("all_footage error: " + str(e))
            raise e 

    def footage_uploading_status(self, footage_id): 
        try: 
            with self.lock: 
                self._sync_footage() 
                return self.footages[footage_id].uploading_status() 
        except Exception as e: 
            print("footage_uploading_status error: " + str(e))
            raise e 

    def _uploading_status_callback(self, object_id, status, message = None): 
        print("uploading status: {} - {}".format(object_id, status))
        try: 
            with self.lock:
                footage_id, file_id = object_id.split('/')
                self.footages[footage_id].set_file_state(file_id, status, message) 
        except Exception as e: 
            print("set file uploading status error: " + str(e))

    def _uploading_update_thread(self): 
        print("uploading update thread in")
        while not self.stop.isSet(): 
            try: 
                with self.lock: 
                    self._sync_footage()
                    for footage_id in self.footages: 
                        self.footages[footage_id].update() 
            except Exception as e: 
                print("uploading update error: " + str(e))
            time.sleep(1.0)
        print("uploading update thread out")
