#! /usr/bin/env python

import os 
import time
import threading

import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse

import json
from jsonrpc import * 

import uuid 
import shutil

class FootageManager(object): 
    def __init__(self): 
        ## loading config 
        self.settings = {} 
        config_file = rospy.get_param("~config_file", "footage_manager.json")
        try: 
            rospy.loginfo("Loading config from: {}".format(config_file))
            with open(config_file) as f: 
                self.settings = json.load(f)
                rospy.logdebug(self.settings)
        except Exception as e: 
            rospy.logwarn("Failed loading config file {}: {}".format(config_file, str(e))) 

        self.footage_location = (self.settings["footage_location"] if "footage_location" in self.settings 
                                 else os.path.join(os.path.expanduser("~"), "camera_data"))
        rospy.loginfo("Footage location: {}".format(self.footage_location))

        self.footage_info_file = self.settings["footage_info"] if "footage_info" in self.settings else ".footage"
        rospy.loginfo("Footage info file: {}".format(self.footage_info_file))

        self.field_corners_file = self.settings["field_corners"] if "field_corners" in self.settings else "corners.json"
        rospy.loginfo("Footage field corners file: {}".format(self.field_corners_file))

        ## dispatch service requests to handlers
        ## this is a list of methods that can be procesed by this node  
        self.service_handlers = { 
            'check_config': self.check_config, 
            'update_config': self.update_config, 
            'reset_config': self.reset_config, 
            'save_config': self.save_config, 
            'footage_status': self.footage_status,
            'prepare_footage': self.prepare_footage, 
            'erase_footage': self.erase_footage, 
            'footage_files': self.footage_files,
            'set_meta': self.set_meta,
            'remove_meta': self.remove_meta,  
            "check_meta": self.check_meta
        }
        rospy.loginfo("Service handlers: {}".format(self.service_handlers.keys()))

        ## A list of status checking methods 
        ## add or remove by status subscribe method 
        self.subscriptions = [
            'footage_status',
        ]
        rospy.loginfo("Status subscriptions: {}".format(self.subscriptions))

        ## rpc service 
        rpc_service = "rpc"
        rospy.loginfo("Starting service: {}".format(rpc_service))
        rospy.Service(rpc_service, JsonService, self.rpc_service_handler)

        ## status topic 
        status_topic = "status" 
        rospy.loginfo("Advertise topic: {}".format(status_topic))
        self.status_pub = rospy.Publisher(status_topic, JsonString, queue_size=2)

        ## status notification, check and publish status periodically in a thead 
        status_thread = threading.Thread(target=self.status_update_thread)
        status_thread.start()


    ## RPC service handler 
    ## JSON string carried by ROS service request and response  
    def rpc_service_handler(self, request): 
        rospy.logdebug("RPC servcie request: {}".format(request.data))
        json_response = {}
        try: 
            json_request = json.loads(request.data.decode())
            json_response = self.handle_json_request(json_request)
        except: 
            json_reponse = jsonrpc_wrap_error(None, JSON_PARSE_ERROR, get_error_message(JSON_PARSE_ERROR))
        response = json.dumps(json_response)
        rospy.logdebug("service response: {}".format(response))
        return JsonServiceResponse(response.encode())


    ## handle JSON-RPC 2.0 request 
    def handle_json_request(self, request): 
        rospy.logdebug("handle json request: {}".format(request))
        if isinstance(request, list): 
            return self.handle_batch_request(request)
        elif isinstance(request, dict): 
            return self.handle_single_request(request)
        else: 
            return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, get_error_message(RPC_INVALID_REQUEST)); 


    ## handle batch request 
    def handle_batch_request(self, request): 
        rospy.logdebug("handle batch request: {}".format(request))
        if len(request) == 0: 
            return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, get_error_message(RPC_INVALID_REQUEST))
        else: 
            response = [] 
            for requ in request: 
                resp = self.handle_single_request(requ); 
                response.append(resp)
            return response


    ## handle single request 
    def handle_single_request(self, request): 
        rospy.logdebug("handle single request: {}".format(request))
        if jsonrpc_validate_request(request): 
            return self.process_request(request)
        else: 
            return jsonrpc_wrap_error(None, RPC_INVALID_REQUEST, get_error_message(RPC_INVALID_REQUEST))


    ## process request 
    def process_request(self, request): 
        rospy.logdebug("process request: {}".format(request))
        try: 
            method = request["method"]
            if method in self.service_handlers: 
                rospy.logdebug("handle request: {}".format(method))
                params = request["params"] if "params" in request else None 
                result = self.service_handlers[method](params)
                rospy.logdebug("result: {}".format(result))
                return jsonrpc_wrap_result(request, result)
            else: 
                rospy.logerr("unsupported method: {}".format(method))
                return jsonrpc_wrap_error(None, RPC_METHOD_NOT_FOUND, str(method))
        except JsonRpcError as e:
            rospy.logerr("exception: {}".format(str(e)))
            return jsonrpc_wrap_exception(request, e)
        except Exception as e: 
            rospy.logerr("exception: {}".format(str(e)))
            return jsonrpc_wrap_error(None, RPC_INTERNAL_ERROR, str(e))  


    ## check config  
    def check_config(self, params): 
        rospy.logdebug("check config...")
        raise JsonRpcError(RPC_INTERNAL_ERROR, "Not implemented.")


    ## update config  
    def update_config(self, params): 
        rospy.logdebug("update config...")
        raise JsonRpcError(RPC_INTERNAL_ERROR, "Not implemented.")


    ## reset config  
    def reset_config(self, params): 
        rospy.logdebug("reset config...")
        raise JsonRpcError(RPC_INTERNAL_ERROR, "Not implemented.")


    ## save config  
    def save_config(self, params): 
        rospy.logdebug("save config...")
        raise JsonRpcError(RPC_INTERNAL_ERROR, "Not implemented.")


    def _get_time_string(self): 
        return time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime())
        

    def _get_footage_id(self, location): 
        rospy.logdebug("load footage id for {}".format(location))
        meta_file = os.path.join(self.footage_location, location, self.footage_info_file)
        try: 
            with open(meta_file) as f:
                meta = json.load(f)
                return meta["id"] 
        except Exception as e: 
            rospy.logwarn("Faild loading footage id: {}".format(str(e))) 
            return location

    def _get_footage_name(self, location): 
        rospy.logdebug("load footage name for {}".format(location))
        meta_file = os.path.join(self.footage_location, location, self.footage_info_file)
        try: 
            with open(meta_file) as f:
                meta = json.load(f)
                return meta["name"]
        except Exception as e:
            rospy.logwarn("Faild loading footage name: {}".format(str(e))) 
            return location

    def _get_footage_timestamp(self, location): 
        return os.stat(os.path.join(self.footage_location, location)).st_ctime

    def _get_footage_size(self, location): 
        rospy.logdebug("get footage size for {}".format(location))
        size_kb = 0
        try: 
            for filename in os.listdir(os.path.join(self.footage_location, location)):
                filepath = os.path.join(self.footage_location, location, filename)
                if os.path.isfile(filepath):
                    ext = os.path.splitext(filename)[1]
                    if ext == ".mp4" or ext == ".mkv": 
                        size_kb += int(os.path.getsize(filepath) / 1000)
        except Exception as e: 
            rospy.logwarn("Failed gete footage size: {}".format(str(e)))
        return size_kb

    def _load_footage_ids(self): 
        rospy.logdebug("load footage ids...")
        ids = []
        for location in os.listdir(self.footage_location):
            if os.path.isdir(os.path.join(self.footage_location, location)) and not location.startswith('.'):  
                ids.append(self._get_footage_id(location))
        rospy.logdebug("footage ids: {}".format(ids))
        return ids 

    def _load_footage_locations(self): 
        rospy.logdebug("load footage locaitons...")
        locations = {}
        for location in os.listdir(self.footage_location):
            if os.path.isdir(os.path.join(self.footage_location, location)) and not location.startswith('.'): 
                id = self._get_footage_id(location)
                locations[id] = location
        rospy.logdebug("footage lovations: {}".format(locations))
        return locations 

    def _load_footage_files(self, location): 
        rospy.logdebug("load footage files for {}".format(location))
        meta_files = []
        video_files = [] 
        try: 
            for filename in os.listdir(os.path.join(self.footage_location, location)):
                filepath = os.path.join(self.footage_location, location, filename)
                if os.path.isfile(filepath):
                    ext = os.path.splitext(filename)[1]
                    if ext == ".mp4" or ext == ".mkv": 
                        video_files.append({"filename": filename, "filepath": filepath})
                    elif ext == ".json": 
                        meta_files.append({"filename": filename, "filepath": filepath})
        except Exception as e: 
            rospy.logwarn("Failed loading footage files: {}".format(str(e)))
        return meta_files, video_files

    def _update_footage_id(self, location, id): 
        rospy.logdebug("update footage id for {}: {}".format(location, id))
        meta_file = os.path.join(self.footage_location, location, self.footage_info_file)
        try: 
            with open(meta_file) as f:
                meta = json.load(f)
                meta["id"] = id 
        except Exception as e: 
            rospy.logwarn("Failed loading footage meta: {}".format(str(e)))
            meta = {"id": id}
        try: 
            with open(meta_file, "w+") as f:
                json.dump(meta, f, indent=4)
        except Exception as e: 
            rospy.logwarn("Failed writing footage meta: {}".format(str(e)))


    def _get_footage_location(self, footage_id): 
        for location in os.listdir(self.footage_location):
            if os.path.isdir(os.path.join(self.footage_location, location)): 
                id = self._get_footage_id(location)
                if footage_id == id: 
                    return location 
        raise JsonRpcError(RPC_INVALID_PARAMS, "Invalid footage id: {}".format(footage_id))


    def _load_field_corners(self, footage_id): 
        rospy.logdebug("load field corners for {}".format(footage_id))
        location = self._get_footage_location(footage_id)
        corners_file = os.path.join(self.footage_location, location, self.field_corners_file)
        with open(corners_file) as f:
            field_corners = json.load(f)
            return field_corners 


    def _update_field_corners(self, footage_id, field_corners): 
        rospy.logdebug("update field corners for {}: {}".format(footage_id, field_corners))
        location = self._get_footage_location(footage_id)
        corners_file = os.path.join(self.footage_location, location, self.field_corners_file)
        with open(corners_file, "w+") as f:
            json.dump(field_corners, f, indent=4)


    def _remove_field_corners(self, footage_id): 
        rospy.logdebug("remove field corners for {}".format(footage_id))
        location = self._get_footage_location(footage_id)
        corners_file = os.path.join(self.footage_location, location, self.field_corners_file)
        os.remove(corners_file)


    ## Prepare footage, with known id or new one 
    def prepare_footage(self, params): 
        rospy.logdebug("Prepare footage: {}".format(params))
        footage_id = None 
        if params is not None and "footage_id" in params:
            try: 
                footage_id = params["footage_id"]
                locations = self._load_footage_locations() 
                print(locations)
                if footage_id in locations: 
                    return {"footage_id": footage_id, "footage_location": locations[footage_id]}
            except Exception as e: 
                raise JsonRpcError(RPC_INTERNAL_ERROR, str(e))
        try: 
            while not footage_id: 
                footage_id = str(uuid.uuid4()) 
                footage_ids = self._load_footage_ids() 
                if footage_id in footage_ids: 
                    footage_id = None 
        except Exception as e: 
            rospy.logerr("Error prepare footage id: {}".format(str(e)))
            raise JsonRpcError(RPC_INTERNAL_ERROR, str(e))
        rospy.loginfo("footage id: {}".format(footage_id))
            
        footage_location = None 
        try: 
            while not footage_location: 
                footage_location = self._get_time_string()
                footage_path = os.path.join(self.footage_location, footage_location)
                if os.path.exists(footage_path): 
                    footage_path = None 
                else: 
                    os.mkdir(footage_path) 
        except Exception as e: 
            rospy.logerr("Error prepare footage location: {}".format(str(e)))
            raise JsonRpcError(RPC_INTERNAL_ERROR, str(e))
        rospy.loginfo("footage location: {}".format(footage_location))
        self._update_footage_id(footage_location, footage_id)
        footage = {
            "footage_id": footage_id, 
            "footage_location": footage_location}
        return footage


    def erase_footage(self, params): 
        rospy.loginfo("erase footage...")
        if params is None or len(params) == 0:
            raise JsonRpcError(RPC_INVALID_PARAMS, "No parameter")
        if "footage_id" not in params: 
            raise JsonRpcError(RPC_INVALID_PARAMS, "No valid footage id is passed")
        footage_id = params["footage_id"]
        rospy.loginfo("footage id: {}".format(footage_id))
        found = False 
        for location in os.listdir(self.footage_location):
            if os.path.isdir(os.path.join(self.footage_location, location)): 
                id = self._get_footage_id(location)
                if footage_id == id: 
                    found = True
                    rospy.loginfo("erased footage location: {}".format(location))
                    shutil.rmtree(os.path.join(self.footage_location, location))
                    rospy.loginfo("erased footage done")
        if not found: 
            raise JsonRpcError(RPC_INVALID_PARAMS, "Not found the footage id: {}".format(footage_id))


    ## footage files for one, more, or all footage  
    def footage_files(self, params): 
        rospy.loginfo("footage files...")
        files = {}
        try: 
            for location in os.listdir(self.footage_location):
                if os.path.isdir(os.path.join(self.footage_location, location)) and not location.startswith('.'): 
                    footage_id = self._get_footage_id(location)
                    rospy.logdebug("footage id: {}".format(footage_id))
                    meta_files, video_files = self._load_footage_files(location)
                    rospy.logdebug(meta_files)
                    rospy.logdebug(video_files)
                    files[footage_id] = {
                        "footage_id": footage_id, 
                        "meta_files": meta_files, 
                        "video_files": video_files, 
                    }
            rospy.logdebug("files: {}".format(files))
        except Exception as e: 
            rospy.logwarn("Error in check footage files: " + str(e))
        ## response files for all conditions  
        return files


    def set_meta(self, params): 
        rospy.loginfo("footage set meta...")
        if "footage_id" not in params: 
            raise JsonRpcError(RPC_INVALID_PARAMS, "No valid footage id is set")
        if "meta_data" not in params: 
            raise JsonRpcError(RPC_INVALID_PARAMS, "No valid meta data is set")
        if "field_corners" in params["meta_data"]: 
            self._update_field_corners(params["footage_id"], params["meta_data"]["field_corners"])


    def remove_meta(self, params): 
        rospy.loginfo("footage remove meta...")
        if "footage_id" not in params: 
            raise JsonRpcError(RPC_INVALID_PARAMS, "No valid footage id is set")
        if "meta_names" not in params: 
            raise JsonRpcError(RPC_INVALID_PARAMS, "No valid meta names are set")
        if "field_corners" in params["meta_names"]: 
            self._remove_field_corners(params["footage_id"])


    def check_meta(self, params): 
        rospy.loginfo("footage check meta...")
        if "footage_id" not in params: 
            raise JsonRpcError(RPC_INVALID_PARAMS, "No valid footage id is set")
        if "meta_names" not in params or not isinstance(params["meta_names"], list):  
            raise JsonRpcError(RPC_INVALID_PARAMS, "No valid meta names are set")
        meta_dataa = {}
        if "field_corners" in params["meta_names"]: 
            try: 
                meta_dataa["field_corners"] = self._load_field_corners(params["footage_id"])
            except Exception as e: 
                rospy.logwarn("Failed load field corners: " + str(e))
        return meta_dataa


    ## footage status for one, more, or all footage  
    def footage_status(self, params): 
        rospy.logdebug("footage status...")
        statuses = {}
        try: 
            for location in os.listdir(self.footage_location):
                if os.path.isdir(os.path.join(self.footage_location, location)) and not location.startswith('.'): 
                    footage_id = self._get_footage_id(location)
                    rospy.logdebug("footage id: {}".format(footage_id))
                    footage_name = self._get_footage_name(location)
                    rospy.logdebug("footage name: {}".format(footage_name))
                    footage_timestamp = self._get_footage_timestamp(location)
                    footage_size = self._get_footage_size(location)
                    statuses[footage_id] = {
                        "footage_id": footage_id, 
                        "footage_name": footage_name, 
                        "footage_location": location, 
                        "footage_timestamp": footage_timestamp, 
                        "footage_size_kb": footage_size, 
                    }
            rospy.logdebug("statuses: {}".format(statuses))
        except Exception as e: 
            rospy.logwarn("Error in check footage status: " + str(e))
        ## response status for all conditions  
        return statuses


    ## status update thread 
    def status_update_thread(self): 
        rospy.loginfo("Status update thread in")
        update_rate = rospy.get_param("~status_update_rate", 1.0)
        update_rate = update_rate if update_rate > 0 else 1.0
        rospy.loginfo("status update rate: {}".format(update_rate))
        ros_rate = rospy.Rate(update_rate)
        while not rospy.is_shutdown():
            if self.status_pub.get_num_connections() > 0: 
                status = []
                for method in self.subscriptions:
                    request = {"method": method} 
                    try: 
                        response = self.handle_json_request(request)
                        if "result" in response: 
                            notification = {"method": method, "params": response["result"]}
                            status.append(notification)
                    except Exception as e: 
                        rospy.logwarn("Error in status update for {}: {}".format(method, str(e)))
                if status: 
                    status_msg = JsonString(json.dumps(status)) 
                    self.status_pub.publish(status_msg)
                    rospy.logdebug("Publish status topic: {}".format(status_msg))
            ros_rate.sleep() 
        rospy.loginfo("Status update thread out")


if __name__ == '__main__':
    try:
        rospy.init_node("footage_manager", log_level=rospy.DEBUG)
        FootageManager() 
        rospy.spin()
    except rospy.ROSInterruptException:
        print("ROS interrupted")
