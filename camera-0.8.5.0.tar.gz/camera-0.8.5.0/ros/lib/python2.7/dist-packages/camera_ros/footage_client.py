import json 
import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService 
from jsonrpc import * 


def _call_ros_service(service, method, params = None):
    request = jsonrpc_wrap_request(method, params)
    if not jsonrpc_validate_request(request): 
        raise Exception("Invalid JSON-RPC request: {}".format(request))
    try: 
        rospy.logdebug("JSON-RPC request: {}".format(request))
        response = json.loads(service(json.dumps(request)).data)
        # rospy.logdebug("JSON-RPC response: {}".format(response))
        return response["result"] if "result" in response else None 
    except rospy.ServiceException as e:
        raise Exception("Call ROS service failed: {}".format(e))
    except ValueError as e: 
        raise Exception("Invalid JSON value: {}".format(e))


## Client of RPC service implemented by footage manager node 
class Footage(object): 
    def __init__(self):
        self.status_topic = "footage_status"
        self.status_sub = None 

        footage_rpc_service = "footage_rpc"
        rospy.loginfo("Connecting to ROS service: {}".format(footage_rpc_service))
        self.rpc_service = rospy.ServiceProxy(footage_rpc_service, JsonService)
        # rospy.loginfo("Waiting for ROS service: {}".format(footage_rpc_service))
        # rospy.wait_for_service(footage_rpc_service)
        # rospy.loginfo("Connected to ROS service: {}".format(footage_rpc_service))


    def subscribe_status(self, status_callback): 
        def msg_callback(msg): 
            try: 
                rospy.logdebug(msg)
                notifications = json.loads(msg.data)
                statuses = {}
                for notification in notifications:
                    statuses[notification["method"]] = notification["params"] 
                status_callback(statuses)
            except Exception as e: 
                rospy.logwarn("Footage status topic callback error: " + str(e))
                
        rospy.loginfo("Subscribe ROS topic: {}".format(self.status_topic))
        self.status_sub = rospy.Subscriber(self.status_topic, JsonString, msg_callback) 


    def unsubscribe_status(self): 
        if self.status_sub: 
            rospy.loginfo("Unsubscribe ROS topic: {}".format(self.status_topic))
            self.status_sub.unregister()


    def prepare_footage(self, footage = None): 
        return _call_ros_service(self.rpc_service, "prepare_footage", {"footage_id": footage})


    def erase_footage(self, footage): 
        return _call_ros_service(self.rpc_service, "erase_footage", footage)


    def footage_status(self, footages = None): 
        return _call_ros_service(self.rpc_service, "footage_status", footages)
