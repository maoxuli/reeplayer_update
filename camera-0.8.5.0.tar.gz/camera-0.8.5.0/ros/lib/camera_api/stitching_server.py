#!/usr/bin/env python 

import json 
import threading
import queue  

import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse
from camera_ros import Calibrator, Recorder  

from concurrent import futures
import grpc

# Stitchig service
from camera_api import stitching_service_pb2, stitching_service_pb2_grpc


class StitchingServicer(stitching_service_pb2_grpc.StitchingServiceServicer):
    """Service to control and monitor the video stitching 
    """
    def __init__(self, task_action): 
        super(StitchingServicer, self).__init__()
        ## connect to ROS service of calibrator and recorder node 
        self.calibrator = Calibrator(task_action) 
        self.recorder = Recorder() 


    def online_calib(self, request, context):
        """Online calibration 
        """
        rospy.loginfo("Stitching online calib: {}".format(request.message))
        ## hook on the rpc exit 
        stop_event = threading.Event()
        def on_rpc_done():
            rospy.loginfo("Stitching online calib cancelling...")
            stop_event.set()   
        context.add_callback(on_rpc_done)

        ## queue for response from calibrator 
        response_queue = queue.Queue() 
        def on_feedback(calib_response): 
            try: 
                response_queue.put(calib_response)
                # rospy.logdebug("queue: {}".format(calib_response))
            except Exception as e: 
                rospy.logwarn("Stitching online calib feedback error: " + str(e))

        def on_result(calib_response): 
            try: 
                response_queue.put(calib_response)
                # rospy.logdebug("queue: {}".format(calib_response))
                response_queue.put(None)
                rospy.loginfo("push None after result")
            except Exception as e: 
                rospy.logwarn("Stitching online calib result error: " + str(e))

        def on_error(message): 
            rospy.logwarn("Stitching online calib error: {}".format(message))

        self.calibrator.online_calib(json.loads(request.message), on_feedback, on_result, on_error)

        ## waiting until client cancel or exception
        rospy.loginfo("Stitching online calib waiting on status")
        while not stop_event.is_set():
            try: 
                response = response_queue.get(timeout = 2) 
                if not response: 
                    rospy.loginfo("RPC done on action result")
                    break 
                message = {"progress": response["progress"]}
                images = response["images"]
                yield stitching_service_pb2.OnlineCalibResponse(message=json.dumps(message), images=images) 
                rospy.logdebug("yield: {}".format(message))
            except queue.Empty:
                rospy.logwarn("Stitching online calib response queue is empty, could be avoid by larger timeout.") 
                pass 
            except: 
                rospy.logwarn("What exception raised by yield when action is done?")
                pass 
        rospy.loginfo("Stitching online calib done")


    def cancel_online_calib(self, request, context):
        """Canel online calibration 
        """
        rospy.loginfo("Stitching cancel online calib")
        try: 
            self.calibrator.cancel_online_calib() 
            return stitching_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def save_calib(self, request, context):
        """Save calibration result
        """
        rospy.loginfo("Stitching save calib")
        try: 
            self.calibrator.save_calib() 
            return stitching_service_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def input_snapshot(self, request, context):
        """Snapshot of the stitching input 
        """
        rospy.loginfo("Stitching input snapshot: {}".format(request.image_scale))
        try: 
            images = self.recorder.capture_snapshot(request.image_scale) 
            return stitching_service_pb2.camera__api_dot_snapshot__pb2.SnapshotResponse(images=images)
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def output_snapshot(self, request, context):
        """Snapshot of the stitching output 
        """
        rospy.loginfo("Stitching snapshot: {}".format(request.image_scale))
        try: 
            images = self.recorder.recording_snapshot(request.image_scale) 
            return stitching_service_pb2.camera__api_dot_snapshot__pb2.SnapshotResponse(images=images)
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


    def snapshot(self, request, context):
        """Snapshot of the stitching output 
        """
        rospy.loginfo("Stitching snapshot: {}".format(request.image_scale))
        try: 
            images = self.recorder.recording_snapshot(request.image_scale) 
            return stitching_service_pb2.camera__api_dot_snapshot__pb2.SnapshotResponse(images=images)
        except Exception as e: 
            rospy.logerr(str(e))
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            raise RuntimeError(str(e))


class StitchingServer(object):
    def __init__(self, task_action): 
        ## gRPC server  
        num_threads = 4 
        ropy.loginfo("Service thread pool size: {}".format(num_threads))
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=num_threads))

        rospy.loginfo("Serve stitching service")
        stitching_service_pb2_grpc.add_StitchingServiceServicer_to_server(
            StitchingServicer(task_action),
            server
        )
        
        service_port = 50051
        rospy.loginfo("Listen on port: {}".format(service_port))
        self.server.add_insecure_port("[::]:{}".format(service_port))
        self.server.start()


    def wait_for_shutdown(self): 
        self.server.stop( )
        self.server.wait_for_termination()


if __name__ == "__main__":
    rospy.init_node("stitching_server", log_level=rospy.DEBUG)
    calibrator_task_action = rospy.get_param("~calibrator_task_action", "calibrator/task")
    server = StitchingServer(task_action) 
    try:
        rospy.spin()
    except rospy.ROSInterruptException:
        print("ROS interrupted")
    server.wait_for_shutdown() 
    print("Service shutdown")
