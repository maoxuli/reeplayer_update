#!/usr/bin/env python 

import json 
import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse
from camera_ros import Camera 

from concurrent import futures
import grpc

# Network service 
from camera_api import network_service_pb2, network_service_pb2_grpc


class NetworkServicer(network_service_pb2_grpc.NetworkServiceServicer):
    """Service to control and monitor all networks 
    """
    def __init__(self): 
        super(NetworkServicer, self).__init__() 
        ## connect to ROS service of camera node 
        self.camera = Camera() 

    def scan_wifi(self, request, context):
        """Scan the available wifi network 
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def connect_wifi(self, request, context):
        """Connect to wifi network 
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def disconnect_wifi(self, request, context):
        """Disconnect from wifi network 
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def check_status(self, request, context):
        """Check network status 
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def watch_status(self, request, context):
        """Watch network status, in stream 
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')


class NetworkServer(object):
    def __init__(self): 
        ## gRPC server  
        num_threads = 4 
        ropy.info("Service thread pool size: {}".format(num_threads))
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=num_threads))

        rospy.loginfo("Serve network service")
        network_service_pb2_grpc.add_NetworkServiceServicer_to_server(
            NetworkServicer(),
            server
        )
        
        service_port = 50051
        rospy.loginfo("Listen on port: {}".format(service_port))
        self.server.add_insecure_port("[::]:{}".format(service_port))
        self.server.start()


    def wait_for_shutdown(self): 
        self.server.stop( )
        self.server.wait_for_termination()


if __name__ == "__main__":
    rospy.init_node("network_server", log_level=rospy.DEBUG)
    server = NetworkServer() 
    try:
        rospy.spin()
    except rospy.ROSInterruptException:
        print("ROS interrupted")
    server.wait_for_shutdown() 
    print("Service shutdown")
