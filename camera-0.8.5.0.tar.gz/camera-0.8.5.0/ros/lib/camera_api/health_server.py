#!/usr/bin/env python

import json 
import threading
import queue  

import rospy
from std_msgs.msg import String as JsonString
from camera.srv import JsonService, JsonServiceResponse
from camera_ros import Camera, Recorder 

from concurrent import futures
import grpc

## Health service 
from camera_api import health_service_pb2 as _health_pb2
from camera_api import health_service_pb2_grpc as _health_pb2_grpc
from health_service import HealthServicer 


class HealthServer(object):
    def __init__(self): 
        ## gRPC server  
        num_threads = 4 
        ropy.loginfo("Service thread pool size: {}".format(num_threads))
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=num_threads))

        rospy.loginfo("Serve health service")
        ## Use the non-blocking implementation to avoid thread starvation.
        self.health_servicer = HealthServicer(
            experimental_non_blocking=True,
            experimental_thread_pool=futures.ThreadPoolExecutor(max_workers=num_threads))
        _health_pb2_grpc.add_HealthServicer_to_server(
            self.health_servicer, 
            self.server
        )
        
        service_port = 50051
        ropy.loginfo("Listen on port: {}".format(service_port))
        self.server.add_insecure_port("[::]:{}".format(service_port))
        self.server.start()


    def wait_for_shutdown(self): 
        print("Service shutting down...")
        self.health_servicer.enter_graceful_shutdown()
        self.server.stop( )
        self.server.wait_for_termination()


if __name__ == "__main__":
    rospy.init_node("health_server", log_level=rospy.DEBUG)
    server = HealthServer() 
    try:
        rospy.spin()
    except rospy.ROSInterruptException:
        print("ROS interrupted")
    server.wait_for_shutdown() 
    print("Service shutdown")
