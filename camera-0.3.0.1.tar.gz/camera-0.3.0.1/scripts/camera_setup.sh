#!/bin/bash

## Overwrite the default settings in this file. 
## The camera system will work with default settings, 
## if the settings are not set in this file.  

set -x

## Dependencies 
export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:/usr/local/lib" 

## HOME may be not set yet when system startup 
[[ -z "${HOME}" ]] && export HOME=/home/rose

## Path for camera system executable 
# export CAMERA_BIN="${HOME}/camera/bin"

## Path for config files
# export CAMERA_CONFIG="${HOME}/camera/config"

## Path for log files
# export CAMERA_LOG="${HOME}/camera/log"

## Auto update level 
## 0: no auto update, 1: auto download new version 
## 2: auto download and install new version 
# export AUTO_UPDATE=2 

## URL for update 
# export UPDATE_URL=""
export UPDATE_URL="https://raw.githubusercontent.com/maoxuli/reeplayer_update/master"

set +x 
