# Camera System 

## Build the camera system software from source code 

Below commands can be used to build the camera system software from source code. The "-a" opiton force to re-build all. 

    build.sh 
    [build.sh -a] 

The binary output of the build is in "lib" and "bin" by defaut, which is set in the "build.sh" file. 

## Create installation version package 

The installation version package is used to install the camera sysem software to other systems. To create the installation package, first set the version number in "versio.sh" as below: 

    VERSION=0.3.0.0

Then execute below commands. The "-i" option is for installation package. The "-a" option is for re-build all. 

    build.sh -i
    [build.sh -ai]

## Install the camera system software with version package 

Suppose the version package of the camera system software ("camera-x.x.x.x.tar.gz") has been downloaded or copied to the target system, and the camera sysem will be installed in the directory "~/Reeplayer", execute below commands in terminical:   

    mkdir ~/Reeplayer 
    tar -xvzf path/to/camera-x.x.x.x.tar.gz -C ~/Reeplayer 
    cd ~/Reeplayer/camera-x.x.x.x
    ./install.sh  

After the installation, the camera system software will be launched with the system startup. To uninstall the camera system software, execute below command: 

    cd ~/Reeplayer/camera
    ./uninstall.sh 
