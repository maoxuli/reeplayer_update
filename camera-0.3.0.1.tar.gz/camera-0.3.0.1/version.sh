#!/bin/bash

VERSION=0.3.0.1